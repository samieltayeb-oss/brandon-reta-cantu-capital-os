# DRAFT — NOT LEGALLY APPROVED
# Recommended Commercial Structures — Six Possible First Engagements (GROK-REVENUE-20261014-24)

Prepared by: NEXORA Legal Counsel Desk (AI legal research and drafting assistant — **not a licensed lawyer**). **Not legal advice.** No pricing. No prospect-specific agreement is drafted here. Builds on `GROK-REVENUE-20261014-18/contracting_guidance.md`, `LIAISON-20261014-06/draft_agreement_v2.md` and `schedule_a_proposal_v3_1.md`.

Conventions: every structure recommendation is REASONED_LEGAL_INTERPRETATION. Facts about prospects are limited to the scope descriptions given by NEXORA Liaison; anything else is **UNKNOWN**. Statutes are named only; **all section references are UNVERIFIED**. All NEXORA templates (MSA, SOW, NDA, DPA, Change Order, Acceptance Certificate) remain **DRAFT_ONLY**.

---

## Summary table

| # | Prospect | Engagement (as described) | Recommended structure & order | Personal info likely? | Key counsel items |
|---|---|---|---|---|---|
| 1 | Core Fabrication | Configurator ↔ work-order integration | Mutual NDA → paid discovery SOW → MSA + integration SOW (+ DPA only if PI flows through NEXORA) | UNKNOWN (mainly business-confidential: drawings, pricing) | IP split (custom code vs pre-existing tools), vendor API/terms reliance, liability cap |
| 2 | AspirePeak | Rent Manager workflows | Mutual NDA → paid discovery SOW (no live PI, or PI under interim data clause) → MSA + SOW + **DPA** | Yes, likely (tenants/owners) | Controller/role question, PIPA/PIPEDA applicability, breach terms, Rent Manager terms |
| 3 | Colz Electric | CRM and dispatch | NDA → discovery SOW → MSA + SOW + DPA | Yes, likely (customers; possibly employee location) | Employee-location data, CASL referral, DPA roles |
| 4 | Transformer Exteriors | SUMMITOS **discovery only** | NDA → **paid discovery/requirements SOW** (NOT the SUMMITOS Pilot Agreement) | Must be none in SUMMITOS | No pilot/conversion commitment, mock-data disclosures, demo representations |
| 5 | Renova Homes | Systems assessment | Mutual NDA + assessment SOW (signed together) | Possible incidental exposure | Advisory-only disclaimer, liability cap, incidental-PI handling |
| 6 | EGM Drywall | Multi-office assessment (HQ Edmonton) | Mutual NDA + assessment SOW (+ site-visit/travel terms); DPA if PI accessed | Possible incidental exposure | Governing law, out-of-Alberta offices (other privacy law/PIPEDA), site safety/insurance |

---

## 1. Core Fabrication — configurator to work-order integration

**Structure (order):** (1) Mutual NDA before any drawings, pricing or configurator data are shared; (2) paid discovery SOW to map the configurator, its API, work-order system and data fields; (3) MSA + integration SOW for the build (Change Orders and Acceptance Certificate under the MSA); (4) DPA only if personal information flows through NEXORA-controlled systems (UNKNOWN).

**Reasoning:** The main asset at risk is confidential technical and commercial information plus IP ownership of integration code. Discovery reduces scope risk because API capability and vendor terms are unknown. An MSA suits likely follow-on work (maintenance, further integrations) — ASSUMPTION.

**Key clauses:** confidentiality covering drawings, BOMs, pricing and margins; IP: client owns custom deliverables on full payment (or licence — CEO/counsel decision) while NEXORA retains pre-existing tools, libraries and know-how with a licence to the client; third-party dependency clause (configurator vendor API changes, rate limits, outages outside NEXORA's control); client warrants it has the right to authorise NEXORA's API access under the vendor's terms; credentials handling; acceptance testing with defined test data; change orders; no warranty of vendor performance; liability cap [UNKNOWN].

**Data considerations:** drawings and pricing are trade secrets/confidential business information (not personal information). Customer names/contacts on quotes or work orders may be personal information — UNKNOWN. Use test/sanitised data where possible; return/destroy at end.

**UNKNOWNs:** configurator vendor identity, its API availability and terms (including whether third-party integrators are permitted); work-order system; whether NEXORA hosts any middleware; whether customer PI is in scope; IP preference of client.

**REQUIRES_LICENSED_COUNSEL:** IP assignment vs licence wording and moral-rights waiver (Copyright Act — sections UNVERIFIED); interaction with configurator vendor licence/API terms; liability cap and exclusions; trade-secret protection adequacy of the NDA.

---

## 2. AspirePeak — Rent Manager workflows

**Structure (order):** (1) Mutual NDA; (2) paid discovery SOW scoped to process mapping **without live tenant/owner data**, or with a written interim data-handling clause if access is unavoidable; (3) MSA + workflow SOW + **DPA** before any production Rent Manager access.

**Reasoning:** Rent Manager workflows will very likely touch tenant and owner personal information (names, contacts, leases, payment/arrears data). A DPA is warranted. Role is unclear: AspirePeak may be the organisation in control, or may act for property owners or condo corporations (UNKNOWN) — that affects who must authorise processing and who receives breach notice.

**Key clauses:** DPA: instructions-only processing, purpose limitation, safeguards, subprocessors, data location [UNKNOWN], breach notification to client, return/deletion, staff confidentiality, cooperation with access requests; client warranty of authority (including from owners/condo corporations if applicable); Rent Manager access via client-provisioned, least-privilege accounts; client responsible for compliance with Rent Manager's terms; no changes to production data without written approval; backup/rollback responsibility; liability cap [UNKNOWN] with privacy carve-out decision.

**Data considerations:** tenant/owner PI, possibly financial data; condo owner records; minimise copies outside Rent Manager; no use of data to train or test unrelated tools; Alberta **Personal Information Protection Act (PIPA)** likely relevant (sections UNVERIFIED); **Condominium Property Act** (Alberta) may bear on condo records — UNVERIFIED, refer to counsel; PIPEDA only if cross-border/federal elements — UNVERIFIED.

**UNKNOWNs:** whether AspirePeak manages condos, rentals or both; its role vis-à-vis owners/condo corporations; Rent Manager edition, API/integration permissions and terms; where NEXORA would store any data; whether automations send messages to tenants (possible CASL).

**REQUIRES_LICENSED_COUNSEL:** controller/service-provider role allocation; PIPA/PIPEDA applicability and breach-notification obligations; whether owner/condo-corporation consent or authorisation is needed; privacy liability cap/indemnity; Rent Manager terms compliance.

---

## 3. Colz Electric — CRM and dispatch

**Structure (order):** NDA → paid discovery SOW → MSA + implementation SOW + DPA (if NEXORA accesses, hosts or migrates PI) → optional maintenance agreement.

**Reasoning:** CRM data is customer PI; dispatch may involve employee location/GPS data, which raises employee-privacy sensitivity. CRM may also send commercial electronic messages.

**Key clauses:** DPA as above; client responsibility for employee notice/consent and workplace policies on location tracking; client responsible for message content, consent records and unsubscribe handling if marketing is sent; third-party CRM/dispatch vendor terms; data migration accuracy and client sign-off; acceptance; change orders; no warranty for vendor uptime; liability cap [UNKNOWN].

**Data considerations:** customer names/addresses/service history; employee location and schedule data (PIPA employee-information rules — sections UNVERIFIED); CASL (**An Act to promote the efficiency and adaptability of the Canadian economy…**, "CASL" — sections UNVERIFIED) if marketing messages — **refer to Risk & Compliance**.

**UNKNOWNs:** CRM/dispatch products chosen; whether GPS tracking is in scope; whether marketing campaigns are in scope; data volumes and migration source; hosting location.

**REQUIRES_LICENSED_COUNSEL:** employee-location data obligations; CASL allocation of responsibility; DPA roles; liability cap.

---

## 4. Transformer Exteriors — SUMMITOS discovery (NOT a pilot)

**This is NOT the SUMMITOS Controlled Paid Pilot Agreement.** SUMMITOS is **not signable and not production-ready**: the Schedule A v3.1 pre-signing technical conditions are unmet, including **S1** (email ingestion routes to a hardcoded tenant) and **S2** (`settings.html` hardcoded tenant), plus unenforced tier entitlements, onboarding defects, no automatic 90-day billing termination and unverified data export (as reported by Argon).

**Structure (order):** Mutual NDA → **paid discovery/requirements SOW only**.

**Required SOW framing:**
- Deliverables limited to requirements, workflow mapping and a fit/gap report.
- **No production access**; **no customer data loaded into SUMMITOS** (any demo uses NEXORA mock data only).
- **No pilot commitment, no conversion, no subscription**, no obligation on either side to enter a later agreement; any future pilot needs a separate agreement once preconditions are met and the CEO approves.
- Any demo is **labelled with mock-data disclosures**; no representations about live supplier integrations, tier capabilities, seat limits, SLA, uptime, profitability, tenant isolation or export timelines.
- Discovery fee not credited toward a pilot unless the CEO decides otherwise (UNKNOWN; no pricing here).
- Confidentiality of client materials shared during discovery; return/destruction.

**Data considerations:** client documents shared for requirements (estimates, supplier lists) stay outside SUMMITOS; minimise PI.

**UNKNOWNs:** what materials client will share; whether client expects a pilot date; how discovery output would feed a later pilot.

**REQUIRES_LICENSED_COUNSEL:** wording of non-commitment and no-reliance clauses; demo/representation disclaimers given Competition Act misleading-representation risk (sections UNVERIFIED) and the earlier website-claims findings.

---

## 5. Renova Homes — systems assessment

**Structure:** Mutual NDA + assessment SOW, signed together before access.

**Reasoning:** Assessment is advisory; main risks are reliance on findings and incidental exposure to customer data.

**Key clauses:** findings are advisory recommendations only, not guarantees or legal/security certifications; client decides and implements; read-only/observed access; no copying of customer data; incidental-PI clause (confidentiality, no retention, deletion of screenshots); report ownership/licence; NEXORA retains methods; liability cap [UNKNOWN]; follow-on work under MSA + SOW if any.

**Data considerations:** possible viewing of homeowner/customer records; PIPA (sections UNVERIFIED) — if NEXORA will copy or process PI, add a DPA.

**UNKNOWNs:** systems in scope; access mode (on-site, screen share, credentials); whether any data extracts are needed.

**REQUIRES_LICENSED_COUNSEL:** advisory disclaimer and no-reliance wording; liability cap; whether incidental access needs DPA terms.

---

## 6. EGM Drywall — multi-office assessment (HQ Edmonton)

**Structure:** Mutual NDA + assessment SOW, with site-visit and travel terms; DPA added if PI is copied or processed.

**Reasoning:** Same advisory character as #5, plus multi-location logistics and possible extra-provincial privacy law.

**Key clauses:** office list and sites in scope; travel and expense terms (approval, reimbursement — amounts not set here); site safety and client site rules; insurance [UNKNOWN]; scheduling and access by local office contacts; advisory-only findings; incidental-PI handling; governing law and venue — **counsel placeholder** (Alberta likely, UNVERIFIED); liability cap [UNKNOWN].

**Data considerations:** if any offices are outside Alberta (UNKNOWN), other provincial privacy law (e.g. BC PIPA, Quebec private-sector law) or PIPEDA may apply — UNVERIFIED; employee data may be seen during assessment.

**UNKNOWNs:** number and location of offices; whether any are outside Alberta; systems in scope; whether site visits involve active construction sites.

**REQUIRES_LICENSED_COUNSEL:** governing law/venue; extra-provincial privacy obligations; site-visit liability and insurance; liability cap.

---

## Cross-cutting items for licensed counsel (REQUIRES_LICENSED_COUNSEL)
1. **Liability caps and exclusions** — amount/basis UNKNOWN; carve-outs for confidentiality, privacy breach, IP infringement; enforceability analysis (Tercon framework, per earlier research).
2. **IP** — assignment vs licence of custom deliverables; retained pre-existing tools; moral-rights waivers; third-party/open-source components.
3. **DPA roles** — organisation in control vs service provider under PIPA/PIPEDA (sections UNVERIFIED); AspirePeak multi-party role question; breach notification flow.
4. **Governing law and venue** — Alberta placeholder; extra-provincial clients/offices.
5. Third-party platform terms (configurator vendor, Rent Manager, CRM/dispatch vendors) and client authorisation warranties.
6. Advisory/no-reliance and demo disclaimers (Renova, EGM, Transformer).
7. Approval of all DRAFT_ONLY templates before use.

## Items for Risk & Compliance
1. CASL exposure if Colz (or AspirePeak) automations send messages.
2. Employee location/dispatch data handling (Colz).
3. Tenant/owner/condo data handling and minimisation (AspirePeak).
4. Confirm no customer data enters SUMMITOS and demo mock-data labelling (Transformer); S1/S2 status.
5. Data location, subprocessors and credential-handling standards for all engagements.
6. Out-of-Alberta office privacy check (EGM).
7. Confirm sales materials don't repeat unverified SUMMITOS claims.

## CEO decisions needed
- Whether discovery fees credit toward later work (no pricing set here).
- Default IP position (assignment vs licence).
- Liability cap policy to propose to counsel.
- Whether to proceed with any engagement before templates are counsel-reviewed.

*DRAFT — NOT LEGALLY APPROVED. Not legal advice. No agreement is formed by this document.*
