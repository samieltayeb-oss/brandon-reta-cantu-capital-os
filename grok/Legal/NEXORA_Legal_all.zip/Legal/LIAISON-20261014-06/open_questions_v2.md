# LIAISON-20261014-06 — Open Questions v2 (SUMMITOS Controlled Paid Pilot Agreement)
**DRAFT — NOT LEGALLY APPROVED.** Internal CEO review only. Not legal advice. Status: DRAFT_ONLY.
Numbering kept from v1. New questions start at 32. Tally: **32 open** (25 v1 unchanged, 3 v1 partially answered, 8a split from closed Q8, 3 new) · **3 closed**.

## Closed
- ~~1. Tier names~~ — CLOSED by CEO direction: Foundation Pilot / Live Intelligence Pilot / Enterprise Pilot. (Website still says Core/Pro: see 13.)
- ~~3. End-of-pilot model~~ — CLOSED by CEO direction: pilot ends after 90 days; no auto-conversion; continuation only by affirmative opt-in.
- ~~8. Do onboarding fees apply?~~ — CLOSED by CEO direction: quoted separately, explicitly approved, never automatic. (Amounts stay open as 8a.)

## A. CEO decisions (open)
2. *(Partially answered — CEO: 90 days.)* Remaining: Pilot Term start trigger (signature, Acceptance, onboarding completion, go-live).
4. Cancellation notice period/method/effective date; refunds and proration. **UNRESOLVED per CEO direction.**
5. *(Partially answered — CEO: monthly in advance, starting after Acceptance + authorized onboarding + payment arrangements.)* Remaining: payment method, invoice due date, late interest, suspension; who "authorizes" onboarding and payment arrangements.
6. Seat limits per tier — pending Argon verification (entitlement enforcement).
7. Modules/features per tier — pending Argon verification (implemented features, operational readiness).
8a. Onboarding fee amounts (public amounts not approved).
9. *(Partially answered — CEO: Enterprise custom, by agreement.)* Remaining: form of Enterprise order document and scope.
10. Support channels, hours, any response commitment.
11. Feedback obligations; reference/logo rights.
12. Pilot customer count and eligibility.
13. Fix website claims before pilots (profitability, multi-tenancy, isolation, SLA, Core/Pro names, "automatic renewal"/"cancel anytime"). Now a direct conflict with the CEO no-auto-conversion direction.
14. NEXORA signatory.
15. Data export window and format. **UNRESOLVED per CEO direction.**
16. Extra seat/usage fees (depends on 6).

## B. Counsel decisions — REQUIRES LICENSED COUNSEL (open)
17. Liability cap and carve-outs. **UNRESOLVED.**
18. Consequential damages exclusion scope. **UNRESOLVED.**
19. Indemnities.
20. IP: outputs, de-identified data, feedback, SFL formulas. **UNRESOLVED.**
21. Privacy roles (PIPA s.5(2); PIPEDA cl.4.1.3); DPA. **UNRESOLVED.**
22. Data residency and PIPA s.13.1 / s.6(2) notice (citations now verified, V3); hosting countries pending Argon D1.
23. Subprocessor list and change notice (Argon D2).
24. Breach terms. Citations updated (V4, V5); PIPA individual-notice regulation and PIPEDA other-organizations subsection number still UNVERIFIED.
25. CASL sender characterization (citations updated, V6).
26. Governing law/venue/dispute resolution.
27. Taxes. **UNRESOLVED; UNVERIFIED (V8)** — accountant.
28. Warranty disclaimer enforceability.
29. Payroll/OHS/WCB reliance disclaimer.
30. E-signature/counterparts. ETA citation now verified (V7, ss.8, 16, 27); wording still for counsel.
31. Survival list; order of precedence.

## New (v2)
32. Alignment: 90-day term vs monthly-in-advance billing gives a partial third/fourth cycle. How is the final period charged? (ties to 4)
33. Opt-in mechanics: form of the follow-on agreement, and Customer Data continuity if Customer opts in vs export/deletion if not (ties to 15).
34. Live self-serve Stripe checkout and "automatic renewal" site copy (compliance E2, E9) conflict with the reviewed-onboarding, no-auto-conversion model. Should self-serve be disabled before any pilot? (CEO; route to website/billing owner — not touched by Legal Desk)
