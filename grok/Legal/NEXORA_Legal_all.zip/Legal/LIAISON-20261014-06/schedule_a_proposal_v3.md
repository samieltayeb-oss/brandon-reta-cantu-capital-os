# DRAFT — NOT LEGALLY APPROVED
**SUMMITOS Controlled Paid Pilot — Schedule A Proposal (v3)** · Task LIAISON-20261014-06 · Prepared 2026-10-14 by NEXORA Legal Counsel Desk (AI drafting assistant, not a lawyer). Internal CEO review only. Not legal advice. Not for customers. Status: DRAFT_ONLY. `draft_agreement_v2.md` is unchanged.

**Evidence basis:** Argon's technical findings, as the CEO reported them through NEXORA Liaison. These are CEO-reported technical facts. Legal Counsel Desk hasn't independently verified them. No finding says a capability is production-verified, so nothing below is rated PRODUCTION-VERIFIED. Public website observations in earlier files predate the Gate A deployment and haven't been re-verified.

## 1. Findings mapped to v2 and Schedule A

| # | Argon finding (CEO-reported) | v2 section / Sch. A item | Contractual implication | Status | Reasoning |
|---|---|---|---|---|---|
| F1 | Core construction ERP modules deployed | §2.3; Sch. A "Features/modules" | Can list core modules in Sch. A as "pilot access", with the module list named specifically [UNKNOWN — CEO TO CONFIRM: which modules]. No fitness or performance promise (§11.3). | PARTIAL | "Deployed" isn't production-verified, and the module list and their completeness weren't stated. |
| F2 | CSV/Excel supplier price import implemented | §2.4; Sch. A | Describe the feature as customer-initiated file import. Customer stays responsible for data accuracy (§2.4, §11.4). | PARTIAL | "Implemented" isn't production-verified, and file-size and format limits are unknown. |
| F3 | Live third-party supplier integrations NOT verified; several connectors use mock data | §2.4; §11.4; Sch. A | Don't promise any live integration. Connectors must be excluded, or disclosed as demo/mock data and not relied on for pricing. Tier name "Live Intelligence" is at risk (see §2). Ties to the misleading-representation risk (Competition Act s.52/s.74.01, initial assessment). | DEMO-ONLY (mock connectors); UNVERIFIED (live integrations) | Mock data is demo-only by definition, and no live connector has been verified. |
| F4 | Tier entitlements and seat limits NOT enforced server-side | §2.3; §3.1; §3.6; §9 (authorized seats); Sch. A | Seat and feature limits can only be contractual (honour-based, with manual monitoring) until they're enforced. Tier differentiation can't be technically guaranteed. | UNVERIFIED | No enforcement exists. Any limit is a paper term only. |
| F5 | New-tenant onboarding has unresolved table-reference mismatches | §2.5 (start trigger); §3 (billing starts after acceptance/onboarding); Sch. A Pilot Start Date / Onboarding | No automated onboarding promise. Billing must not start until onboarding has been manually confirmed complete. Integrity risk to customer data at set-up. | PARTIAL (defective) | The onboarding path exists but has known defects. It's not ready for production. |
| F6 | Automatic Stripe subscription termination at 90 days NOT implemented | §2.5; §4; §13.1; §3 billing | Risk of charging after the pilot ends, contrary to the CEO's "no automatic conversion" position. A documented manual cancellation control is required. Possible refund exposure (§3.5/§13.5 UNRESOLVED). Consumer and payment rules: compliance check (Risk & Compliance). | UNVERIFIED (not implemented) | The required control is absent. |
| F7 | Full-tenant data export and offboarding need further verification | §8 (customer data); §13.6 data return; §6 (PIPA retention) | Don't commit to an export deadline, format or deletion timeline. §13.6 stays UNRESOLVED. | UNVERIFIED | Argon explicitly says it needs verification. |
| F8 | PDF extraction limited; OCR for scanned documents not fully configured | §2.3; §11.3/§11.4; Sch. A | If listed at all, describe document extraction as "limited / best-effort, scanned documents not supported" [wording UNKNOWN — CEO TO CONFIRM]. Disclose the limits. | PARTIAL | Exists in limited form. OCR is incomplete. |
| F9 | Supplier email-ingestion route has hardcoded tenant identifier | §6 (privacy/security); §7 confidentiality; §9(d); §2.4 | **Potential cross-tenant data exposure.** Inconsistent with any confidentiality and safeguarding commitment (PIPA/PIPEDA safeguards, Risk & Compliance to confirm). Must be fixed, or the feature disabled, before signing. **FLAG → Risk & Compliance Analyst; possible privacy-incident assessment REQUIRES_LICENSED_COUNSEL if any real customer data has passed through this route.** | UNVERIFIED (security defect) | A known defect. The feature can't be treated as safe for customer data. |

**Status counts (9 findings):** PRODUCTION-VERIFIED 0 · PARTIAL 4 (F1, F2, F5, F8) · DEMO-ONLY 1 (F3, mock connectors) · UNVERIFIED 5 (F3 live integrations, F4, F6, F7, F9). F3 is counted twice because it has two parts.

## 2. Proposed conservative tier descriptions (for Sch. A)

Common to all tiers: 90-day controlled pilot; no automatic conversion; billed monthly in advance only after acceptance and authorized onboarding/payment arrangements; onboarding quoted separately; no SLA, uptime or response-time commitment (§10.2); no guarantee of profitability, accuracy or results (§11.4); no live supplier integrations; no data-export deadline (§13.6 UNRESOLVED); onboarding is NEXORA-assisted/manual and isn't automated.

- **Foundation Pilot — CAD $299/month.** Pilot access to the core SUMMITOS construction ERP modules [UNKNOWN — CEO TO CONFIRM: module list] and customer-initiated CSV/Excel supplier price import. Limited PDF extraction (scanned documents/OCR not supported) [UNKNOWN — CEO TO CONFIRM: include or exclude]. Seats: PROPOSED 10 (see §3).
- **Live Intelligence Pilot — CAD $599/month.** Everything in Foundation, plus [UNKNOWN — CEO TO CONFIRM: differentiating features; none is supported by Argon's findings as a verified, distinct capability]. Supplier connectors, if shown at all, are demonstration only and use sample/mock data that must not be relied on for pricing. Seats: PROPOSED 25 (see §3).
  - **CEO NAMING DECISION / disclosure:** "Live Intelligence" may imply live supplier data or integrations, which aren't verified (F3). Either rename it, or add this disclosure: *"'Live Intelligence' is a plan name only. It does not include live third-party supplier integrations during the pilot unless they are listed and confirmed in writing in this Schedule A."* Misleading-representation risk; Risk & Compliance to review.
- **Enterprise Pilot — custom, by agreement.** Scope, modules, seats and fees set out in a separately approved order form [UNKNOWN — CEO TO CONFIRM]. Subject to the same verification limits. No capability beyond F1/F2/F8 may be listed until it's verified.

Sch. A must also note: *"Plan limits are contractual. They aren't currently enforced technically, and NEXORA monitors them manually [UNKNOWN — CEO TO CONFIRM: method]."*

## 3. Seat limits — PROPOSED ONLY
- 10 seats (Foundation) and 25 seats (Live Intelligence) are **PROPOSED contractual limits only**, pending CEO approval and server-side enforcement (F4). Enterprise: [UNKNOWN — CEO TO CONFIRM].
- **Source check on the pairing:** v2 contains no seat numbers. `changes_v2.md` records that "public 10/25/unlimited seats" were removed. v1 and `open_questions.md` say only "Public pages say 10 and 25", which isn't CEO-confirmed. Those figures came from the pre-release public tiers ("Core"/"Pro"/unlimited), and **no file explicitly pairs 10 with Foundation or 25 with Live Intelligence.** The pairing used here (10 = Foundation, 25 = Live Intelligence) is inferred from the order and is **[UNCLEAR — CEO TO CONFIRM pairing]**.
- Extra-seat fees (§3.6): still UNKNOWN.

## 4. Technical preconditions before ANY paid pilot is signed
Each requires written confirmation from Argon, with evidence, and CEO sign-off:
1. **Email-ingestion tenant isolation fixed** (hardcoded tenant identifier removed and server-side tenant scoping verified), or the route disabled. Risk & Compliance review complete. Any past cross-tenant exposure assessed.
2. **Onboarding table-reference mismatches resolved** and a new-tenant onboarding tested end to end.
3. **90-day termination:** automatic Stripe cancellation implemented, **or** a documented manual control (owner, calendar trigger, verification step, refund procedure) so no charge occurs after the Pilot Term.
4. **Full-tenant data export and offboarding verified** (format, completeness, deletion) before any export or deletion term is drafted.
5. **Entitlements and seat limits** enforced server-side, **or** a documented manual monitoring process is in place and the contract says the limits are contractual.
6. **Mock connector data** disabled for pilot tenants, or clearly labelled as demo data in the UI and in Sch. A.
7. **PDF/OCR limits** disclosed in Sch. A and customer-facing documentation.
8. Public website claims (guaranteed profitability, 4-hour SLA, 24/7, automatic renewal, self-serve checkout) re-verified post-Gate A and aligned with this pilot model (carried over from the initial assessment).
9. Billing doesn't start until acceptance and onboarding are confirmed (CEO direction). Self-serve checkout mustn't bypass a signed agreement.

## 5. Remaining decisions
**CEO (commercial):** module list per tier; what distinguishes Live Intelligence from Foundation; Live Intelligence rename vs. disclosure; seat figures and their pairing; manual-monitoring method for limits; Enterprise order-form scope; whether to include document extraction at all; extra-seat fees; refund/proration if billing errors occur after day 90; go/no-go on each precondition in §4.

**REQUIRES_LICENSED_COUNSEL:** limitation of liability, exclusions and indemnities (§12); warranty disclaimer wording and enforceability in Alberta (§11); privacy roles, residency, subprocessors and breach obligations, including any assessment of the email-ingestion defect (§6); data return, deletion and retention terms (§13.6); IP and customer-data ownership (§8); adequacy of the demo/mock-data and plan-name disclosures under the Competition Act; governing law (§15). Taxes: accountant verification (§5).

---
> **DRAFT — NOT LEGALLY APPROVED. Internal CEO review only. Not legal advice. Not for distribution.** Next: Risk & Compliance Analyst review.
