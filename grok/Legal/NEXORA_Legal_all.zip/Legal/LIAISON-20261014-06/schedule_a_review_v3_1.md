# Schedule A v3.1 Review: Misleading or Unsupported Contractual Claims
**Task:** LIAISON-20261014-06 (Schedule A v3.1 review) · **Reviewer:** NEXORA Risk & Compliance Analyst (external advisory) · **Date:** 2026-10-14 (MT)
**Reviewed:** `schedule_a_proposal_v3_1.md` (v3.1) against Argon's full report (`.../attachments/cc67c8b3...e42.md`, "Argon"). Context: `compliance_review.md`, `compliance_review_v2.md`. Partial `schedule_a_review.md` (on hold) was ignored.
**Status:** REVIEW_SUBMITTED. Advisory research, **not legal advice**. No compliance conclusion is made. No file other than this one was edited (plus a text extraction `sources/C-34.txt` made from the existing `sources/C-34.html`). Production was not touched. No new agreement version was created and no work was assigned.

**Labels:** LEGAL REQUIREMENT = statutory text verified in `sources/`; INTERPRETATION = my reading, needs counsel; RECOMMENDATION = suggestion only. **Buckets:** (A) confirmed legal requirements · (B) counsel · (C) CEO commercial · (D) Argon technical facts (listed only) · (E) unsupported/inconsistent claims.

**Sources verified (official, local copies in `sources/`):**
| Instrument | Official URL | Local file | Currency shown |
|---|---|---|---|
| Competition Act, R.S.C. 1985, c. C-34 | https://laws-lois.justice.gc.ca/eng/acts/C-34/ | `sources/C-34.html` (+ `C-34.txt`) | "current to 2026-09-21" |
| PIPEDA, S.C. 2000, c. 5 | https://laws-lois.justice.gc.ca/eng/acts/P-8.6/ | `sources/P-8.6.html/.txt` | per file |
| Alberta PIPA, SA 2003, c P-6.5 | https://kings-printer.alberta.ca/documents/Acts/P06P5.pdf | `sources/P06P5.pdf/.txt` | "Current as of September 1, 2025" |
| Alberta PIPA Regulation, AR 366/2003 | Alberta King's Printer | `sources/PIPAReg.pdf` | per file |

---

## 1. Table of all 23 technical findings, checked against Argon (CEO addition 1)
"Check" means whether v3.1's row matches Argon's report text.

| # | Capability | Argon's classification (as in Argon) | Argon location | v3.1 accurate? |
|---|---|---|---|---|
| A1 | Estimating & Quotes | PRODUCTION_VERIFIED | §1.1 | Yes |
| A2 | Jobs, Work Orders & Scheduling | PRODUCTION_VERIFIED | §1.1 | Yes |
| A3 | Clients/CRM & Client Portal | PRODUCTION_VERIFIED | §1.1 | Yes |
| A4 | Invoicing, Payments, Expenses & Tax | PRODUCTION_VERIFIED | §1.1 | Yes |
| A5 | Crew, Time, Payroll & Safety/OHS | PRODUCTION_VERIFIED | §1.1; matrix "payroll calculation worksheets" | Yes |
| A6 | Materials, Inventory & POs | PRODUCTION_VERIFIED | §1.1; matrix enforcement "Contractual (no server-side tier gate deployed)" | Yes |
| A7 | Reporting | PRODUCTION_VERIFIED | §1.1 | Yes |
| A8 | BOM/Assemblies/Rules/SFL | PRODUCTION_VERIFIED | §1.2 | Yes |
| A9 | Price Alerts & Cost Drift Analyzer | PARTIAL | §1.2 ("`0::numeric AS estimated_margin_delta`") | Yes (v3.1 omits Argon's word "accurately" for cost deltas; conservative) |
| A10 | `has_entitlement()` | SOURCE_IMPLEMENTED (helper only, NOT enforced) | §1.3 | Yes, but see E6: v3.1 does not record the helper's own capability mapping |
| A11 | `seed_tenant_defaults` | PRODUCTION_VERIFIED | §1.4 | Yes |
| A12 | Onboarding & invitations | PARTIAL (Admin-Assisted) | §1.4 | Yes |
| A13 | Seat-limit enforcement | NONE (UNVERIFIED / Not Implemented) | §2 | Yes |
| A14 | Checkout billing | PARTIAL / Disabled by Gate A | §3 | Yes |
| A15 | Supplier CSV/Excel import | PRODUCTION_VERIFIED | §4.1 | Yes |
| A16 | PDF extraction | PARTIAL (OCR SOURCE_IMPLEMENTED, keys absent) | §4.2 | Yes |
| A17 | Email ingestion | PARTIAL | §4.2 | Yes |
| A18 | Sync dispatcher | PARTIAL | §4.3 | Yes |
| A19 | Roofmart/RONA/ABC/Convoy | DEMO_ONLY | §4.4 | Yes (SKUs/prices match) |
| A20 | Home Depot connector | PARTIAL | §4.4 | Yes |
| A21 | Self-serve exports | PARTIAL (§5 heading) / PRODUCTION_VERIFIED (summary) | §5, summary | Yes, dual label correctly recorded |
| A22 | Full-tenant export/offboarding | UNVERIFIED / Manual Admin (§5); PARTIAL (matrix, summary) | §5, §6 | Yes, dual label recorded. Minor: v3.1's count line places A22 under PARTIAL while N1 treats it as UNVERIFIED for contract purposes. Not misleading, but the count should footnote this. |
| A23 | 90-day term / non-auto conversion as process | PARTIAL | §6 matrix row; §3 recommendation | Yes |

Result: no misquoted classification found. Two minor presentation points (A10 mapping, A22 count) are in (E).

---

## 2. Reconciliation of Argon's 3 matrix vs §7 contradictions (CEO addition 2; focus point 1)

| Item | Argon §6 matrix (exact quote, Foundation column) | Argon §7 (exact quote) | Also: `has_entitlement()` source mapping (Argon §1.3) | v3.1 handling | Conservative? |
|---|---|---|---|---|---|
| BOM/SFL | "**Dynamic BOM, Assemblies, Rules Engine & SFL** \| Included (UI accessible)" | Live Intelligence "plus dynamic Bill of Materials (BOM) assemblies, Summit Formula Language (`SFL`) rules" (Foundation text omits it) | not named; `enterprise` → adds "`advanced_rule_automation`" | Foundation: [UNKNOWN — CEO TO CONFIRM]; LI: listed "[subject to CEO decision N2]"; N2 and §8 Q1 | **Yes.** Not promised in Foundation; flagged for CEO. |
| Inventory/PO | "**Materials, Inventory & Purchase Orders** \| Included (UI accessible)" | Live Intelligence "plus ... purchase order and inventory tracking" | `pro` → adds "`purchasing`"; `enterprise` → adds "`inventory`" | Same as above | **Mostly.** But v3.1 lists A6 among the "Core modules Argon verified" (§2(a)) without the N2 caveat there. And it does not note that the source helper puts inventory in **Enterprise**, which is a third allocation. |
| CSV import | "**Supplier Price Import (CSV / Excel) & Staging Approval** \| Manual catalog entry + CSV upload" | Live Intelligence "plus ... CSV/Excel supplier price-sheet import with staging approval workflows" | `pro` → adds "`supplier_intelligence`" (meaning undefined) | LI: listed "subject to CEO decision N2"; Foundation UNKNOWN | **Yes.** |

### Competition Act analysis (focus 1)
**(A) A1. LEGAL REQUIREMENT.** Competition Act s.52(1) (https://laws-lois.justice.gc.ca/eng/acts/C-34/, current to 2026-09-21): "No person shall, for the purpose of promoting, directly or indirectly, the supply or use of a product or ... any business interest, by any means whatever, knowingly or recklessly make a representation to the public that is false or misleading in a material respect." s.52(1.1)(a): it is not necessary to prove that "any person was deceived or misled". s.52(4): "the general impression conveyed by a representation as well as its literal meaning shall be taken into account".
**(A) A2. LEGAL REQUIREMENT.** s.74.01(1)(a) (reviewable conduct, civil): "makes a representation to the public that is false or misleading in a material respect". s.74.01(1)(b): "makes a representation to the public in the form of a statement, warranty or guarantee of the performance, efficacy or length of life of a product that is not based on an adequate and proper test thereof, the proof of which lies on the person making the representation". s.74.01(1)(c): a purported warranty/guarantee or promise "to repeat or continue a service until it has achieved a specified result" if "materially misleading or if there is no reasonable prospect that it will be carried out". s.74.03(5): general impression and literal meaning taken into account under 74.01. s.52(1.3) (drip pricing): a price "not attainable due to fixed obligatory charges or fees" is false or misleading.
**(B) B1. INTERPRETATION, for counsel.** Whether a Schedule A signed in a negotiated B2B pilot is a "representation to the public". The same tier wording reused on the website or in sales collateral more clearly would be. Counsel to decide scope.
**(B) B2. INTERPRETATION.** Two paid tiers at CAD $299 and $599, where Argon reports "All authenticated users of an active tenant have access to all deployed modules", could create a general impression (s.52(4)/74.03(5)) that the extra $300 buys technically distinct features. Disclosing that limits are contractual (v3.1 "Common to all tiers") likely reduces this risk. Counsel to assess sufficiency.
**(B) B3. INTERPRETATION.** The 74.01(1)(b) testing requirement. Argon verified *deployment* ("Deployed in production ... with multi-tenant RLS"). v3.1 correctly notes Argon "does not address usability testing, performance, data accuracy, or real-customer end-to-end workflow testing". Any performance or efficacy wording (e.g., "cost-drift impact analysis", "accurately calculates") would, in my reading, need an adequate and proper test on file. Whether Argon's code inspection counts as such a test is for counsel. The margin delta returns 0, so any "margin analysis" wording would lack support (v3.1 flag 6 handles this).
**(B) B4. INTERPRETATION.** The name "Live Intelligence" while A19 is DEMO_ONLY and no live feed exists. The general-impression risk is noted in v3.1 §3. Counsel to decide whether a disclosure suffices or a rename is needed.
**(B) B5. INTERPRETATION.** Drip pricing (s.52(1.3)). Argon's matrix pairs "CAD $299/mo + onboarding". If onboarding were in practice obligatory, advertising "$299/month" alone may raise s.52(1.3) issues. v3.1 says onboarding applies "only if quoted separately and approved". Counsel to confirm.
**(C) C1. RECOMMENDATION.** CEO to choose one allocation for the three items (matrix, §7, or the helper mapping), then have Argon confirm that the chosen wording matches reality.

---

## 3. Contractual tier limits vs server-side enforcement (CEO addition 3)
**(E) E1. INTERPRETATION. Confirmed separated.** v3.1 "Common to all tiers": "Plan limits are contractual only and not technically enforced"; §2(c) "all tier boundaries are unenforced"; seats "PROPOSED 10 — not approved, not enforced"; §7 cond. 8. Residual inconsistency: §3 LI says "nothing prevents Foundation users from reaching them", yet still lists them as LI "plus" features. This is accurate, but it is the B2 risk.
**(E) E2.** §2(b) says "Every differentiating feature Argon identifies is PARTIAL". Under Argon §7, BOM/SFL and CSV import (PRODUCTION_VERIFIED) are also differentiators. The sentence is true only for matrix-based differentiators. RECOMMENDATION: qualify it "on Argon's matrix".

## 4. 30-day export and tenant-isolation wording (CEO addition 4)
**(E) E3. Confirmed: no 30-day export deadline adopted** (N3; "No data-export deadline"; §8 Q6).
**(E) E4. Confirmed: no tenant-isolation guarantee adopted** (N4, S5). Gap: N4 cites only Argon §7's "tenant-isolated workspace". Argon's matrix also uses "within an isolated tenant workspace" (core estimating row). RECOMMENDATION: extend N4 to the matrix wording so it is not copied later.
**(E) E5.** v3.1 §2(a) states that the core modules are deployed "per Argon". This is properly attributed, with no independent verification claimed.
**(E) E6.** v3.1 does not record Argon §1.3's helper mapping (`core` → estimating, crm, invoicing; `pro` → supplier_intelligence, purchasing, analytics; `enterprise` → inventory, advanced_rule_automation, api_access). This is a third tier model inconsistent with both the matrix and §7, and with the site's "Core/Pro" names already noted in the earlier review. RECOMMENDATION: add it to N2.
**(E) E7.** Legacy in-app pricing ($4,900 / $14,900 / $24,900) conflicts with the pilot pricing. v3.1 flag 1 and cond. 9 handle it.

---

## 5. PRIORITY technical risk: S1 and S2 hardcoded tenant ID (CEO addition 5; focus 3)
**PRIORITY.** Argon: `supplier-email-ingest` "hardcodes `DEFAULT_TENANT_ID` (`a1b2c3d4-0000-0000-0000-000000000001`) instead of resolving tenant per recipient address", and `settings.html` "hardcodes `TENANT = 'a1b2c3d4-0000-0000-0000-000000000001'`". **No conclusion is made that any breach or incident occurred.**

**(D) Facts for Argon to establish (listed only; I did not investigate):**
- D1. Whether the email ingest endpoint has received any inbound mail and attachments in production, and since when.
- D2. Which tenant owns `a1b2c3d4-…0001` (demo/internal or a real customer), and whether more than one tenant exists in production.
- D3. Whether ingested attachments contained personal information (e.g., names or contact details of supplier staff or customers) or only price data.
- D4. Whether `settings.html` reads, writes, or both reach the fixed tenant for every user, and whether RLS blocks that in practice.
- D5. Whether any user outside tenant …0001 could view or alter its data, and whether access logs exist to show it.
- D6. Whether the issue can be disabled or fixed before any pilot (v3.1 cond. 1–2).

**(A) Verified text that would apply ONLY IF real personal information was affected (conditional):**
- A3. LEGAL REQUIREMENT, Alberta PIPA s.34.1(1) (`sources/P06P5.txt`, current as of 2025-09-01): "An organization having personal information under its control must, without unreasonable delay, provide notice to the Commissioner of any incident involving the loss of or unauthorized access to or disclosure of the personal information where a reasonable person would consider that there exists a real risk of significant harm to an individual as a result of the loss or unauthorized access or disclosure." s.34.1(2): the notice "must include the information prescribed by the regulations" (PIPA Reg. AR 366/2003 s.19, including "(d) an assessment of the risk of harm", "(e) an estimate of the number of individuals", "(h) the name of and contact information for a person who can answer"). s.37.1(1): "the Commissioner may require the organization to notify individuals"; Reg. s.19.1(1): such notification "must (a) be given directly to the individual". Related: s.34 duty to make "reasonable security arrangements against such risks as unauthorized access".
- A4. LEGAL REQUIREMENT, PIPEDA s.10.1(1): "An organization shall report to the Commissioner any breach of security safeguards involving personal information under its control if it is reasonable in the circumstances to believe that the breach creates a real risk of significant harm to an individual." s.10.1(2): "as soon as feasible after the organization determines that the breach has occurred". s.10.1(3): "an organization shall notify an individual ... if it is reasonable in the circumstances to believe that the breach creates a real risk of significant harm to the individual." s.10.2(1): an organization that notifies an individual under 10.1(3) "shall notify any other organization, a government institution or a part of a government institution of the breach if the notifying organization believes that the other organization ... may be able to reduce the risk of harm". s.10.3(1): "An organization shall, in accordance with any prescribed requirements, keep and maintain a record of **every** breach of security safeguards involving personal information under its control" (this applies regardless of RROSH); s.10.3(2): provide it to the Commissioner on request.

**(B) For counsel:**
- B6. INTERPRETATION. Whether any event occurred at all, and whether it is a PIPA "incident" or PIPEDA "breach of security safeguards".
- B7. INTERPRETATION. The real-risk-of-significant-harm assessment, if personal information is involved.
- B8. INTERPRETATION. Which regime applies. PIPA covers provincially regulated Alberta organizations; PIPEDA covers commercial activity and interprovincial flows. Possibly both, depending on facts.
- B9. INTERPRETATION. Who has "control" (NEXORA vs the pilot customer as controller, NEXORA as service provider), which affects who reports.
- B10. RECOMMENDATION. Whatever the outcome, record the assessment (supports s.10.3 if PIPEDA applies).

---

## 6. S4 Home Depot scraping (CEO addition 6; focus 4)
- **(B) B11. INTERPRETATION, counsel only, no conclusion.** Argon: `HomeDepotConnector` "attempts unauthenticated HTML scraping of `homedepot.ca` ... subject to retail bot-protection (`403 Access Denied`)". For counsel: review of homedepot.ca website terms of use, the legal significance of circumventing or encountering bot protection, and any other legal issues counsel identifies. I did not review the retailer's terms and draw no conclusion.
- **(D) D7.** Argon to confirm whether the scraper has run in production, how often, and whether it is reachable by pilot tenants.
- **(E) E8.** Any wording describing Home Depot pricing as an integration would be unsupported (A20 PARTIAL). v3.1 excludes "web-scraped supplier feed".

---

## 7. The 10 pre-signing conditions (focus 2)
**(E) E9. INTERPRETATION.** Conditions 1–10 track Argon's unresolved items 1–6 and are generally clear. Clarity gaps:
- Cond. 1: "Any past exposure assessed" names no assessor and no standard. RECOMMENDATION: "assessed by Argon (facts, D1–D6) and by counsel (legal, B6–B9), documented".
- Cond. 2: has no past-exposure assessment, unlike cond. 1. RECOMMENDATION: add it.
- Cond. 4: "guarantees no charge after 90 days" is an internal control target. Keep it out of customer text.
- Cond. 6: covers the mocks and "Live-search UI" but does not name the Home Depot scraper (S4).

**(C)/(D) Missing, given Argon (RECOMMENDATION):**
- M1 (D). Disable or hide `supplier-web-fetch` for pilot tenants pending counsel (S4).
- M2 (D). Argon to reconcile N1, N2 and the `has_entitlement()` mapping (E6) in writing.
- M3 (C). Final Schedule A tier wording re-checked against Argon's evidence before signing (Competition Act B2–B4).
- M4 (D). PDF OCR placeholder: confirm what a user sees for scanned PDFs, so no fake output is shown (as with the mocks).
- M5 (D). Decide whether the RC20 migrations stay unapplied during pilots, since checkout depends on them (A14).
- M6 (B). Privacy notice, cross-border/service-provider disclosure and CASL items still open from earlier reviews (v2 §6).

---

## 8. Unresolved risks
1. S1/S2 hardcoded tenant: facts unknown (D1–D6); legal consequences conditional (A3–A4, B6–B10). **PRIORITY.**
2. Tier differentiation unenforced and inconsistent across three Argon models (B2, E6). Misleading-representation risk (B1–B4).
3. "Live Intelligence" name vs no live data (B4).
4. Mock connectors and scraper reachable by users (A19, A20, S4).
5. Billing: no automated 90-day stop; manual control not yet tested (A14, A23).
6. Export/offboarding/deletion unverified (A22).
7. Hosting region, subprocessors and security unknown (v2 §6).
8. Legacy in-app pricing (E7). Margin delta 0 (A9).
9. Still unresolved from v2: cancellation notice, refunds and proration, liability, privacy, taxes, IP and data return.

## 9. Exact CEO decisions needed (C)
1. Choose the tier allocation of BOM/SFL, materials/inventory/PO and CSV import: Argon matrix (Foundation), Argon §7 (Live Intelligence) or the helper mapping (inventory = Enterprise).
2. Approve, change or reject seats 10 / 25 and the Enterprise seat basis.
3. Rename "Live Intelligence", or adopt the disclosure, subject to counsel (B4).
4. Include PDF extraction (beta) and the cost-drift analyzer (PARTIAL), or not.
5. Pilot billing method and the named owner of the 90-day stop.
6. Export/offboarding/deletion position (no deadline adopted).
7. Whether to direct Argon to establish D1–D7, and whether to refer S1/S2 and S4 to licensed counsel.
8. Whether any pilot may start before conditions 1–10 and M1–M6 are met.
9. Whether onboarding is ever mandatory (affects drip-pricing analysis, B5).
