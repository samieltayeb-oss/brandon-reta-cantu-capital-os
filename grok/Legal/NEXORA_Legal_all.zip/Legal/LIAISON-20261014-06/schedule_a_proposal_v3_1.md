# DRAFT — NOT LEGALLY APPROVED

**SUMMITOS Controlled Paid Pilot Agreement: Schedule A Proposal v3.1 (internal CEO review only)**
Task: LIAISON-20261014-06 · Prepared by: NEXORA Legal Counsel Desk (AI drafting assistant, not a lawyer) · Date: 2026-10-14
Supersedes: schedule_a_proposal_v3.md (kept unchanged). Base agreement: draft_agreement_v2.md (unchanged).
Evidence source: Argon, *SUMMITOS — Technical Tier & Pilot Readiness Verification (Read-Only)*, supplied by the CEO through NEXORA Liaison. It replaces the earlier 9-point summary.

> **Evidence basis.** Every technical finding below is **Argon's** report, quoted or summarised with Argon's classification. NEXORA Legal Counsel Desk has done **no independent testing** of SUMMITOS, its database, code or billing. Classifications are Argon's and are not changed here. Where the Desk sees a tension, it is set out as a separate **Desk note**. Argon states `PRODUCTION_CHANGED = NO`. Website observations in earlier files predate the Gate A deployment and haven't been re-verified.
>
> Not legal advice. No term here is binding or offered to any customer. Unknowns are marked [UNKNOWN — CEO/COUNSEL TO CONFIRM: …].

---

## 0. CEO commercial decisions preserved (CEO_APPROVED_COMMERCIAL_POSITION)
- Pilot Term: **90 days**.
- **No automatic conversion or renewal.** The pilot ends after 90 days unless the customer affirmatively opts into a later written agreement or subscription.
- Billing: **monthly in advance**, starting only after Acceptance and authorized onboarding and payment arrangements.
- Onboarding fees: **only when quoted separately and explicitly approved.** No automatic onboarding charges.
- Pricing: Foundation Pilot CAD $299/month · Live Intelligence Pilot CAD $599/month · Enterprise Pilot custom, by agreement.
- Tier features and seat limits: **not approved.** This document only *proposes* them for CEO decision.

---

## 1. Argon findings register (Argon's classifications, unchanged)

| # | Capability | Argon classification | Argon's stated evidence | Argon's stated limitations |
|---|---|---|---|---|
| A1 | Estimating & Quotes | PRODUCTION_VERIFIED | Argon reports `estimates.html`, `estimates`, `estimate_line_items`, `estimate_versions`, `v_estimate_summary` deployed in production project `pmzvstvnraqsahpnkdoz` with multi-tenant RLS. | No tier gate (tenant RLS only). |
| A2 | Jobs, Work Orders & Scheduling | PRODUCTION_VERIFIED | Argon reports `jobs.html`, `work-orders.html`, `schedule.html` and tables `jobs`, `job_costs`, `work_orders`, `schedule_events` deployed with multi-tenant RLS. | No tier gate. |
| A3 | Clients/CRM & Client Portal | PRODUCTION_VERIFIED | Argon reports `clients.html`, `portal.html`, `portal_tokens` and token-scoped portal RPCs (get/approve/decline estimate, get invoice) deployed with multi-tenant RLS. | None stated beyond the token model. |
| A4 | Invoicing, Payments, Expenses & Tax | PRODUCTION_VERIFIED | Argon reports `invoices`, `invoice_line_items`, `payments`, `expenses`, `tax_rates` deployed with multi-tenant RLS. | None stated. |
| A5 | Crew, Time Tracking, Payroll & Safety/OHS | PRODUCTION_VERIFIED | Argon reports `crew.html`, `time-tracking.html`, `payroll.html`, `safety.html` deployed with multi-tenant RLS. Argon's matrix describes payroll as "payroll calculation worksheets". | No tier gate. |
| A6 | Materials, Inventory & Purchase Orders | PRODUCTION_VERIFIED | Argon reports `materials.html`, `inventory.html`, `purchase-orders.html` deployed with multi-tenant RLS. | Argon: "Contractual (no server-side tier gate deployed)". |
| A7 | Operational & Financial Reporting | PRODUCTION_VERIFIED | Argon reports `reports.html` and views `v_dashboard_kpis`, `v_monthly_revenue`, `v_job_profitability`, `v_invoice_aging`, `v_gst_summary` (Revenue, Invoice Aging, Expenses, Job Profit, GST/HST, WCB, Year-End, Collections). | None stated. |
| A8 | Dynamic BOM, Assemblies, Rules Engine & SFL | PRODUCTION_VERIFIED | Argon reports `bm_assemblies`, `bm_rules`, `bm_bom_runs`, `prc_generate_estimate_bom`, `prc_calculate_estimate`, `prc_evaluate_sfl` in production. | Argon: no server-side tier gate. |
| A9 | Price Alerts & Estimate Cost Drift Analyzer | PARTIAL | Argon reports it is deployed and calculates line-item and total material cost deltas on draft/open/internal estimates. | Argon reports `prc_analyze_price_impact` returns `0` for `estimated_margin_delta` ("margin recalculation deferred to manual confirmation"). Margin impact isn't calculated. |
| A10 | Server-side tier entitlement (`has_entitlement()`) | SOURCE_IMPLEMENTED (helper only, NOT enforced) | Argon reports the helper is defined in RC20 migration `20260826000000` (core / pro / enterprise capability sets). | Argon reports the RC20 migrations are **not applied** to production and `has_entitlement()` is **never called** in any RLS policy, RPC, Edge Function or route guard. All authenticated users of an active tenant can reach all deployed modules. |
| A11 | Tenant defaults seeding (`seed_tenant_defaults`) | PRODUCTION_VERIFIED | Argon reports it is deployed. | Seeding only. Not end-to-end onboarding. |
| A12 | Pilot onboarding & user invitations | PARTIAL (admin-assisted) | Argon reports managed provisioning by NEXORA is possible. | Argon reports `tenant-onboarding` queries non-existent `public.profiles` (actual `user_profiles`), `tenant-admin.html` queries non-existent `public.invites` (actual `tenant_invites`), and `settings.html` hardcodes tenant `a1b2c3d4-0000-0000-0000-000000000001`. Self-serve onboarding isn't working. |
| A13 | Seat-limit enforcement | UNVERIFIED (NONE / not implemented) | Argon reports no `max_seats`/`seat_limit` column, trigger, RLS policy or Edge Function check. | Argon: limits are "enforced operationally by NEXORA and contractually". `settings.html` still shows legacy one-time licence cards ($4,900 / 1 user; $14,900 / up to 5; $24,900 / unlimited). |
| A14 | Subscription term / checkout billing | PARTIAL (disabled by Gate A) | Argon reports `create-checkout-session` is deployed with `BILLING_CHECKOUT_ENABLED=false` (HTTP 503). | Argon reports: **no 90-day fixed term** (indefinite recurring subscription, no `cancel_at`, no Subscription Schedule); **no onboarding-fee line item**; depends on unapplied RC20 tables. |
| A15 | Supplier CSV/Excel upload & staging | PRODUCTION_VERIFIED | Argon reports `supplier-csv-import` is ACTIVE, backed by `prc_import_*`, `prc_approve_staging_rows`, `prc_active_prices`, `prc_price_history`. Supports .csv/.xlsx/.xls with human staging review. | Argon matrix: "Contractual (Edge Function checks `tenant_id` + role)". No tier gate. |
| A16 | PDF quote extraction | PARTIAL | Argon reports `supplier-pdf-extract` is ACTIVE for text-layer PDFs (`pdf-parse`). Regex/line-pattern extraction. No AI/LLM parser. | Argon reports cloud OCR (Textract/Google Vision/Azure) is SOURCE_IMPLEMENTED but **no OCR keys are configured**, so it falls back to a placeholder. Scanned PDFs aren't supported. |
| A17 | Email quote ingestion | PARTIAL | Argon reports `supplier-email-ingest` is ACTIVE and routes .csv/.xlsx/.pdf attachments from Postmark/SendGrid webhooks. | Argon reports it **hardcodes `DEFAULT_TENANT_ID`** (`a1b2c3d4-…0001`) instead of resolving the tenant per recipient. |
| A18 | Scheduled supplier sync dispatcher | PARTIAL | Argon reports `supplier-sync-dispatch` is ACTIVE for `storage_csv` jobs. | Argon reports SFTP connector "not yet implemented" and API connector "requires provider-specific implementation". |
| A19 | Live supplier connectors: Roofmart, RONA, ABC Supply, Convoy | DEMO_ONLY | Argon reports hardcoded mocks ("Mock browser execution for architecture pilot") returning fixed SKUs/prices (e.g. RM-12345 $35.99; RONA-12345 $12.99; ABC-12345 $39.99; CS-12345 $145.99). | Argon: the agreement **must not** promise live API/EDI feeds. |
| A20 | Home Depot connector (`supplier-web-fetch`) | PARTIAL | Argon reports it attempts unauthenticated HTML scraping of homedepot.ca. | Argon reports it is subject to retail bot protection (403 Access Denied). |
| A21 | Self-serve exports (timesheet CSV, document download, print/save-to-PDF of estimates, invoices, reports) | PARTIAL (Section 5 heading); PRODUCTION_VERIFIED (Argon summary) | Argon reports `exportWeekCSV()`, `downloadDoc()` and print functions implemented. | Limited to those artefacts. Not a full-tenant export. |
| A22 | Full-tenant bulk export & offboarding | UNVERIFIED / manual admin process (Section 5); overall export area PARTIAL (matrix and summary) | Argon reports data is keyed by `tenant_id`, so NEXORA could extract it administratively (SQL/CSV/JSON). | Argon reports there is **no self-serve full-tenant export endpoint and no automated offboarding/decommissioning RPC**. |
| A23 | 90-day term / non-automatic conversion / advance monthly billing (as a pilot process) | PARTIAL | Argon recommends manual Stripe Invoicing or a manually configured 3-cycle Subscription Schedule (`iterations: 3`, `end_behavior: 'cancel'`) plus a separate onboarding invoice. | Argon reports a manual/admin process only. Automated checkout can't do it. |

**Classification counts (23 register lines, each counted once under its primary Argon label):** PRODUCTION_VERIFIED 10 (A1–A8, A11, A15) · PARTIAL 10 (A9, A12, A14, A16, A17, A18, A20, A21, A22 export area overall, A23) · SOURCE_IMPLEMENTED 1 (A10) · DEMO_ONLY 1 (A19, covering 4 connectors) · UNVERIFIED 1 (A13). Argon labels two items twice: A21 is PRODUCTION_VERIFIED in its summary, and the A22 sub-item (full-tenant export/offboarding) is UNVERIFIED in Section 5. Also SOURCE_IMPLEMENTED in Argon's report: cloud OCR (within A16) and the RC20 billing schema (within A14).

### Desk notes on Argon's report (Argon's classifications are not changed)
- **N1. Internal inconsistency: export labels.** Argon's Section 5 calls full-tenant export/offboarding UNVERIFIED, but the matrix and summary call the export area PARTIAL. Self-serve exports are PARTIAL in Section 5 and PRODUCTION_VERIFIED in the summary. The Desk treats the full-tenant item as UNVERIFIED for contract purposes, the more conservative reading. Argon should reconcile.
- **N2. Internal inconsistency: tier allocation.** Argon's matrix (Section 6) shows Materials/Inventory/PO and BOM/SFL as "Included (UI accessible)" for Foundation, and CSV upload in Foundation. Argon's recommended descriptions (Section 7) list BOM/SFL, PO/inventory and CSV supplier import as Live Intelligence *additions*. The CEO must choose. See §3.
- **N3. Argon's 30-day export proposal not adopted.** Argon suggests committing to a CSV/JSON export "within 30 days of pilot end". Under the task rules and because A22 is unverified, **no export deadline is included.** This is Argon's recommendation, not a CEO-approved term.
- **N4. "Tenant-isolated" wording not adopted.** Argon's suggested Foundation text says "tenant-isolated workspace". Given A12/A17 (hardcoded tenant identifiers) and the earlier instruction not to make tenant-isolation claims without verification, the Desk doesn't use the phrase. It needs Risk & Compliance review.
- **N5. Argon's Section 7 wording is a recommendation.** It includes "Up to 10/25 named users", "90 days from workspace activation" and "white-glove" configuration. None of these is CEO-approved and none is adopted as a commitment.

---

## 2. Clarifications requested by the CEO

**(a) Core modules Argon verified (PRODUCTION_VERIFIED, per Argon):** Estimating & Quotes; Jobs, Work Orders & Scheduling; Clients/CRM & Client Portal; Invoicing, Payments, Expenses & Tax; Crew, Time Tracking, Payroll & Safety/OHS; Materials, Inventory & Purchase Orders; Operational & Financial Reporting; Dynamic BOM/Assemblies/Rules/SFL; Supplier CSV/Excel import & staging; tenant-defaults seeding. Argon reports these as deployed in production. Argon report does not address usability testing, performance, data accuracy, or real-customer end-to-end workflow testing.

**(b) Features that distinguish Foundation from Live Intelligence:** Argon distinguishes them **only on paper**. On Argon's matrix the Live Intelligence-only items are: PDF & email quote ingestion ("Beta / Assisted", PARTIAL); Price Drift Alerts & Cost Impact Analyzer (PARTIAL, no margin delta); and the 25 vs 10 proposed seats (UNVERIFIED/not enforced). Argon's Section 7 additionally places BOM/SFL, PO/inventory and CSV supplier import in Live Intelligence (see N2). **None of the differentiators is technically enforced (A10). Every differentiating feature Argon identifies is PARTIAL, and none is PRODUCTION_VERIFIED as an exclusive Live Intelligence capability.** No live supplier data feed is part of either tier.

**(c) No server-side tier enforcement:** Argon reports **all** tier boundaries are unenforced. `has_entitlement()` is unapplied and never called, so every authenticated user of an active tenant can reach every deployed module, including the Live Intelligence features. Seat caps aren't enforced either (A13). Argon reports enforcement is contractual and through NEXORA admin provisioning only.

**(d) Mock or demo-only supplier integrations:** Argon reports Roofmart, RONA, ABC Supply and Convoy are **DEMO_ONLY** hardcoded mocks. Home Depot web scraping is PARTIAL and blocked by bot protection. The SFTP and API sync connectors are unimplemented. Argon reports the only working supplier-pricing paths are file-based: CSV/Excel (PRODUCTION_VERIFIED) and text-layer PDF (PARTIAL).

**(e) Onboarding, export and billing commitments that remain unverified or partial:**
- Onboarding: self-serve onboarding and invitations are broken (A12, PARTIAL). Only NEXORA-managed provisioning is viable. Argon report does not address how long managed onboarding takes or whether an end-to-end managed onboarding has been tested on a fresh tenant.
- Export/offboarding: no full-tenant export endpoint and no offboarding/deletion RPC (A22). Argon report does not address deletion or destruction of customer data, backups, or verification that an admin extraction is complete.
- Billing: checkout is disabled. No automatic 90-day end, no onboarding-fee line item, and the RC20 billing schema isn't applied (A14). The manual invoicing or Subscription Schedule approach is Argon's recommendation; Argon report does not address whether it has been configured or tested. Argon report does not address refunds, proration or tax handling in Stripe.

---

## 3. Proposed conservative tier descriptions (PROPOSED — not CEO-approved)

**Common to all tiers.** 90-day controlled pilot. No automatic conversion. Billed monthly in advance only after Acceptance and authorized onboarding/payment arrangements, using a NEXORA-issued invoice or a manually controlled schedule [UNKNOWN — CEO TO CONFIRM billing method]. Onboarding only if quoted separately and approved. Accounts are provisioned by NEXORA (no self-serve onboarding). No SLA, uptime or response-time commitment. No guarantee of results, accuracy, profitability or margin. No live third-party supplier integrations. No data-export deadline (§13.6 of v2 remains UNRESOLVED). Plan limits are contractual only and not technically enforced.

### Foundation Pilot — CAD $299/month
- **Deployed functionality (per Argon, PRODUCTION_VERIFIED):** estimating and quotes; jobs, work orders and scheduling; client records and a link-based client portal for estimate approval and invoice viewing; invoicing, payments, expenses and tax-rate tracking; crew records, timesheets (with weekly CSV export), payroll calculation worksheets and safety/OHS logs; standard operational and financial reports. [UNKNOWN — CEO TO CONFIRM whether materials/inventory/PO, BOM/SFL and CSV supplier import are in Foundation (Argon matrix) or Live Intelligence only (Argon §7). See N2.]
- **Customer-ready end-to-end workflow:** **Not confirmed.** Argon verified deployment, not a complete customer workflow from onboarding through export. Onboarding must be NEXORA-assisted (A12), and full-tenant export is unverified (A22).
- Seats: **PROPOSED 10 — not approved, not enforced.**

### Live Intelligence Pilot — CAD $599/month
- **Deployed functionality (per Argon):** everything in Foundation, plus [subject to CEO decision N2] supplier price-sheet import from CSV/Excel with staging approval (PRODUCTION_VERIFIED); BOM/assemblies/SFL rules (PRODUCTION_VERIFIED); text-layer PDF quote extraction, **beta**, with scanned PDFs not supported (PARTIAL); material cost-drift identification on draft/open estimates, with margin impact **not calculated** and confirmed manually by the estimator (PARTIAL).
- **Excluded:** email quote ingestion until the hardcoded-tenant defect is fixed (A17, see §5); any live, real-time, API, EDI, SFTP or web-scraped supplier feed (A18–A20).
- **Customer-ready end-to-end workflow:** **Not confirmed.** The differentiating features are PARTIAL/beta, and nothing prevents Foundation users from reaching them.
- Seats: **PROPOSED 25 — not approved, not enforced.**
- **Naming risk (from v3, still open):** "Live Intelligence" may imply live supplier data. Rename it, or add a disclosure: *"'Live Intelligence' is a plan name. It does not include live third-party supplier data feeds or integrations."* Misleading-representation risk; Risk & Compliance to review.

### Enterprise Pilot — custom, by agreement
- **Deployed functionality:** same as Live Intelligence. Anything beyond that (custom configuration, rule modelling, integrations) only as set out in a separately approved order form or SOW [UNKNOWN — CEO/COUNSEL TO CONFIRM].
- Argon lists direct supplier connectors as "Custom / Roadmap only". **No roadmap item may be presented as a pilot deliverable.**
- **Customer-ready end-to-end workflow:** Not confirmed. Seats: [UNKNOWN — CEO TO CONFIRM].

---

## 4. Required flags
1. **Seat limits:** 10 (Foundation) and 25 (Live Intelligence) are **PROPOSED only, not CEO-approved and not technically enforced** (A13). The in-app `settings.html` still shows legacy one-time licence pricing ($4,900 / $14,900 / $24,900), which conflicts with the pilot pricing and must not be shown to pilot customers.
2. **Mock supplier integrations:** 4 of 5 connectors are DEMO_ONLY mocks returning fixed prices. If a pilot customer can reach them, the fake prices could be mistaken for real quotes. Disable them or clearly label them as demo data.
3. **Incomplete onboarding:** self-serve onboarding and invitations reference non-existent tables. Provisioning is manual by NEXORA only.
4. **Billing limitations:** **no automatic 90-day termination**; checkout would create an open-ended recurring subscription; no onboarding-fee line item; RC20 billing schema not applied. Billing outside a controlled manual process risks charges after the pilot, contrary to the "no automatic conversion" decision.
5. **Data-export risks:** no full-tenant export or offboarding/deletion function. Export depends on manual admin SQL extraction, with completeness unverified. No deadline, format or deletion term can be promised yet.
6. **Price-impact accuracy:** the margin delta is hardcoded to 0. Any marketing or Schedule A wording implying margin analysis would be inaccurate.

---

## 5. Tenant-isolation and security issues — FLAG FOR RISK & COMPLIANCE
- **S1 (HIGH, possibly CRITICAL). Email-ingestion hardcoded tenant.** Argon reports `supplier-email-ingest` routes all inbound attachments to `DEFAULT_TENANT_ID` `a1b2c3d4-0000-0000-0000-000000000001`. In a multi-tenant pilot, one customer's supplier documents could land in another tenant's workspace. Disable it or fix it before signing. If any real customer data has gone through it, a privacy-incident assessment is needed (PIPA/PIPEDA; **REQUIRES_LICENSED_COUNSEL**).
- **S2 (HIGH). `settings.html` hardcodes the same tenant UUID** (`TENANT = 'a1b2c3d4-…0001'`). Argon report does not address whether settings reads or writes reach that fixed tenant for every user. Argon should confirm whether it can expose or alter another tenant's settings.
- **S3 (MEDIUM). Tier boundaries unenforced.** Not a cross-tenant issue, but customers on a lower tier can reach higher-tier features. It is a contract-integrity and billing-fairness risk.
- **S4 (MEDIUM). Home Depot scraping.** Unauthenticated scraping of a retailer's site that has bot protection may raise website terms-of-use and legal issues. Argon report does not address the retailer's terms. Refer to Risk & Compliance/counsel before it is used or described.
- **S5 (note).** Argon reports multi-tenant RLS on the core modules. That is Argon's evidence only. The Desk hasn't verified it, and no "tenant isolation" claim should appear in customer documents until Risk & Compliance has reviewed S1/S2.
- Argon report does not address hosting region or data residency, subprocessors (Supabase, Stripe, Postmark/SendGrid, any OCR provider), encryption, backups, or access logging. v2 §6 stays UNRESOLVED.

---

## 6. Changelog versus v3 (what the full Argon report changed)
1. Replaced the CEO's 9-point summary with Argon's full report and **Argon's own labels** (v3 used the Desk's own PRODUCTION-VERIFIED/PARTIAL/DEMO-ONLY/UNVERIFIED mapping, with 0 production-verified). Argon reports **10 PRODUCTION_VERIFIED items**, including all core ERP modules and CSV/Excel import.
2. Core module list is now named (v3 had [UNKNOWN: module list]).
3. Foundation vs Live Intelligence: v3 said nothing verified distinguishes them. Argon now identifies PARTIAL differentiators (PDF/email ingestion, cost-drift analyzer), with an inconsistency in BOM/PO/CSV allocation (N2). Still nothing enforced.
4. Added the SOURCE_IMPLEMENTED status of `has_entitlement()` and the unapplied RC20 migrations.
5. Named the mock connectors (Roofmart, RONA, ABC Supply, Convoy) and the Home Depot scraping issue. Added SFTP/API unimplemented.
6. Onboarding defect detail (profiles/invites table mismatches) and a **new second hardcoded tenant (settings.html, S2)**.
7. Billing detail: checkout disabled by Gate A; no `cancel_at`; no onboarding-fee item; Argon's manual-billing recommendation recorded (not adopted as a term).
8. Export split into self-serve partial exports and an unverified full-tenant export. Argon's 30-day export suggestion **not adopted** (N3).
9. New flags: legacy in-app pricing cards; margin delta hardcoded to 0; scraping legal risk (S4).
10. Seat pairing (10 = Foundation, 25 = Live Intelligence) is now sourced from Argon's report rather than inferred, but it remains **PROPOSED, not approved and not enforced**.

---

## 7. Pre-signing technical conditions
Each needs written confirmation from Argon, with evidence, plus CEO sign-off before any paid pilot agreement is signed:
1. Email ingestion fixed so it resolves the tenant per recipient, or disabled for pilot tenants. Any past exposure assessed (S1).
2. The `settings.html` hardcoded tenant fixed and its impact confirmed (S2).
3. Managed onboarding of a fresh tenant tested end to end. Profiles/invites mismatches fixed, or confirmed to be bypassed by the admin process.
4. A documented, tested billing control that guarantees no charge after 90 days and no automatic conversion (manual invoicing or a capped schedule), with a named owner. Checkout stays disabled.
5. A separate onboarding-fee invoicing process, used only on approved quotes.
6. Mock connectors disabled, or clearly labelled as demo data, for pilot tenants. Live-search UI hidden or disclosed.
7. A full-tenant export procedure tested for completeness, plus a decision on deletion and offboarding, before any v2 §13.6 term is drafted.
8. Seat and tier limits: either enforced server-side, or a documented manual monitoring process, with the agreement stating that limits are contractual.
9. Legacy pricing cards removed from `settings.html`, and public website claims re-verified after Gate A (no guaranteed profitability, SLA, 24/7 or auto-renewal claims).
10. Hosting region, subprocessors and security measures confirmed for v2 §6 (Argon report does not address).

---

## 8. CEO decisions needed
1. Tier allocation of BOM/SFL, materials/inventory/PO and CSV supplier import: Foundation (Argon matrix) or Live Intelligence only (Argon §7)? (N2)
2. Approve, change or reject the proposed 10 / 25 seat limits and the Enterprise seat basis; extra-seat fees.
3. Rename "Live Intelligence", or adopt the disclosure.
4. Include PDF extraction (beta) and the cost-drift analyzer in Schedule A, given their PARTIAL status?
5. Billing method for pilots (manual invoice or capped Stripe schedule) and who owns the 90-day stop.
6. Data-export and offboarding position (no deadline proposed; Argon's 30-day suggestion is awaiting CEO and counsel decision).
7. Whether any customer data has passed through email ingestion, and whether to refer S1/S2 to counsel.
8. Whether pilots may start before conditions 1–10 in §7 are met (the Desk recommends not).

Still UNRESOLVED from v2 (unchanged): cancellation notice, refunds and proration, liability, privacy, taxes, IP and data return. These need CEO and counsel input and Risk & Compliance review.

# DRAFT — NOT LEGALLY APPROVED
