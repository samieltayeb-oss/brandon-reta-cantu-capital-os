> **DRAFT — NOT LEGALLY APPROVED. AI-generated. Not legal advice.** Prepared by NEXORA Legal Counsel Desk (AI legal research and drafting assistant, not a licensed lawyer) for internal CEO review. Task LIAISON-20261014-06. 2026-10-14. Status: DRAFT_ONLY.
> Reviewed: draft_agreement.md and open_questions.md (not edited), plus compliance_review.md (Risk & Compliance Analyst). Framework: /workspace/legal/framework/legal_research_framework.md.

# SUMMITOS Controlled Paid Pilot Agreement: Initial Legal-Risk Assessment

## 1. Executive legal-risk summary
- The biggest exposure isn't in the draft agreement. It's NEXORA's **public SUMMITOS pages**. They "guarantee profitability", promise a "Priority 4-Hour Response SLA" and "24/7 Dedicated Architect", and claim "Cryptographic Multi-Tenancy / Complete database isolation". None of this is verified. These are representations to the public promoting a product, which is the conduct addressed by Competition Act s.52(1) and s.74.01(1)(a)–(c). [VERIFIED_PRIMARY_AUTHORITY for the text; whether the claims breach it is REASONED_LEGAL_INTERPRETATION / REQUIRES_LICENSED_COUNSEL]
- The draft disclaims these claims (§10.2, §11.4). A contract disclaimer doesn't cure a misleading public representation. Customers who signed up relying on the site may also argue the claims formed part of the bargain. [REASONED_LEGAL_INTERPRETATION]
- Live **self-serve Stripe checkout** links to Terms and Privacy pages that return 404 (per R&C E2/E3). Customers can buy outside any signed agreement, so the draft's protections may not apply to them at all. [UNVERIFIED factual capture from R&C; REASONED_LEGAL_INTERPRETATION]
- The draft leaves the **liability cap blank** (§12.1, §12.3) and has no indemnity decision. Until it's filled in, NEXORA's exposure is uncapped for GPS, payroll and estimating data. Enforceability of any cap will be tested under *Tercon*, 2010 SCC 4 (citation verified; pin cites unverified). [REQUIRES_LICENSED_COUNSEL]
- **Privacy/cross-border**: hosting regions and subprocessors are unknown. PIPA s.13.1 and s.6(2) require country-level information when service providers outside Canada are used. §6.5 can't support the customer's obligations without it. [VERIFIED_PRIMARY_AUTHORITY text; application REQUIRES_LICENSED_COUNSEL]
- The draft is structurally sound as a placeholder template, with 31 open questions. **It is not executable.**

## 2. Clause-by-clause issue matrix
| § | Issue | Rating | Factual basis | Legal basis | Label |
|---|---|---|---|---|---|
| Pre-contract / site | Profitability guarantee, SLA, 24/7, crypto multi-tenancy claims | **CRITICAL** | Public pages (R&C E5–E7); no testing or substantiation on record | Competition Act s.52(1), (4); s.74.01(1)(a), (b) (performance guarantee must rest on an adequate and proper test, with the burden on the maker), (c) | VERIFIED_PRIMARY_AUTHORITY (text); REQUIRES_LICENSED_COUNSEL (application) |
| Pre-contract / site | Self-serve checkout bypasses the signed agreement; Terms/Privacy pages 404 | **CRITICAL** | R&C E2, E3, E11 | Contract formation (ETA s.27 click-through can form contracts); consumer purchasers trigger CPA s.6(4)(t.1) and ISCR s.4, s.6 | VERIFIED_PRIMARY_AUTHORITY (text); REASONED_LEGAL_INTERPRETATION |
| 12 | Liability cap and carve-outs blank; consequential-damages exclusion unconfirmed | **HIGH** | §12.1–12.4 placeholders | *Tercon* 2010 SCC 4: courts ask whether the clause applies, and whether to refuse enforcement for unconscionability or overriding public policy | VERIFIED (citation) / UNVERIFIED (pin cites); REQUIRES_LICENSED_COUNSEL |
| 6.2–6.7 | Controller/service-provider roles, cross-border, subprocessors, breach timing unknown | **HIGH** | GPS, payroll, crew data; Supabase/Stripe named, regions unknown | PIPA s.5(2), s.6(2)–(3), s.13.1, s.34, s.34.1; PIPEDA s.10.1, Sch.1 cl.4.1.3 | VERIFIED_PRIMARY_AUTHORITY (text); REQUIRES_LICENSED_COUNSEL |
| 4 | End-of-pilot renewal model undecided; site says "automatic renewal" | **HIGH** | §4.1 placeholder; R&C E9 | CPA s.6(4)(t.1) if the customer is an individual; Competition Act s.74.01 if renewal terms mislead | VERIFIED_PRIMARY_AUTHORITY (text); CEO decision |
| 11.3 | "Merchantability" US-style disclaimer; Alberta fit unconfirmed | **MEDIUM** | §11.3 wording | Alberta implied-terms law NOT RESEARCHED | UNVERIFIED; REQUIRES_LICENSED_COUNSEL |
| 11.4 | Correctly disclaims profitability, but contradicts the site | **HIGH** (because of the conflict) | Site vs §11.4 | Competition Act s.74.01(1)(c) (guarantee "materially misleading" or no reasonable prospect of being carried out) | REASONED_LEGAL_INTERPRETATION |
| 10 | No SLA, which is sound; contradicts the site's 4-hour SLA | **HIGH** (conflict) | §10.2 vs site | As above | REASONED_LEGAL_INTERPRETATION |
| 6.4 | Security commitment generic; no isolation claim, which is correct | **MEDIUM** | Tenant isolation design unknown (R&C D3) | PIPA s.34 reasonable security arrangements | VERIFIED_PRIMARY_AUTHORITY (text) |
| 8 | Ownership of customer-created SFL formulas/outputs; feedback; de-identified data | **MEDIUM** | §8.3–8.4 placeholders | Copyright Act s.13(1), (4) (assignment/licence in signed writing); s.14.1 moral rights waivable, not assignable | VERIFIED_PRIMARY_AUTHORITY; REQUIRES_LICENSED_COUNSEL |
| 14 | CASL consent box: content of the request; sender of customer messages | **MEDIUM** | §14.2–14.3 | CASL s.6, s.10(1), s.11 (Regulations not reviewed) | VERIFIED_PRIMARY_AUTHORITY (text, via R&C) |
| 6.8 / payroll, OHS, WCB modules | Regulatory reliance on outputs | **MEDIUM** | Module list from site | NOT RESEARCHED | UNVERIFIED |
| 5 | Tax clause generic; registration and place of supply unknown | **MEDIUM** | §5.1 | Excise Tax Act s.165(1)–(2), s.240(1); **accountant to verify** | VERIFIED_PRIMARY_AUTHORITY (text); UNVERIFIED (application) |
| 13 | Termination notice, cure, data-return windows blank | **MEDIUM** | §13 placeholders | PIPA s.35 retention | VERIFIED_PRIMARY_AUTHORITY |
| 15 | Governing law placeholder; no dispute mechanism | **MEDIUM** | §15 | Counsel decision | REQUIRES_LICENSED_COUNSEL |
| 15.3 / 16 | E-signature/counterparts | **LOW** | §15.3 | ETA s.8, s.16, s.27 | VERIFIED_PRIMARY_AUTHORITY |
| 1 | Party details, order of precedence | **LOW** (fact gaps) | §1 | — | CEO decision |
| 7 | Confidentiality survival blank | **LOW** | §7.4 | — | CEO decision |
| 3 | Pricing table; tier names differ from site | **LOW** (legal) / MEDIUM (consistency) | CEO-approved $299/$599/custom vs site "Core/Pro" | — | CEO_APPROVED_COMMERCIAL_POSITION (pricing) |
| H (defined terms) | "Agreement", "Plan", "Pilot Term", "Customer Data" are used; "Selected Plan", "Order Form" and "Enterprise order form" are undefined | **LOW** | Draft text | — | REASONED_LEGAL_INTERPRETATION |

## 3. Primary authority citations (verified 2026-10-14)
| Authority | Section(s) | URL | Jurisdiction | Status |
|---|---|---|---|---|
| Competition Act, RSC 1985, c C-34 (current to 2026-09-21) | s.52(1), (1.1), (4), (5); s.74.01(1)(a)–(c) | https://laws-lois.justice.gc.ca/eng/acts/C-34/section-52.html ; …/section-74.01.html | Federal | VERIFIED_PRIMARY_AUTHORITY (fetched by this desk) |
| Copyright Act, RSC 1985, c C-42 | s.13(1), (3), (4); s.14.1(1)–(4) | https://laws-lois.justice.gc.ca/eng/acts/C-42/section-13.html ; …/section-14.1.html | Federal | VERIFIED_PRIMARY_AUTHORITY (fetched by this desk) |
| Excise Tax Act, RSC 1985, c E-15 | s.165(1)–(2); s.240(1) | https://laws-lois.justice.gc.ca/eng/acts/E-15/section-165.html ; …/section-240.html | Federal | VERIFIED_PRIMARY_AUTHORITY (text); application UNVERIFIED (accountant) |
| *Tercon Contractors Ltd. v. British Columbia (Transportation and Highways)*, 2010 SCC 4, [2010] 1 SCR 69 | Headnote issues only; no paragraph pin cites | https://decisions.scc-csc.ca/scc-csc/scc-csc/en/item/7843/index.do | SCC | Citation VERIFIED on the court site (title page). Full text blocked (403); the CanLII page returned empty. Test wording from the official headnote via search index: **pin cites UNVERIFIED.** |
| PIPA, SA 2003, c P-6.5 | s.5(2), 6(2)–(3), 13, 13.1, 34, 34.1, 35 | https://kings-printer.alberta.ca/documents/Acts/P06P5.pdf | Alberta | VERIFIED (King's Printer copy downloaded 2026-10-14 by R&C; s.13.1 and s.34.1 re-read by this desk) |
| PIPEDA, SC 2000, c 5 | s.4(1), 10.1, 10.3; Sch.1 cl.4.1.3 | https://laws-lois.justice.gc.ca/eng/acts/P-8.6/FullText.html | Federal | VERIFIED by R&C 2026-10-14 (not re-fetched by this desk) |
| CASL, SC 2010, c 23 | s.6, 10(1), 10(9)–(10), 11 | https://laws-lois.justice.gc.ca/eng/acts/E-1.6/FullText.html | Federal | VERIFIED by R&C 2026-10-14 |
| Electronic Transactions Act, SA 2001, c E-5.5 | s.8, 16, 27 | https://kings-printer.alberta.ca/documents/Acts/E05P5.pdf | Alberta | VERIFIED by R&C (King's Printer copy) |
| Consumer Protection Act, RSA 2000, c C-26.3 | s.1(1)(b), 6(4)(t.1) | https://kings-printer.alberta.ca/documents/Acts/C26P3.pdf | Alberta | VERIFIED (copy; s.6(4)(t.1) re-located by this desk) |
| Internet Sales Contract Regulation, Alta Reg 81/2001 | s.2, 4, 5, 6 | https://kings-printer.alberta.ca/documents/Regs/2001_081.pdf | Alberta | VERIFIED by R&C |
**Case law:** apart from *Tercon* (citation only), no case was verified. No Alberta authority on SaaS disclaimers, auto-renewal or limitation clauses has been verified.

## 4. Highest-risk clauses (ranked)
1. **CRITICAL**: Public-site profitability guarantee, plus the SLA, 24/7 and crypto multi-tenancy claims (Competition Act s.52 / s.74.01). Direction: CEO to have the claims removed or substantiated before any pilot; keep §10.2/§11.4.
2. **CRITICAL**: Self-serve checkout outside the signed agreement, with 404 Terms/Privacy pages. Direction: pause self-serve or publish reviewed terms before pilots; decide whether consumers (individuals) are excluded.
3. **HIGH**: §12 limitation of liability and indemnities blank. Direction: CEO picks a cap model; counsel tests enforceability against *Tercon*.
4. **HIGH**: §6 privacy roles, cross-border and subprocessors, breach-notice timing. Direction: technical facts first (hosting regions, subprocessor list), then a DPA decision by counsel.
5. **HIGH**: §4 renewal/conversion model vs the site's "automatic renewal". Direction: CEO chooses the model; explicit disclosure and consent.
6. MEDIUM: §8 IP in customer-created formulas/outputs, data-use rights, moral rights.
7. MEDIUM: §11.3 disclaimer wording (US-style), payroll/OHS reliance.

## 5. Assertions needing source verification
**A. Citations in the draft**
| Draft ref | Assertion | Status now |
|---|---|---|
| §6.1 | PIPA / PIPEDA apply | Statutes VERIFIED; which one applies to each flow REQUIRES_LICENSED_COUNSEL |
| §6.7, OQ24 | PIPA s.34.1 and PIPEDA breach notification | VERIFIED (s.34.1; PIPEDA s.10.1). Individual-notice content under the PIPA Regulation UNVERIFIED |
| §14.2 | CASL S.C. 2010, c. 23 | VERIFIED; the "not pre-checked" rule is CRTC guidance (non-binding) |
| §15.3, OQ30 | Alberta Electronic Transactions Act | VERIFIED: SA 2001, c E-5.5, ss.8, 16, 27 |
| §5, OQ27 | GST/HST/PST/QST | GST/HST text VERIFIED (ETA s.165, s.240). Place of supply, PST/QST and NEXORA registration UNVERIFIED (accountant) |
| §11.3 | Implied warranties "merchantability" | UNVERIFIED for Alberta |
| §4.1 | "Renewal-disclosure requirements" | Consumer: CPA s.6(4)(t.1) VERIFIED. B2B: no Alberta statute identified (UNVERIFIED) |
**B. Public-site claims (all UNVERIFIED as fact)**
| Claim | Risk | Authority to check |
|---|---|---|
| "guarantee profitability before the first nail is driven" / "eliminate margin erosion automatically" | Misrepresentation; unsubstantiated performance guarantee | Competition Act s.52(1), s.74.01(1)(a)–(c) (VERIFIED text) |
| "Priority 4-Hour Response SLA", "Support SLA Guarantee", "24/7 Dedicated Architect" | Purported guarantee with no reasonable prospect of being carried out (if unresourced) | s.74.01(1)(c) |
| "Cryptographic Multi-Tenancy", "Complete database isolation" (vs RLS on the Security page) | False security claim; also PIPA s.34 expectations | s.74.01(1)(a); PIPA s.34 |
| "Instant automated Canadian tenant provisioning" vs "no Canadian-only residency guarantee" | Misleading residency impression | s.52(4) general impression; PIPA s.13.1 |
| Live supplier price sync (Beacon, ABC, Convoy) | Feature may not exist | s.74.01(1)(a) |
| Competitor price comparisons with no source | Misleading comparative claim | s.74.01(1)(a) |
| "The only ERP built specifically for…" | Unsubstantiated superlative | s.74.01(1)(a) |
Penalty and remedy provisions (e.g., s.74.1) were **not** reviewed: UNVERIFIED.

## 6. CEO decisions required (CEO_APPROVED_COMMERCIAL_POSITION pending)
1. Correct or substantiate the site claims and decide on pausing self-serve checkout before pilots (highest priority).
2. Official tier names (Foundation / Live Intelligence approved vs site Core/Pro).
3. Pilot term, start trigger, end-of-pilot model, cancellation, refunds.
4. Liability cap model and carve-outs; whether to offer indemnities.
5. Support channels and hours; whether any response-time commitment is resourced.
6. Seats, modules and onboarding fees; Enterprise order form.
7. Data-use rights (aggregated/de-identified), feedback, reference rights.
8. Whether individuals or sole proprietors are eligible pilot customers (triggers CPA/ISCR).
9. Signatory; NEXORA corporate details; GST/HST registration number.

## 7. Privacy/compliance items for Risk & Compliance (via NEXORA Liaison)
- Hosting regions and complete subprocessor list (Supabase, Stripe, email/SMS, AI APIs), with a technical owner to confirm (R&C D1–D2).
- PIPA s.13.1 / s.6(2) notice chain for customer-entered data; whether §6.5 must name countries.
- PIPA Regulation and PIPEDA Breach Regulations (not reviewed): individual-notice content.
- Breach-notice timing NEXORA→customer, to support PIPA s.34.1 / PIPEDA s.10.1.
- CASL Regulations (prescribed sender information) for §14.2; sender characterization for customer SMS/email (§14.3).
- GPS/location data of the customer's workers: sensitivity, consent allocation.
- Whether any health information could enter SUMMITOS (e.g., WCB/OHS injury data). If so, it's out of scope and escalates.
- Competition Act review of site claims, to coordinate with the website owner (no change made by this desk).

## 8. Remaining uncertainties and REQUIRES_LICENSED_COUNSEL items
- REQUIRES_LICENSED_COUNSEL: enforceability of the cap and exclusions (*Tercon* pin cites unverified); Alberta warranty disclaimer law; governing law and venue; PIPA vs PIPEDA allocation and the s.26(2)(b) exemption; DPA need; CASL sender role; IP ownership of customer formulas and outputs; Competition Act exposure from existing site claims; consumer status of sole proprietors; payroll/OHS reliance disclaimers.
- UNVERIFIED: all public-site factual claims; hosting and subprocessor facts; regulations (PIPA Reg, CASL Regs, PIPEDA Breach Regs); tax place-of-supply and PST/QST; any Alberta case law; OPC/OIPC guidance (not fetched).
- Note: R&C findings were relied on for PIPEDA, CASL, ETA and ISCR without re-fetching (cross-checked against their downloaded official copies only).

## 9. Quality-control checklist
- [x] Header marked DRAFT — NOT LEGALLY APPROVED, AI-generated, not legal advice
- [x] Agreement not rewritten or edited; only directional notes given
- [x] Every citation has a URL, jurisdiction, date and section; unverifiable items marked UNVERIFIED
- [x] No case cited unless confirmed on a court site (*Tercon*: citation only; pin cites flagged)
- [x] Canadian law kept separate from US/international (see framework §2)
- [x] Every conclusion labelled
- [x] CEO-approved pricing reflected; no other commercial term assumed
- [x] No uptime, profitability or tenant-isolation claim adopted
- [ ] Independent R&C review of this assessment (pending, via NEXORA Liaison)
- [ ] Qualified Alberta counsel review (not yet engaged)
- [ ] Accountant review of tax (not yet engaged)
- [ ] Technical verification of hosting, subprocessors and isolation (not yet done)
