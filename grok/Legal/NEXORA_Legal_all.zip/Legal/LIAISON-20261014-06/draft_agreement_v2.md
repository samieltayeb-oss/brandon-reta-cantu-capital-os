> **DRAFT — NOT LEGALLY APPROVED. Internal CEO review only. Not legal advice. Not for distribution to customers.**
> Status: **DRAFT_ONLY** | Version: v2 | Task: LIAISON-20261014-06 | Prepared by: NEXORA Legal Counsel Desk (AI drafting assistant, not a lawyer) | Date: 2026-10-14
> Supersedes nothing: v1 (draft_agreement.md) is retained unchanged. Changelog: changes_v2.md. Open questions: open_questions_v2.md.
> Before any execution, a qualified lawyer must review the liability, IP, privacy and cross-border items (**REQUIRES LICENSED COUNSEL**).

# SUMMITOS CONTROLLED PAID PILOT AGREEMENT (v2)

**Drafting notes**
- Labels used: **CEO_APPROVED_COMMERCIAL_POSITION** (CEO directions relayed by NEXORA Liaison, 2026-10-14); **VERIFIED_PRIMARY_AUTHORITY** (citation text verified by Risk & Compliance Analyst against the official source, compliance_review.md V1–V7); **UNVERIFIED**; **REQUIRES LICENSED COUNSEL**.
- Citation verification means only that the cited provision exists and says what is described. How it applies to NEXORA's facts is still for counsel (compliance_review.md, Part B).
- King's Printer texts used for verification are office consolidations. Counsel should confirm them against official versions. Regulations (PIPA Regulation, PIPEDA Breach of Security Safeguards Regulations, CRTC Electronic Commerce Protection Regulations) were **not** reviewed, so their prescribed content is UNVERIFIED.
- SUMMITOS context comes only from the three public pages (nexorayyc.io/summitos, nexorayyc.io/products/summitos, summitos.nexorayyc.io), fetched 2026-10-14. Public claims of guaranteed profitability, cryptographic multi-tenancy, complete database isolation, a 4-hour response SLA, 24/7 dedicated architect and automatic renewal are **not** adopted. Each is unverified and conflicts with this draft.

---

## 1. Parties
1.1 **NEXORA Technologies Corp.**, a corporation under [UNKNOWN — CEO/COUNSEL TO CONFIRM: jurisdiction of incorporation and corporate number], with its registered office at [UNKNOWN — CEO/COUNSEL TO CONFIRM: address], Calgary, Alberta ("**NEXORA**").
1.2 **[UNKNOWN — CEO/COUNSEL TO CONFIRM: Customer legal name]**, a [entity type/jurisdiction], with its address at [address] ("**Customer**").
1.3 Effective Date: [UNKNOWN — CEO/COUNSEL TO CONFIRM].
1.4 Order of precedence: [UNKNOWN — CEO/COUNSEL TO CONFIRM: does this Agreement stand alone, or does it sit under a NEXORA MSA/Order Form, and which document prevails?]

## 2. Pilot Scope and Duration
2.1 **Purpose.** NEXORA will give Customer access to SUMMITOS, a construction/contractor operations and estimating software service, on a controlled, limited pilot basis, so Customer can evaluate it in Customer's operations.
2.2 **Pilot nature.** Customer acknowledges that SUMMITOS is in a limited pilot stage. Features may be incomplete, may change, or may be withdrawn.
2.3 **Selected Pilot Plan and included features.** Customer's Pilot Plan is set out in Schedule A. The modules, features and seat limits included in each Pilot Plan are [UNKNOWN — pending Argon verification of implemented features, entitlement enforcement and operational readiness]. No feature, module, integration or seat limit is promised by this Agreement unless it is listed in a completed Schedule A. (CEO_APPROVED_COMMERCIAL_POSITION: tier features and seat limits not approved.)
2.4 **Third-party supplier data.** Any supplier price-feed integration is provided only if, and to the extent, it is available and listed in Schedule A. [UNKNOWN — pending Argon verification of implemented features, entitlement enforcement and operational readiness: which integrations exist and how they work.] NEXORA doesn't control the accuracy of supplier data.
2.5 **Pilot Term.** The pilot runs for **ninety (90) days** (the "**Pilot Term**") (CEO_APPROVED_COMMERCIAL_POSITION), starting on [UNKNOWN — CEO/COUNSEL TO CONFIRM: start trigger, e.g. the Pilot Start Date stated in Schedule A once Acceptance and onboarding are complete], unless terminated earlier under Section 13.
2.6 **End of pilot; no automatic conversion.** The pilot and this Agreement **end automatically at the end of the Pilot Term**. They do not renew, extend or convert into any paid subscription or other agreement. Any continued use after the Pilot Term requires Customer to affirmatively opt in by entering into a separate written agreement or subscription with NEXORA. (CEO_APPROVED_COMMERCIAL_POSITION.) [UNKNOWN — CEO/COUNSEL TO CONFIRM: form of the opt-in, and how Customer Data is treated if Customer opts in (continuity) versus not (Section 13.6).]
2.7 **Workspace.** Customer will receive one company workspace. [UNKNOWN — CEO/COUNSEL TO CONFIRM: additional workspaces/entities.]
2.8 **Onboarding.** Any onboarding or implementation services, and any fee for them, will be quoted separately and apply only if Customer explicitly approves that quote in writing. No onboarding fee is charged automatically. (CEO_APPROVED_COMMERCIAL_POSITION.) [UNKNOWN — CEO/COUNSEL TO CONFIRM: onboarding fee amounts. The amounts on public pages ($1,000 / $2,500 / $5,000–$15,000+ CAD) are not approved and are not adopted.]
2.9 **Feedback.** [UNKNOWN — CEO/COUNSEL TO CONFIRM: any Customer feedback, meeting or reporting obligations during the pilot.]

## 3. Fees and Billing
3.1 **Pilot Plans (CEO_APPROVED_COMMERCIAL_POSITION):**

| Pilot Plan | Pilot Fee |
|---|---|
| Foundation Pilot | CAD $299 per month |
| Live Intelligence Pilot | CAD $599 per month |
| Enterprise Pilot | Custom, by separate written agreement between the parties [UNKNOWN — CEO/COUNSEL TO CONFIRM: form of Enterprise order document] |

Features and seat limits per Pilot Plan: [UNKNOWN — pending Argon verification of implemented features, entitlement enforcement and operational readiness].

3.2 **Billing start.** No fee is billed until all of the following have occurred: (a) Customer's acceptance of this Agreement ("**Acceptance**"); (b) authorized onboarding; and (c) authorized payment arrangements. (CEO_APPROVED_COMMERCIAL_POSITION.) [UNKNOWN — CEO/COUNSEL TO CONFIRM: what counts as "authorized" onboarding and payment arrangements, and who authorizes them.]
3.3 **Billing frequency.** Pilot Fees are billed **monthly in advance** in Canadian dollars (CEO_APPROVED_COMMERCIAL_POSITION). Payment method: [UNKNOWN — CEO/COUNSEL TO CONFIRM]. Invoices are due within [UNKNOWN — CEO/COUNSEL TO CONFIRM: days]. No charges will be made after the Pilot Term ends unless Customer has opted in under Section 2.6.
3.4 **Late payment.** [UNKNOWN — CEO/COUNSEL TO CONFIRM: interest, suspension right and notice before suspension.]
3.5 **Refunds and proration.** [UNKNOWN — CEO/COUNSEL TO CONFIRM: refunds and proration, including how the final billing period is charged where the 90-day Pilot Term does not align with monthly billing cycles, and treatment on early termination.] — **UNRESOLVED**
3.6 **Additional seats/usage.** [UNKNOWN — CEO/COUNSEL TO CONFIRM; depends on Argon verification of entitlement enforcement.]

## 4. End of Pilot and Cancellation
4.1 **No renewal.** This Agreement contains no automatic renewal, extension or conversion. See Section 2.6. (CEO_APPROVED_COMMERCIAL_POSITION.)
4.2 **Cancellation by Customer during the Pilot Term.** Customer may cancel by giving [UNKNOWN — CEO/COUNSEL TO CONFIRM: cancellation notice period and method]. Cancellation takes effect [UNKNOWN — CEO/COUNSEL TO CONFIRM: effective date]. — **UNRESOLVED**
4.3 **End-of-pilot notice.** [UNKNOWN — CEO/COUNSEL TO CONFIRM: whether NEXORA sends Customer a courtesy notice before the Pilot Term ends describing the opt-in option and data export deadline. Any such notice must not imply automatic continuation.]
4.4 **Consumer note.** If a Customer could be an individual "consumer" (e.g. a sole proprietor), Alberta's *Consumer Protection Act*, RSA 2000, c C-26.3, s.6(4)(t.1) (disclosure of and express consent to renewals) and the *Internet Sales Contract Regulation*, AR 81/2001, ss.4–6, may apply (VERIFIED_PRIMARY_AUTHORITY for the text, compliance_review.md A13–A14; applicability REQUIRES LICENSED COUNSEL).

## 5. Taxes — UNRESOLVED
5.1 Fees exclude applicable taxes. [UNKNOWN — CEO/COUNSEL TO CONFIRM: which sales taxes apply (GST/HST/PST/QST) by Customer location, NEXORA's GST/HST registration number, and whether any provincial PST registration is required. **UNVERIFIED** (compliance V8: Excise Tax Act not reviewed in the compliance task). Accountant to confirm.]
5.2 Each party is responsible for its own income taxes.

## 6. Data Protection and Privacy — UNRESOLVED — REQUIRES LICENSED COUNSEL
6.1 **Applicable law.** Each party will comply with the privacy laws that apply to it. These may include Alberta's *Personal Information Protection Act*, SA 2003, c P-6.5 ("**PIPA**") (V1, VERIFIED_PRIMARY_AUTHORITY) and, where applicable, the federal *Personal Information Protection and Electronic Documents Act*, SC 2000, c 5 ("**PIPEDA**"), Part 1 of which applies to personal information collected, used or disclosed in the course of commercial activities (s.4(1)) (V2, VERIFIED_PRIMARY_AUTHORITY). [Which statute governs each data flow REQUIRES LICENSED COUNSEL (compliance B1).]
6.2 **Roles.** For personal information Customer enters into SUMMITOS (e.g. employee, crew, time-tracking/GPS, payroll, client CRM and photo data), Customer is [UNKNOWN — CEO/COUNSEL TO CONFIRM: characterization, e.g. the organization in control, with NEXORA acting as a service provider processing only on Customer's instructions (see PIPA s.5(2); PIPEDA Sch. 1 cl. 4.1.3)]. [UNKNOWN — CEO/COUNSEL TO CONFIRM: whether a separate Data Processing Agreement is required.]
6.3 **Customer responsibilities.** Customer is responsible for having the notices and consents needed for the personal information it enters into SUMMITOS, including location data collected from its personnel.
6.4 **Security.** NEXORA will use reasonable security arrangements appropriate to the sensitivity of the information (cf. PIPA s.34). [UNKNOWN — CEO/COUNSEL TO CONFIRM: specific security commitments. This draft makes no tenant-isolation, encryption or "complete database isolation" representation — pending Argon verification (compliance D3–D4).]
6.5 **Data residency / cross-border.** Customer Data is hosted in [UNKNOWN — CEO/COUNSEL TO CONFIRM: countries and regions, pending Argon verification (D1)]. Customer Data may be processed or stored outside Alberta and/or Canada by NEXORA's service providers in [UNKNOWN — CEO/COUNSEL TO CONFIRM: countries]. [PIPA s.13.1(1)–(4) (notice where a service provider outside Canada is used) and s.6(2)–(3) (policies naming the countries and purposes) — V3, VERIFIED_PRIMARY_AUTHORITY for the text. Whether this clause is enough to support Customer's obligations, and who gives the notice, REQUIRES LICENSED COUNSEL (B3–B4).]
6.6 **Subprocessors.** NEXORA uses third-party service providers to deliver SUMMITOS. [UNKNOWN — CEO/COUNSEL TO CONFIRM: complete subprocessor list, locations and purposes, pending Argon verification (D2); notice mechanism for changes.]
6.7 **Security incidents.** NEXORA will notify Customer of a security incident affecting Customer's personal information [UNKNOWN — CEO/COUNSEL TO CONFIRM: timing and content], and the parties will cooperate on notifications required by law, including: PIPA s.34.1(1)–(2) (notice to the Commissioner without unreasonable delay where there is a real risk of significant harm) (V4, VERIFIED_PRIMARY_AUTHORITY; notice to individuals is set by regulation — UNVERIFIED); and PIPEDA s.10.1(1) (report to the Commissioner), s.10.1(3) (notice to individuals), s.10.2(1) (notice to other organizations; verified by Risk & Compliance, see compliance_review_v2.md) and s.10.3(1) (breach records) (V5, corrected citation). [Allocation of these duties REQUIRES LICENSED COUNSEL (B5).]
6.8 **Health information.** Customer will not enter health information into SUMMITOS. [UNKNOWN — CEO/COUNSEL TO CONFIRM.]

## 7. Confidentiality
7.1 "**Confidential Information**" means non-public information one party discloses to the other in connection with this Agreement that is marked confidential, or would reasonably be understood to be confidential. It includes Customer's supplier pricing, bidding formulas and estimates, and NEXORA's software, pricing and product roadmap.
7.2 The receiving party will use Confidential Information only to perform or receive the pilot, protect it with at least reasonable care, and disclose it only to personnel and advisors who need to know it and are bound by similar obligations.
7.3 Exclusions: information that is public through no fault of the recipient; already known to the recipient; independently developed; or lawfully received from a third party. Disclosure is permitted where required by law, with notice to the other party where lawful.
7.4 Duration: [UNKNOWN — CEO/COUNSEL TO CONFIRM: survival period].

## 8. Intellectual Property and Customer Data — UNRESOLVED — REQUIRES LICENSED COUNSEL
8.1 **NEXORA IP.** NEXORA and its licensors retain all rights in SUMMITOS, including its software, documentation, Summit Formula Language and any improvements. This Agreement doesn't transfer any ownership. [UNKNOWN — CEO/COUNSEL TO CONFIRM: wording.]
8.2 **Licence to Customer.** During the Pilot Term only, NEXORA grants Customer a non-exclusive, non-transferable, revocable right for its authorized users to use SUMMITOS for Customer's internal business purposes. The licence ends with the Pilot Term unless Customer opts in under Section 2.6.
8.3 **Customer Data.** As between the parties, Customer owns the data it submits ("**Customer Data**"). Customer grants NEXORA a licence to host, process and use Customer Data only as needed to provide and support SUMMITOS. [UNKNOWN — CEO/COUNSEL TO CONFIRM: use of aggregated/de-identified data; ownership of Customer-created formulas, templates and outputs.]
8.4 **Feedback.** [UNKNOWN — CEO/COUNSEL TO CONFIRM: licence to use Customer feedback.]
8.5 **Publicity.** Neither party may use the other's name or logo without prior written consent. [UNKNOWN — CEO/COUNSEL TO CONFIRM: reference-customer rights.]

## 9. Acceptable Use
Customer will not, and will not allow anyone else to:
(a) use SUMMITOS in violation of law or third-party rights;
(b) reverse engineer, copy, resell or sublicense SUMMITOS, or build a competing product from it;
(c) upload malicious code, or interfere with or probe the security of the service;
(d) access other customers' data, or share credentials beyond its authorized users;
(e) load data it doesn't have the right to use, including supplier data restricted by supplier terms;
(f) send unlawful commercial electronic messages through the notification features (see Section 14).
[UNKNOWN — CEO/COUNSEL TO CONFIRM: any additional restrictions; whether a separate AUP document governs.]

## 10. Support
10.1 NEXORA will provide pilot support through [UNKNOWN — CEO/COUNSEL TO CONFIRM: channels] during [UNKNOWN — CEO/COUNSEL TO CONFIRM: hours, time zone].
10.2 **No service levels.** NEXORA makes no commitment on uptime, availability, response time or resolution time unless a separately signed service level schedule says otherwise. [The public "Priority 4-Hour Response SLA" and "24/7 Dedicated Architect" claims are NOT adopted and are unverified.]
10.3 Maintenance windows and planned changes: [UNKNOWN — CEO/COUNSEL TO CONFIRM].

## 11. Warranties and Disclaimers — REQUIRES LICENSED COUNSEL
11.1 Each party warrants that it has the authority to enter into this Agreement.
11.2 [UNKNOWN — CEO/COUNSEL TO CONFIRM: any limited performance warranty by NEXORA.]
11.3 **Disclaimer.** Except as expressly stated, SUMMITOS is provided during the pilot "as is" and "as available". To the extent permitted by law, NEXORA disclaims all other warranties and conditions, express or implied, including merchantability, fitness for a particular purpose and non-infringement. [Wording and enforceability under Alberta law REQUIRE LICENSED COUNSEL.]
11.4 **No business outcome guarantee.** NEXORA does not guarantee profitability, margin protection, estimate accuracy, supplier price accuracy or business results. Customer remains responsible for reviewing estimates, prices, invoices, payroll, tax, safety/OHS and compliance outputs before relying on them. [Conflicts with the public claim to "guarantee profitability" (compliance E5).]

## 12. Limitation of Liability — UNRESOLVED — REQUIRES LICENSED COUNSEL
12.1 **Cap.** Each party's total liability under this Agreement will not exceed [UNKNOWN — CEO/COUNSEL TO CONFIRM: cap amount/formula].
12.2 **Excluded damages.** [UNKNOWN — CEO/COUNSEL TO CONFIRM: scope of exclusion of indirect, incidental, special, consequential or punitive damages and lost profits, revenue or data.]
12.3 **Carve-outs.** [UNKNOWN — CEO/COUNSEL TO CONFIRM: exclusions from the cap.]
12.4 **Indemnities.** [UNKNOWN — CEO/COUNSEL TO CONFIRM: whether any indemnities are included, and in which direction.]

## 13. Termination and Data Return
13.1 **Expiry.** This Agreement ends at the end of the Pilot Term under Section 2.6. (CEO_APPROVED_COMMERCIAL_POSITION.)
13.2 **Early termination for convenience.** [UNKNOWN — CEO/COUNSEL TO CONFIRM: whether either party may terminate early for convenience, and on what notice.]
13.3 **Termination for breach.** Either party may terminate on written notice if the other materially breaches and fails to cure within [UNKNOWN — CEO/COUNSEL TO CONFIRM: days].
13.4 **Suspension.** NEXORA may suspend access as needed to address a security risk or a breach of Section 9. [UNKNOWN — CEO/COUNSEL TO CONFIRM: notice requirements.]
13.5 **Effect.** On expiry or termination, access ends, and Customer pays Pilot Fees properly accrued to that date. [Refunds and proration: UNKNOWN — CEO/COUNSEL TO CONFIRM (see Section 3.5).]
13.6 **Data return — UNRESOLVED.** [UNKNOWN — CEO/COUNSEL TO CONFIRM: export window after expiry or termination, export format, deletion timeline, and retention of backups and legally required records (cf. PIPA s.35; backup periods pending Argon verification (D7)).]
13.7 **Survival.** Sections [UNKNOWN — CEO/COUNSEL TO CONFIRM: survival list] survive.

## 14. Communications and CASL Consent
14.1 **Operational messages.** NEXORA may send Customer service, billing, security and account messages relating to the pilot. [Whether these fall outside the CEM definition REQUIRES LICENSED COUNSEL (B7).]
14.2 **Marketing consent (optional, separate).** ☐ Customer's signatory consents to receive commercial electronic messages from NEXORA Technologies Corp. about NEXORA products and services. Consent can be withdrawn at any time using the unsubscribe mechanism in each message or by contacting [UNKNOWN — CEO/COUNSEL TO CONFIRM: contact address]. [*Canada's Anti-Spam Legislation*, SC 2010, c 23 ("**CASL**"): s.6(1)–(2) (consent and prescribed message content), s.10(1) (purpose and identification when requesting express consent), s.10(9)–(10) (implied consent, existing business relationship), s.11 (unsubscribe, effective within 10 business days) — V6, corrected citation, VERIFIED_PRIMARY_AUTHORITY for the text. The "not pre-checked / positive opt-in" practice comes from CRTC guidance, which is non-binding, and the prescribed identification content is set by regulation (UNVERIFIED) (B6).]
14.3 **Customer's own messages.** When Customer uses the SUMMITOS notification features (SMS/email) to message its own clients or subcontractors, Customer is responsible for obtaining the consents and including the identification and unsubscribe content required by law. [Sender characterization under CASL s.6 REQUIRES LICENSED COUNSEL (B8).]
14.4 **Notices.** Legal notices go to the addresses in Section 1 by [UNKNOWN — CEO/COUNSEL TO CONFIRM: method].

## 15. Governing Law — PLACEHOLDER
15.1 [PLACEHOLDER — PENDING COUNSEL] This Agreement is governed by the laws of the Province of Alberta and the federal laws of Canada that apply there. The parties attorn to the courts of [UNKNOWN — CEO/COUNSEL TO CONFIRM: venue].
15.2 Dispute resolution: [UNKNOWN — CEO/COUNSEL TO CONFIRM].
15.3 General: entire agreement, amendment in writing, assignment, force majeure, severability, independent contractors, counterparts and electronic signature [UNKNOWN — CEO/COUNSEL TO CONFIRM: wording]. Electronic signature and electronic contract formation: Alberta *Electronic Transactions Act*, SA 2001, c E-5.5, ss.8, 16, 27 (V7, VERIFIED_PRIMARY_AUTHORITY for the text). "Counterparts" is a drafting point, not an ETA term (B11).

## 16. Signatures
*Signature block is a template placeholder only. Nothing in this draft is to be signed.*

| NEXORA Technologies Corp. | [Customer Legal Name] |
|---|---|
| By: ____________________ | By: ____________________ |
| Name: [UNKNOWN — CEO/COUNSEL TO CONFIRM] | Name: |
| Title: | Title: |
| Date: | Date: |

### Schedule A — Pilot Plan Selection
☐ Foundation Pilot (CAD $299/month) ☐ Live Intelligence Pilot (CAD $599/month) ☐ Enterprise Pilot (custom, by agreement)
Pilot Term: 90 days, no automatic conversion | Pilot Start Date: [UNKNOWN — CEO/COUNSEL TO CONFIRM]
Features/modules and seats: [UNKNOWN — pending Argon verification of implemented features, entitlement enforcement and operational readiness]
Onboarding: ☐ None ☐ Separately quoted and approved in writing (quote ref: ______) — no automatic onboarding charge

---
> **DRAFT — NOT LEGALLY APPROVED. Internal CEO review only. Not legal advice. Not for distribution to customers.** Status: DRAFT_ONLY (v2)
