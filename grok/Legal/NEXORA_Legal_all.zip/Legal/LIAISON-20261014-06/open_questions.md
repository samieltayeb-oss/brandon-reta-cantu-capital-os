# LIAISON-20261014-06 — Open Questions (SUMMITOS Controlled Paid Pilot Agreement)
DRAFT — NOT LEGALLY APPROVED. Internal CEO review only. Not legal advice. Not for distribution to customers.
Status: DRAFT_ONLY

## A. CEO decisions (commercial)
1. Tier names: the agreement uses the CEO-approved "Foundation" ($299) and "Live Intelligence" ($599). Public pages call the same price points "SummitOS Core" and "SummitOS Pro". Which names are the official ones?
2. Pilot term length (for example, 60 or 90 days) and its start date trigger (signature, provisioning or go-live).
3. What happens at the end of the pilot: automatic conversion to a paid subscription, renewal month-to-month, or ending unless the customer opts in? Public pages say "automatic renewal" and "cancel anytime".
4. Notice period for cancellation, and whether fees are prorated or refunded.
5. Billing: monthly in advance or in arrears, payment method, invoice due date, and late-payment interest (if any).
6. Seat limits per tier. Public pages say 10 and 25, which isn't CEO-confirmed.
7. Which modules and features are in each tier during the pilot. Public pages list features (for example, live supplier sync for Beacon, ABC and Convoy) whose readiness isn't verified.
8. Onboarding fees. Public pages list $1,000, $2,500 and $5,000–$15,000+ CAD. Do any of them apply to the pilot?
9. Enterprise pilot pricing and scope: a separate order form, or out of scope for this template?
10. Support: channels, hours and any response-time commitment. Public pages say "Priority 4-Hour Response SLA" and "24/7 Dedicated Architect", which aren't verified and aren't included in the draft.
11. Pilot feedback obligations and whether NEXORA can use the customer's name or logo as a reference.
12. Number and maximum count of pilot customers. Is there any eligibility criterion (roofing and exterior contractors only)?
13. Should the public website claims ("guarantee profitability", "cryptographic multi-tenancy", "complete database isolation", "SLA guarantees") be fixed before the pilot starts? They conflict with the disclaimers in the draft. Route to the website owner.
14. Who signs for NEXORA (name and title)?
15. Data return format and the window for the customer to export data after termination.
16. Fee for extra seats or additional usage, if any.

## B. Counsel decisions (REQUIRES QUALIFIED LEGAL REVIEW)
17. Liability cap amount and structure (for example, fees paid in the last X months), plus carve-outs (confidentiality, IP infringement, data breach, gross negligence or wilful misconduct).
18. Exclusion of indirect and consequential damages, and whether it's enforceable as drafted.
19. Whether to include indemnities, and in which direction (IP infringement by NEXORA; customer data and content).
20. IP: ownership of customer data, outputs and estimates; licence to aggregated or de-identified data; feedback licence; Summit Formula Language (SFL) formulas the customer creates.
21. Privacy: whether NEXORA acts as a service provider/processor under Alberta PIPA and PIPEDA for customer-entered personal information (GPS time tracking, crew, payroll, client CRM, photos). Is a separate DPA needed?
22. Data residency: where Supabase (and Stripe, if used) host and process data. Cross-border transfer notice obligations. Hosting region is unknown.
23. Subprocessor list (Supabase confirmed on the public page; Stripe referenced; others unknown) and the change-notice mechanism.
24. Security incident and breach notification terms (PIPA s. 34.1 notification to the Commissioner; PIPEDA breach of security safeguards). Citations to be verified by the Risk & Compliance Analyst.
25. CASL: whether the SMS and email notification feature makes the customer or NEXORA the sender of commercial electronic messages, and the consent allocation between them.
26. Governing law and venue (Alberta is a placeholder) and any dispute resolution or arbitration.
27. Taxes: GST, plus HST, PST or QST depending on the customer's location, and NEXORA's registration status. Confirm with an accountant or counsel.
28. Warranty disclaimer wording and its enforceability, including the "beta/pilot" as-is framing.
29. Whether the payroll, OHS safety and WCB modules create any regulatory reliance risk that needs a specific disclaimer.
30. E-signature validity and the counterparts clause (Alberta Electronic Transactions Act). Citation unverified.
31. Survival clause list and order of precedence with any order form or MSA.
