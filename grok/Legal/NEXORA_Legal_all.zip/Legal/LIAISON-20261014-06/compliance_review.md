# Compliance Review — TASK LIAISON-20261014-06 — SUMMITOS Controlled Paid Pilot Agreement (draft)
Status: EVIDENCE_SUBMITTED · Advisory research only, not legal advice · 2026-10-14 ~02:40 MT (UTC-6)
Scope: CEO updated scope (buckets A–E). Read-only review of draft_agreement.md and open_questions.md (not edited). Approved model: Foundation CAD $299/mo, Live Intelligence CAD $599/mo, Enterprise custom; reviewed onboarding (not self-serve).
Official texts downloaded to ./sources/ (PDF/HTML + .txt extracts). 05 evidence: /workspace/compliance/LIAISON-20261014-05/risk-register.md (R1–R12).
No compliance conclusions are made. Each point appears in exactly one bucket.

## Official sources (current versions retrieved 2026-10-14)
| ID | Instrument | URL | Currency stated by publisher |
|---|---|---|---|
| S-A | Personal Information Protection Act, SA 2003, c P-6.5 (PIPA) | https://kings-printer.alberta.ca/documents/Acts/P06P5.pdf | Current as of September 1, 2025 |
| S-B | Personal Information Protection and Electronic Documents Act, SC 2000, c 5 (PIPEDA) | https://laws-lois.justice.gc.ca/eng/acts/P-8.6/FullText.html | Act current to 2026-09-21 |
| S-C | Canada's Anti-Spam Legislation, SC 2010, c 23 (CASL) | https://laws-lois.justice.gc.ca/eng/acts/E-1.6/FullText.html | Act current to 2026-09-21; last amended 2026-01-01 |
| S-D | Electronic Transactions Act, SA 2001, c E-5.5 (ETA) | https://kings-printer.alberta.ca/documents/Acts/E05P5.pdf | Current as of June 11, 2025 |
| S-E | Consumer Protection Act, RSA 2000, c C-26.3 (CPA) | https://kings-printer.alberta.ca/documents/Acts/C26P3.pdf | Current as of September 1, 2026 |
| S-F | Internet Sales Contract Regulation, AR 81/2001 (ISCR) | https://kings-printer.alberta.ca/documents/Regs/2001_081.pdf | Current as of April 1, 2023 |
| S-G | CRTC CASL FAQ (non-binding guidance) | https://crtc.gc.ca/eng/com500/faq500.htm | n/a |
King's Printer files are office consolidations; counsel should confirm against official versions before relying on them. Regulations (PIPA Regulation, CRTC Electronic Commerce Protection Regulations, PIPEDA Breach Regulations) were NOT retrieved.

## Citation verification (draft items marked UNVERIFIED)
| # | Draft ref | As drafted | Result | Verified reference |
|---|---|---|---|---|
| V1 | §6.1 | Alberta PIPA | VERIFIED (name); add cite | SA 2003, c P-6.5 [S-A] |
| V2 | §6.1 | PIPEDA | VERIFIED (name); add cite | SC 2000, c 5; application s.4(1) [S-B] |
| V3 | brief | PIPA s.13.1 cross-border notice | VERIFIED | s.13.1(1)–(4); related s.6(2)–(3) [S-A] |
| V4 | §6.7, OQ24 | PIPA s.34.1 notice to Commissioner | VERIFIED | s.34.1(1)–(2) [S-A]; individual notice is set by regulation (UNVERIFIED) |
| V5 | §6.7, OQ24 | PIPEDA "breach of security safeguards" (no section) | CORRECTED | s.10.1(1) report to Commissioner; s.10.1(3) notify individual; separate subsection to notify other organizations (number not confirmed due to text flattening); s.10.3(1) breach records [S-B] |
| V6 | §14 | CASL (no section) | CORRECTED | s.6(1)–(2), s.10(1), s.10(9)–(10), s.11 [S-C] |
| V7 | §15.3, OQ30 | Alberta Electronic Transactions Act | VERIFIED (name); add cite | SA 2001, c E-5.5; ss.8, 16, 27 [S-D] |
| V8 | OQ27 | GST/HST/PST/QST | STILL UNVERIFIABLE in this task | Excise Tax Act not reviewed; accountant |

---
## (A) CONFIRMED LEGAL REQUIREMENTS (text verified by me in the official source)
A1. PIPA s.13(1): before/at collection, notify the individual of (a) purposes and (b) name or position/title of a person who can answer questions. [S-A]
A2. PIPA s.13.1(1)–(2): an organization that uses a service provider outside Canada to collect, or transfers to one, personal information collected with consent "must notify the individual"; s.13.1(3): before or at collection/transfer, notify of (a) how to access written information on its policies and practices for service providers outside Canada and (b) name or title of a person who can answer questions about collection, use, disclosure or storage by those providers; s.13.1(4): in addition to s.13 notice. Applies "subject to the regulations" (regulations not reviewed). [S-A]
A3. PIPA s.6(2): where a service provider outside Canada is used, policies must include (a) the countries where collection, use, disclosure or storage "is occurring or may occur" and (b) the purposes the provider is authorized for; s.6(3): make written information available on request. [S-A]
A4. PIPA s.5(2): an organization engaging a person by contract is responsible for that person's compliance with the Act; s.5(3): designate individual(s) responsible. [S-A]
A5. PIPA s.34: reasonable security arrangements; s.34.1(1): organization with information "under its control" must notify the Commissioner "without unreasonable delay" where a reasonable person would consider there is "a real risk of significant harm". s.35(1): retain only as long as reasonably required for legal or business purposes. [S-A]
A6. PIPEDA s.4(1): Part 1 applies to personal information collected, used or disclosed in the course of commercial activities. Sch.1 cl.4.1.3: responsible for information transferred to a third party for processing; "shall use contractual or other means to provide a comparable level of protection". Cl.4.8/4.8.2: openness, including name/title and address of the accountable person. [S-B]
A7. PIPEDA s.10.1(1): report to the Commissioner any breach of security safeguards involving information under its control where there is a real risk of significant harm; s.10.1(3): notify the individual; s.10.3(1): keep a record of every breach of security safeguards. [S-B]
A8. CASL s.6(1): prohibited to send a commercial electronic message (CEM) to an electronic address unless the recipient consented (express or implied) and the message complies with s.6(2) (prescribed sender identification, contact info, unsubscribe mechanism). [S-C]
A9. CASL s.10(1): a person seeking express consent must, when requesting it, set out clearly and simply (a) the purpose(s) and (b) prescribed information identifying the person seeking consent. [S-C]
A10. CASL s.10(9)(a) and s.10(10): implied consent via "existing business relationship", including a purchase or written contract within the prior two years and an inquiry/application within the prior six months. [S-C]
A11. CASL s.11: unsubscribe must be at no cost, by the same electronic means where practicable; give effect "without delay, and in any event no later than 10 business days"; contact information valid for at least 60 days after sending. [S-C]
A12. ETA s.8(1): no one is required to use or accept electronic records without consent (consent may be inferred from conduct, s.8(2)); s.16(1): a legal requirement that a record be signed is satisfied by an electronic signature (subject to s.16(2) and s.22); s.27: contract formation may be expressed electronically, including by clicking an icon. [S-D]
A13. CPA s.6(4)(t.1) (consumer transactions only): unfair practice for a representation about an agreement for continuing provision of services without "prominent and full disclosure of the details of the agreement, including duration, changes in price, renewals, extensions or amendments", or failure to obtain "the consumer's express consent to renewals, extensions or amendments". "Consumer" = an individual (s.1(1)(b)). [S-E]
A14. ISCR s.2 (applies where supplier or consumer is Alberta-resident, or offer/acceptance is made in or sent from Alberta); s.4(1)(a): pre-contract disclosure including (v) itemized price incl. taxes, (vii) total or periodic payments, (viii) currency, (ix) payment terms, (xii) cancellation, return, exchange and refund policies; s.5 copy of contract; s.6(1): cancellation until 7 days after receiving the copy if the s.4(1)(a) disclosures were not made, or within 30 days if no copy was provided. [S-F]

## (B) LEGAL INTERPRETATIONS REQUIRING COUNSEL
B1. Whether PIPA, PIPEDA or both govern each data flow (intra-Alberta, interprovincial or cross-border; PIPEDA s.26(2)(b) "substantially similar" exemption). (§6.1)
B2. Whether NEXORA is a contracted service provider to the Customer (PIPA s.5(2); PIPEDA cl.4.1.3) for Customer-entered employee, GPS, payroll, CRM and photo data, and whether a separate DPA is needed. (§6.2, OQ21)
B3. Who must give the PIPA s.13.1 notice for Customer-entered data (likely the Customer as the organization using the provider, which then makes NEXORA a link in the chain); and whether NEXORA itself owes s.13.1 notice for signatory/admin data it collects. Text in A2 is verified; how it applies to these facts is interpretation.
B4. Whether draft §6.5 ("may be processed or stored outside Alberta and/or Canada", no countries named) is enough to support the Customer's s.6(2)(a) and s.13.1 obligations.
B5. Breach terms: NEXORA→Customer notice timing and content so the Customer can meet PIPA s.34.1 / PIPEDA s.10.1; individual notification under the PIPA Regulation (not reviewed). (§6.7, OQ24)
B6. CASL express-consent mechanics in §14.2: the statute (A9) requires purpose and identity in the request. The "no pre-checked box / positive opt-in action" rule comes from CRTC guidance [S-G], not statutory text I verified, so its application is for counsel. Also whether §14.2 needs NEXORA's mailing address and contact details (prescribed by regulation, not reviewed).
B7. Whether §14.1 operational messages are outside the CEM definition, and the scope of implied consent under s.10(10) once a pilot contract is signed.
B8. CEM sender characterization for Customer SMS/email sent through SummitOS (CASL s.6 "send or cause or permit to be sent"; possible s.9 aiding exposure per CRTC guidance). (§14.3, OQ25)
B9. Whether any pilot customer could be a "consumer" (e.g., a sole proprietor), triggering CPA s.6(4)(t.1) and the ISCR. Signed, reviewed onboarding may change whether the ISCR applies (Internet sales contract definition).
B10. B2B auto-renewal and cancellation disclosure: no Alberta statute was identified in this review; enforceability rests on contract law and the Competition Act (05 R2). (§4)
B11. E-signature and counterparts wording under ETA ss.8, 16, 27; "counterparts" is a contract-drafting point, not an ETA term. (§15.3, OQ30)
B12. Warranty disclaimer, liability cap and carve-outs, indemnities, IP and de-identified data use, governing law and venue (§§8, 11, 12, 15; OQ17–20, 26, 28).
B13. Regulatory reliance risk from the payroll, OHS and WCB modules (OQ29). Tax treatment and registration (OQ27, V8); accountant as well.

## (C) CEO COMMERCIAL DECISIONS
C1. Official tier names: adopt Foundation / Live Intelligence / Enterprise (approved) in all documents (§3.1, OQ1).
C2. Pilot term length and start trigger (§2.5, OQ2).
C3. End-of-pilot model: convert, renew month-to-month, or opt in; renewal reminder (§4.1, §4.3, OQ3). Choose before counsel drafts B9/B10 wording.
C4. Cancellation notice period, effective date, proration and refunds (§3.4, §4.2, §13.4, OQ4).
C5. Billing timing, payment method, due date, late interest and suspension (§3.2–3.3, OQ5).
C6. Seats and modules per tier; extra-seat fees (§2.3, §3.5, OQ6, 7, 16).
C7. Onboarding fees within the reviewed-onboarding model (§2.7, OQ8); Enterprise order form (OQ9).
C8. Support channels and hours; whether to offer any response-time commitment (§10, OQ10).
C9. Feedback and reference rights (OQ11); pilot eligibility and count (OQ12); signer (OQ14); data export window and format (OQ15); privacy/CASL contact address for §14.2.
C10. Whether to disable self-serve sign-up and correct website claims before pilots start (OQ13; see E).

## (D) TECHNICAL FACTS REQUIRING ARGON VERIFICATION (listed only; not investigated)
D1. Hosting countries and regions for SummitOS database, edge functions, backups and logs (Supabase; any others).
D2. Complete subprocessor list with locations and purposes (Supabase, Stripe, email/SMS providers, AI APIs such as Groq/Anthropic, Vercel, Upstash, Hostinger).
D3. Tenant isolation design (PostgreSQL RLS keyed to tenant ID versus separate databases); whether any "cryptographic" separation exists.
D4. Encryption in transit and at rest; key management.
D5. Whether live supplier feed integrations (Beacon, ABC Supply, Convoy, Roofmart) exist, and whether they are APIs, scrapers or customer-uploaded CSV.
D6. Breach detection and logging capability needed to support PIPEDA s.10.3 records and notice timelines.
D7. Data deletion and backup retention periods (supports §13.5 and PIPA s.35).
D8. Unsubscribe and consent-record handling in the SMS/email notification features.

## (E) UNSUPPORTED OR INCONSISTENT PUBLIC CLAIMS (from 05 captures)
E1. Tier names: site uses "SummitOS Core" ($299) and "SummitOS Pro" ($599), inconsistent with the approved Foundation / Live Intelligence. [05 raw/nexorayyc.io_summitos.txt; summitos.nexorayyc.io.txt]
E2. Self-serve sign-up and Stripe checkout are live ("Choose Your Plan & Subscribe", "Continue to Secure Stripe Checkout →", "Create Workspace →"), inconsistent with the approved reviewed-onboarding model and the product page ("Limited pilot", "Pricing is not finalised"). [05 R2; raw/summitos.nexorayyc.io_signup.html.txt]
E3. Sign-up says "you agree to the SummitOS Terms of Service and Privacy Policy", but summitos.nexorayyc.io/terms.html and /privacy.html return 404. [05 R1; raw/status.txt]
E4. "Instant automated Canadian tenant provisioning" versus the Security page ("We do not guarantee Canadian-only data residency…") and the Privacy page (US providers). [05 R5]
E5. "guarantee profitability before the first nail is driven"; "eliminate margin erosion automatically"; "The only ERP built specifically for…". Conflicts with draft §11.4. [05 R3]
E6. "Cryptographic Multi-Tenancy", "Complete database isolation", "Isolated databases" versus the Security page's RLS description. [05 R7]
E7. "Priority 4-Hour Response SLA", "Support SLA Guarantee", "24/7 Dedicated Architect". Conflicts with draft §10.2. [05 R8]
E8. "Live Supplier Price Sync … Beacon, ABC Supply, and Convoy Supply", "Custom Scrapers & APIs", versus the product page ("Import price lists from CSV files"). [05 R6]
E9. "Automatic renewal" / "Cancel anytime" / "Get Started Free" / "Annual (2 Months Free)", with no published renewal or refund terms. [05 R2]
E10. Competitor comparison ("Cost per User ~$129 / mo", "Procore / Buildertrend $400+ / mo") with no source or date. [05 R8]
E11. The site Privacy Policy excludes "enterprise software pilots" and says they are governed by signed agreements, yet self-serve sign-up has no signed-agreement step. [05 R4]

## Limits
- Regulations listed above were not reviewed, so their prescribed content is UNVERIFIED.
- PDF/HTML text extraction flattened some subsection labels (noted at V5).
- No website, implementation, billing or production system was accessed for 06.
