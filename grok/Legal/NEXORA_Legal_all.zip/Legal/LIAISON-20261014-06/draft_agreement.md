> **DRAFT — NOT LEGALLY APPROVED. Internal CEO review only. Not legal advice. Not for distribution to customers.**
> Status: **DRAFT_ONLY** | Task: LIAISON-20261014-06 | Prepared by: NEXORA Legal Counsel Desk (AI drafting assistant, not a lawyer) | Date: 2026-10-14
> Before any execution, a qualified lawyer must review the liability, IP, privacy and cross-border items (**REQUIRES QUALIFIED LEGAL REVIEW**).

# SUMMITOS CONTROLLED PAID PILOT AGREEMENT

**Drafting notes**
- SUMMITOS context comes only from https://nexorayyc.io/summitos, https://nexorayyc.io/products/summitos and https://summitos.nexorayyc.io, all fetched 2026-10-14.
- The public pages are inconsistent with each other. /products/summitos says "Limited pilot" and "Pricing is not finalised". The other two pages list Core $299 and Pro $599 with automatic renewal.
- The public pages also make claims this draft deliberately does **not** adopt: "guarantee profitability", "Cryptographic Multi-Tenancy", "Complete database isolation", "Priority 4-Hour Response SLA" and "24/7 Dedicated Architect". Each one is unverified.
- Statute names below are given for identification only. The Risk & Compliance Analyst must confirm section-level citations against official sources (Justice Laws, CanLII, Alberta King's Printer). They are marked UNVERIFIED where noted.

---

## 1. Parties
1.1 **NEXORA Technologies Corp.**, a corporation under [UNKNOWN — CEO/COUNSEL TO CONFIRM: jurisdiction of incorporation and corporate number], with its registered office at [UNKNOWN — CEO/COUNSEL TO CONFIRM: address], Calgary, Alberta ("**NEXORA**").
1.2 **[UNKNOWN — CEO/COUNSEL TO CONFIRM: Customer legal name]**, a [entity type/jurisdiction], with its address at [address] ("**Customer**").
1.3 Effective Date: [UNKNOWN — CEO/COUNSEL TO CONFIRM].
1.4 Order of precedence: [UNKNOWN — CEO/COUNSEL TO CONFIRM: does this Agreement stand alone, or does it sit under a NEXORA MSA/Order Form, and which document prevails?]

## 2. Pilot Scope and Duration
2.1 **Purpose.** NEXORA will give Customer access to SUMMITOS, a construction/contractor operations and estimating software service, on a controlled, limited pilot basis. The purpose is to evaluate the software in Customer's operations.
2.2 **Pilot nature.** Customer acknowledges that SUMMITOS is in a limited pilot stage. Features may be incomplete, may change, or may be withdrawn.
2.3 **Selected Plan and included features.** The Customer's plan is set out in Schedule A. The modules, features and seat limits included in each plan are [UNKNOWN — CEO/COUNSEL TO CONFIRM: module list and seat limits per plan. The public site states 10/25/unlimited seats, which isn't CEO-confirmed].
2.4 **Third-party supplier data.** Any supplier price-feed integrations (for example, supplier catalogs named on public pages) are provided only if and to the extent they are available. [UNKNOWN — CEO/COUNSEL TO CONFIRM: which integrations are live, and whether Customer must supply its own feeds/credentials.] NEXORA doesn't control the accuracy of supplier data.
2.5 **Pilot Term.** The pilot starts on [UNKNOWN — CEO/COUNSEL TO CONFIRM: start trigger] and continues for [UNKNOWN — CEO/COUNSEL TO CONFIRM: duration] (the "**Pilot Term**"), unless terminated earlier under Section 13.
2.6 **Workspace.** Customer will receive one company workspace. [UNKNOWN — CEO/COUNSEL TO CONFIRM: additional workspaces/entities.]
2.7 **Onboarding.** [UNKNOWN — CEO/COUNSEL TO CONFIRM: whether any onboarding or implementation service and fee applies during the pilot. Public pages list optional onboarding at $1,000/$2,500 CAD and Enterprise implementation at $5,000–$15,000+ CAD.]
2.8 **Feedback.** [UNKNOWN — CEO/COUNSEL TO CONFIRM: any Customer feedback, meeting or reporting obligations during the pilot.]

## 3. Fees and Billing
3.1 **Plans (CEO-approved pricing; CEO_APPROVED_COMMERCIAL_POLICY):**

| Plan | Fee |
|---|---|
| Foundation | CAD $299 per month |
| Live Intelligence | CAD $599 per month |
| Enterprise | Custom pricing per a separately signed order form [UNKNOWN — CEO/COUNSEL TO CONFIRM] |

[UNKNOWN — CEO TO CONFIRM: the public site calls these price points "SummitOS Core" and "SummitOS Pro". Confirm the official plan names.]
3.2 **Billing.** Fees are billed [UNKNOWN — CEO/COUNSEL TO CONFIRM: monthly in advance/arrears] in Canadian dollars by [UNKNOWN — CEO/COUNSEL TO CONFIRM: payment method]. Invoices are due within [UNKNOWN — CEO/COUNSEL TO CONFIRM: days].
3.3 **Late payment.** [UNKNOWN — CEO/COUNSEL TO CONFIRM: interest, suspension right and notice before suspension.]
3.4 **Proration and refunds.** [UNKNOWN — CEO/COUNSEL TO CONFIRM.]
3.5 **Additional seats/usage.** [UNKNOWN — CEO/COUNSEL TO CONFIRM.]

## 4. Renewal and Cancellation
4.1 **End of Pilot Term.** When the Pilot Term ends, [UNKNOWN — CEO/COUNSEL TO CONFIRM: one of (a) the Agreement ends unless Customer opts in to a subscription; (b) it converts automatically to a month-to-month subscription at the Plan fee; or (c) other]. Public pages state "automatic renewal" and "cancel anytime". Counsel must confirm the renewal-disclosure requirements (coordinate with the Risk & Compliance Analyst).
4.2 **Cancellation by Customer.** Customer may cancel by giving [UNKNOWN — CEO/COUNSEL TO CONFIRM: notice period and method]. Cancellation takes effect [UNKNOWN — CEO/COUNSEL TO CONFIRM: end of current billing period?].
4.3 **Renewal reminders.** [UNKNOWN — CEO/COUNSEL TO CONFIRM: whether NEXORA sends a reminder notice before conversion or renewal.]

## 5. Taxes
5.1 Fees exclude applicable taxes. Customer will pay the Goods and Services Tax (GST), and, depending on Customer's location, any applicable Harmonized Sales Tax (HST), provincial sales tax (PST) or Québec Sales Tax (QST). [UNKNOWN — CEO/COUNSEL TO CONFIRM: tax treatment by customer location, NEXORA's GST/HST registration number, and whether PST registrations are required (for example, BC/SK/MB). Accountant or counsel to confirm. NEEDS CONFIRMATION.]
5.2 Each party is responsible for its own income taxes.

## 6. Data Protection and Privacy — REQUIRES QUALIFIED LEGAL REVIEW
6.1 **Applicable law.** Each party will comply with the privacy laws that apply to it. These may include Alberta's *Personal Information Protection Act* (PIPA) and, where applicable, the federal *Personal Information Protection and Electronic Documents Act* (PIPEDA). [Citations UNVERIFIED in this draft; Risk & Compliance Analyst to confirm applicability and citations.]
6.2 **Roles.** For personal information that Customer enters into SUMMITOS (for example, employee, crew, time-tracking/GPS, payroll, client CRM and photo data), Customer is [UNKNOWN — CEO/COUNSEL TO CONFIRM: characterization, e.g. the organization in control, with NEXORA acting as a service provider processing only on Customer's instructions]. [UNKNOWN — COUNSEL TO CONFIRM: whether a separate Data Processing Agreement is required.]
6.3 **Customer responsibilities.** Customer is responsible for having the notices and consents needed for the personal information it enters into SUMMITOS, including location data collected from its personnel.
6.4 **Security.** NEXORA will use reasonable security safeguards appropriate to the sensitivity of the information. [UNKNOWN — CEO/COUNSEL TO CONFIRM: specific security commitments. This draft makes no tenant-isolation, encryption or "complete database isolation" representation. Any such statement must first be technically verified — NEEDS VERIFICATION.]
6.5 **Data residency / cross-border.** Customer data is hosted in [UNKNOWN — CEO/COUNSEL TO CONFIRM: hosting provider region(s)]. Customer data may be processed or stored outside Alberta and/or Canada by NEXORA's service providers. [REQUIRES QUALIFIED LEGAL REVIEW: cross-border notice obligations.]
6.6 **Subprocessors.** NEXORA uses third-party service providers to deliver SUMMITOS. Public product pages identify Supabase (database/edge functions) and reference Stripe (payments). [UNKNOWN — CEO/COUNSEL TO CONFIRM: complete subprocessor list, locations, and the notice mechanism for changes.]
6.7 **Security incidents.** NEXORA will notify Customer of a security incident affecting Customer's personal information [UNKNOWN — CEO/COUNSEL TO CONFIRM: timing and content], and the parties will cooperate on any notifications required by law. [Risk & Compliance Analyst to map PIPA/PIPEDA breach-notification requirements; citations UNVERIFIED.]
6.8 **Healthcare information.** Customer will not enter health information into SUMMITOS. [UNKNOWN — CEO/COUNSEL TO CONFIRM.]

## 7. Confidentiality
7.1 "**Confidential Information**" means non-public information that one party discloses to the other in connection with this Agreement and that is marked confidential, or would reasonably be understood to be confidential. It includes Customer's supplier pricing, bidding formulas and estimates, and NEXORA's software, pricing and product roadmap.
7.2 The receiving party will use Confidential Information only to perform or receive the pilot. It will protect the information with at least reasonable care, and will disclose it only to personnel and advisors who need to know it and are bound by similar obligations.
7.3 Exclusions: information that is public through no fault of the recipient; already known to the recipient; independently developed; or lawfully received from a third party. Disclosure is permitted where required by law, with notice to the other party where lawful.
7.4 Duration: [UNKNOWN — CEO/COUNSEL TO CONFIRM: survival period].

## 8. Intellectual Property and Customer Data — REQUIRES QUALIFIED LEGAL REVIEW
8.1 **NEXORA IP.** NEXORA and its licensors retain all rights in SUMMITOS, including its software, documentation, Summit Formula Language and any improvements. This Agreement doesn't transfer any ownership.
8.2 **Licence to Customer.** During the Pilot Term, NEXORA grants Customer a non-exclusive, non-transferable, revocable right for its authorized users to use SUMMITOS for Customer's internal business purposes.
8.3 **Customer Data.** As between the parties, Customer owns the data it submits ("**Customer Data**"). Customer grants NEXORA a licence to host, process and use Customer Data only as needed to provide and support SUMMITOS. [UNKNOWN — CEO/COUNSEL TO CONFIRM: whether NEXORA may use aggregated/de-identified data for product improvement. Ownership of Customer-created formulas, templates and outputs.]
8.4 **Feedback.** [UNKNOWN — CEO/COUNSEL TO CONFIRM: licence to use Customer feedback.]
8.5 **Publicity.** Neither party may use the other's name or logo without prior written consent. [UNKNOWN — CEO TO CONFIRM: reference-customer rights.]

## 9. Acceptable Use
Customer will not, and will not allow anyone else to:
(a) use SUMMITOS in violation of law or third-party rights;
(b) reverse engineer, copy, resell or sublicense SUMMITOS, or build a competing product from it;
(c) upload malicious code, or interfere with or probe the security of the service;
(d) access other customers' data, or share credentials beyond the authorized seats;
(e) load data it doesn't have the right to use, including supplier data restricted by supplier terms;
(f) send unlawful commercial electronic messages through the notification features (see Section 14).
[UNKNOWN — CEO/COUNSEL TO CONFIRM: any additional restrictions; whether a separate AUP document governs.]

## 10. Support
10.1 NEXORA will provide pilot support through [UNKNOWN — CEO/COUNSEL TO CONFIRM: channels, e.g. email] during [UNKNOWN — CEO/COUNSEL TO CONFIRM: hours, time zone].
10.2 **No service levels.** Unless a separately signed service level schedule says otherwise, NEXORA makes no commitment on uptime, availability, response time or resolution time. [NOTE: public pages advertise a "Priority 4-Hour Response SLA" and "24/7 Dedicated Architect". These are NOT adopted and are unverified. CEO to decide.]
10.3 Maintenance windows and planned changes: [UNKNOWN — CEO/COUNSEL TO CONFIRM].

## 11. Warranties and Disclaimers — REQUIRES QUALIFIED LEGAL REVIEW
11.1 Each party warrants that it has the authority to enter into this Agreement.
11.2 [UNKNOWN — CEO/COUNSEL TO CONFIRM: any limited performance warranty by NEXORA.]
11.3 **Disclaimer.** Except as expressly stated, SUMMITOS is provided during the pilot "as is" and "as available". To the extent permitted by law, NEXORA disclaims all other warranties and conditions, express or implied, including merchantability, fitness for a particular purpose and non-infringement. [Counsel to confirm wording and enforceability under Alberta law.]
11.4 **No business outcome guarantee.** NEXORA does not guarantee profitability, margin protection, estimate accuracy, supplier price accuracy or business results. Customer remains responsible for reviewing estimates, prices, invoices, payroll, tax, safety/OHS and compliance outputs before relying on them. [NOTE: conflicts with the public claim to "guarantee profitability". Flag to the CEO.]

## 12. Limitation of Liability — REQUIRES QUALIFIED LEGAL REVIEW
12.1 **Cap.** Each party's total liability under this Agreement will not exceed [UNKNOWN — CEO/COUNSEL TO CONFIRM: cap amount/formula].
12.2 **Excluded damages.** Neither party is liable for indirect, incidental, special, consequential or punitive damages, or for lost profits, revenue or data. [UNKNOWN — COUNSEL TO CONFIRM scope.]
12.3 **Carve-outs.** [UNKNOWN — CEO/COUNSEL TO CONFIRM: exclusions from the cap, e.g. confidentiality breach, Customer payment obligations, IP infringement, data/privacy breach, gross negligence or wilful misconduct.]
12.4 **Indemnities.** [UNKNOWN — CEO/COUNSEL TO CONFIRM: whether any indemnities are included.]

## 13. Termination and Data Return
13.1 Either party may terminate for convenience on [UNKNOWN — CEO/COUNSEL TO CONFIRM: notice].
13.2 Either party may terminate on written notice if the other materially breaches and fails to cure within [UNKNOWN — CEO/COUNSEL TO CONFIRM: days].
13.3 NEXORA may suspend access as needed to address a security risk or a breach of Section 9. [UNKNOWN — CEO/COUNSEL TO CONFIRM: notice requirements.]
13.4 **Effect.** On termination, access ends, and Customer pays fees accrued to the termination date. [Refunds: UNKNOWN — CEO/COUNSEL TO CONFIRM.]
13.5 **Data return.** For [UNKNOWN — CEO/COUNSEL TO CONFIRM: period] after termination, Customer may export its Customer Data in [UNKNOWN — CEO/COUNSEL TO CONFIRM: format, e.g. CSV]. After that, NEXORA will delete Customer Data within [UNKNOWN — CEO/COUNSEL TO CONFIRM], except for backups and records it must keep by law. [Privacy retention rules: Risk & Compliance Analyst.]
13.6 **Survival.** Sections [UNKNOWN — COUNSEL TO CONFIRM list, e.g. 5, 7, 8, 11.3–11.4, 12, 13.4–13.6, 15] survive.

## 14. Communications and CASL Consent
14.1 **Operational messages.** NEXORA may send Customer service, billing, security and account messages relating to the pilot.
14.2 **Marketing consent (optional, separate).** ☐ Customer's signatory consents to receive commercial electronic messages from NEXORA Technologies Corp. about NEXORA products and services. They can withdraw this consent at any time using the unsubscribe mechanism in each message or by contacting [UNKNOWN — CEO TO CONFIRM: contact address]. [Consent must be a separate, opt-in action, not pre-checked. Requirements under Canada's Anti-Spam Legislation (S.C. 2010, c. 23) — citation UNVERIFIED — to be confirmed by the Risk & Compliance Analyst.]
14.3 **Customer's own messages.** When Customer uses the SUMMITOS notification features (SMS/email) to message its own clients or subcontractors, Customer is responsible for obtaining the consents and including the identification and unsubscribe content required by law. [REQUIRES QUALIFIED LEGAL REVIEW: sender characterization.]
14.4 **Notices.** Legal notices go to the addresses in Section 1 by [UNKNOWN — CEO/COUNSEL TO CONFIRM: method].

## 15. Governing Law — PLACEHOLDER
15.1 [PLACEHOLDER — PENDING COUNSEL] This Agreement is governed by the laws of the Province of Alberta and the federal laws of Canada that apply there. The parties attorn to the courts of [UNKNOWN — COUNSEL TO CONFIRM: Calgary, Alberta?].
15.2 Dispute resolution: [UNKNOWN — COUNSEL TO CONFIRM: negotiation, mediation or arbitration].
15.3 General: entire agreement, amendment in writing, assignment, force majeure, severability, independent contractors, counterparts and electronic signature [UNKNOWN — COUNSEL TO CONFIRM: wording; Alberta Electronic Transactions Act citation UNVERIFIED].

## 16. Signatures

| NEXORA Technologies Corp. | [Customer Legal Name] |
|---|---|
| By: ____________________ | By: ____________________ |
| Name: [UNKNOWN — CEO TO CONFIRM] | Name: |
| Title: | Title: |
| Date: | Date: |

*I have authority to bind the corporation.*

### Schedule A — Plan Selection
☐ Foundation (CAD $299/month) ☐ Live Intelligence (CAD $599/month) ☐ Enterprise (custom — see order form)
Seats: [UNKNOWN] | Pilot Term: [UNKNOWN] | Onboarding: [UNKNOWN]

---

## Open Questions
## A. CEO decisions (commercial)
1. Tier names: the agreement uses the CEO-approved "Foundation" ($299) and "Live Intelligence" ($599). Public pages call the same price points "SummitOS Core" and "SummitOS Pro". Which names are the official ones?
2. Pilot term length (for example, 60 or 90 days) and its start date trigger (signature, provisioning or go-live).
3. What happens at the end of the pilot: automatic conversion to a paid subscription, renewal month-to-month, or ending unless the customer opts in? Public pages say "automatic renewal" and "cancel anytime".
4. Notice period for cancellation, and whether fees are prorated or refunded.
5. Billing: monthly in advance or in arrears, payment method, invoice due date, and late-payment interest (if any).
6. Seat limits per tier. Public pages say 10 and 25, which isn't CEO-confirmed.
7. Which modules and features are in each tier during the pilot. Public pages list features (for example, live supplier sync for Beacon, ABC and Convoy) whose readiness isn't verified.
8. Onboarding fees. Public pages list $1,000, $2,500 and $5,000–$15,000+ CAD. Do any of them apply to the pilot?
9. Enterprise pilot pricing and scope: a separate order form, or out of scope for this template?
10. Support: channels, hours and any response-time commitment. Public pages say "Priority 4-Hour Response SLA" and "24/7 Dedicated Architect", which aren't verified and aren't included in the draft.
11. Pilot feedback obligations and whether NEXORA can use the customer's name or logo as a reference.
12. Number and maximum count of pilot customers. Is there any eligibility criterion (roofing and exterior contractors only)?
13. Should the public website claims ("guarantee profitability", "cryptographic multi-tenancy", "complete database isolation", "SLA guarantees") be fixed before the pilot starts? They conflict with the disclaimers in the draft. Route to the website owner.
14. Who signs for NEXORA (name and title)?
15. Data return format and the window for the customer to export data after termination.
16. Fee for extra seats or additional usage, if any.

## B. Counsel decisions (REQUIRES QUALIFIED LEGAL REVIEW)
17. Liability cap amount and structure (for example, fees paid in the last X months), plus carve-outs (confidentiality, IP infringement, data breach, gross negligence or wilful misconduct).
18. Exclusion of indirect and consequential damages, and whether it's enforceable as drafted.
19. Whether to include indemnities, and in which direction (IP infringement by NEXORA; customer data and content).
20. IP: ownership of customer data, outputs and estimates; licence to aggregated or de-identified data; feedback licence; Summit Formula Language (SFL) formulas the customer creates.
21. Privacy: whether NEXORA acts as a service provider/processor under Alberta PIPA and PIPEDA for customer-entered personal information (GPS time tracking, crew, payroll, client CRM, photos). Is a separate DPA needed?
22. Data residency: where Supabase (and Stripe, if used) host and process data. Cross-border transfer notice obligations. Hosting region is unknown.
23. Subprocessor list (Supabase confirmed on the public page; Stripe referenced; others unknown) and the change-notice mechanism.
24. Security incident and breach notification terms (PIPA s. 34.1 notification to the Commissioner; PIPEDA breach of security safeguards). Citations to be verified by the Risk & Compliance Analyst.
25. CASL: whether the SMS and email notification feature makes the customer or NEXORA the sender of commercial electronic messages, and the consent allocation between them.
26. Governing law and venue (Alberta is a placeholder) and any dispute resolution or arbitration.
27. Taxes: GST, plus HST, PST or QST depending on the customer's location, and NEXORA's registration status. Confirm with an accountant or counsel.
28. Warranty disclaimer wording and its enforceability, including the "beta/pilot" as-is framing.
29. Whether the payroll, OHS safety and WCB modules create any regulatory reliance risk that needs a specific disclaimer.
30. E-signature validity and the counterparts clause (Alberta Electronic Transactions Act). Citation unverified.
31. Survival clause list and order of precedence with any order form or MSA.

---
> **DRAFT — NOT LEGALLY APPROVED. Internal CEO review only. Not legal advice. Not for distribution to customers.** Status: DRAFT_ONLY
