# LIAISON-20261014-06 — Changelog v1 → v2
**DRAFT — NOT LEGALLY APPROVED.** Internal CEO review only. Not legal advice. Status: DRAFT_ONLY. v1 (draft_agreement.md) left unchanged.
Sources: **CEO** = CEO commercial directions relayed by NEXORA Liaison, 2026-10-14 (CEO_APPROVED_COMMERCIAL_POSITION). **V#** = compliance_review.md citation table.

| Section | Change | Source |
|---|---|---|
| Header | Marked v2, added classification labels and note that regulations weren't reviewed | Charter / V-table limits |
| §2.3, §2.4, §3.1, §3.6, Sch. A | Tier features, modules, integrations and seat limits set to [UNKNOWN — pending Argon verification…]; removed reference to public 10/25/unlimited seats | CEO |
| §2.5 | Pilot Term = 90 days; start trigger still UNKNOWN | CEO |
| §2.6 (new), §4.1, §13.1, §8.2, §3.3 | Pilot ends at 90 days; no renewal, extension or auto-conversion; continued use only by affirmative opt-in to a separate agreement; licence and charges end with the term | CEO |
| §4 (v1 4.1, 4.3) | Removed the convert / month-to-month renewal options and "renewal reminder before conversion"; replaced with optional end-of-pilot notice (UNKNOWN). Section retitled "End of Pilot and Cancellation" | CEO |
| §4.2 | Cancellation notice kept UNRESOLVED | CEO (keep unresolved) |
| §4.4 (new) | Consumer note citing CPA s.6(4)(t.1) and ISCR ss.4–6; applicability for counsel | compliance A13–A14, B9 |
| §2.8 (v1 2.7), Sch. A | Onboarding quoted separately, explicit written approval, no automatic charge; public fee amounts not adopted | CEO |
| §3.1 | Tier names → Foundation Pilot / Live Intelligence Pilot / Enterprise Pilot (custom, by agreement); removed Core/Pro naming question | CEO |
| §3.2 (new) | Billing starts only after Acceptance + authorized onboarding + authorized payment arrangements | CEO |
| §3.3 | Monthly in advance, CAD; payment method and due date UNKNOWN | CEO |
| §3.5, §13.5 | Refunds and proration UNRESOLVED; added 90-day vs monthly-cycle alignment question | CEO (keep unresolved) |
| §5 | Removed the substantive GST/HST/PST/QST statement; whole clause UNRESOLVED and UNVERIFIED | V8, CEO (keep unresolved) |
| §6.1 | Added PIPA SA 2003, c P-6.5; PIPEDA SC 2000, c 5, s.4(1) | V1, V2 |
| §6.5 | Added PIPA s.13.1(1)–(4) and s.6(2)–(3); countries UNKNOWN | V3 |
| §6.7 | Added PIPA s.34.1(1)–(2) (individual notice by regulation: UNVERIFIED); corrected PIPEDA to s.10.1(1), s.10.1(3), other-organizations subsection (number UNVERIFIED), s.10.3(1) | V4, V5 |
| §6 (whole), §8, §12, §13.6 | Marked UNRESOLVED; v1 substantive damages-exclusion text in §12.2 and v1 data-return mechanics (CSV etc.) replaced with UNKNOWN markers | CEO (keep unresolved) |
| §6.4, §6.6 | Removed naming of Supabase/Stripe as subprocessors (pending Argon D1–D2); no security representations | Compliance D-list; CEO (no invented commitments) |
| §14.2 | CASL cited as SC 2010, c 23, s.6(1)–(2), s.10(1), s.10(9)–(10), s.11; opt-in practice flagged as non-binding CRTC guidance | V6 |
| §15.3 | Added ETA SA 2001, c E-5.5, ss.8, 16, 27; counterparts noted as drafting point | V7 |
| §13.2 | Termination for convenience now an open question (fixed term) | CEO (consequential) |
| §16 | Added "not to be signed" placeholder note | Charter |

## Correction (CEO-approved, via NEXORA Liaison, 2026-10-14)
- §6.7: changed the PIPEDA reference for notifying other organizations from "the s.10.1 subsection on notifying other organizations (subsection number UNVERIFIED)" to "s.10.2(1)". Verified by Risk & Compliance Analyst in compliance_review_v2.md. Nothing else changed. Website observations referenced in these documents are pre-release (before SUMMITOS Gate A was deployed) and haven't been re-verified.
