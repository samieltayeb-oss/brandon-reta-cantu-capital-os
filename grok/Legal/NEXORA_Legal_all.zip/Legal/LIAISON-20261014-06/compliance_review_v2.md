# Compliance Review v2 — TASK LIAISON-20261014-06 — draft_agreement_v2.md
Status: EVIDENCE_SUBMITTED · Advisory research only, not legal advice · 2026-10-14 ~02:45 MT (UTC-6)
Read-only review of draft_agreement_v2.md against changes_v2.md, open_questions_v2.md, compliance_review.md (v1) and the official texts in ./sources/. Nothing was edited. No compliance conclusions are made. Buckets A–E as in v1. Each point appears once.

## 1. CEO directions: application check
| Direction | v2 location | Result |
|---|---|---|
| 90-day term | §2.5 "ninety (90) days"; Sch. A "Pilot Term: 90 days" | APPLIED. Start trigger UNKNOWN (§2.5). |
| Ends unless the customer affirmatively opts in | §2.6, §4.1, §8.2, §13.1, §3.3 last sentence, Sch. A | APPLIED. |
| Billing monthly in advance, only after acceptance and authorization | §3.2 (a)–(c); §3.3 "monthly in advance" | APPLIED. "Authorized" is undefined (§3.2 UNKNOWN). |
| No automatic onboarding charges | §2.8 "No onboarding fee is charged automatically"; Sch. A | APPLIED. Public amounts are expressly not adopted. |
| Features and seats UNKNOWN pending Argon | §2.3, §2.4, §3.1, §3.6, Sch. A | APPLIED. |

**Whole-draft search for renewal or conversion wording** (searched for automatic, renew, convert, conversion, auto-). Every hit is negating or descriptive; none grants renewal or conversion:
- Line 12 (drafting note): "Public claims of … automatic renewal are **not** adopted."
- §2.6: "end automatically at the end of the Pilot Term. They do not renew, extend or convert into any paid subscription or other agreement."
- §4.1: "This Agreement contains no automatic renewal, extension or conversion."
- §4.3: "Any such notice must not imply automatic continuation."
- §4.4: "(disclosure of and express consent to renewals)", a statutory description only.
- Sch. A: "Pilot Term: 90 days, no automatic conversion"
No leftover v1 convert or month-to-month option text was found.

## 2. Citation corrections: accuracy check
| V# | v2 text | Result |
|---|---|---|
| V1 | PIPA SA 2003, c P-6.5 (§6.1) | ACCURATE |
| V2 | PIPEDA SC 2000, c 5, s.4(1) (§6.1) | ACCURATE |
| V3 | PIPA s.13.1(1)–(4), s.6(2)–(3) (§6.5) | ACCURATE |
| V4 | PIPA s.34.1(1)–(2); individual notice by regulation UNVERIFIED (§6.7) | ACCURATE |
| V5 | PIPEDA s.10.1(1), s.10.1(3), "the s.10.1 subsection on notifying other organizations (subsection number UNVERIFIED)", s.10.3(1) (§6.7) | **NEEDS CORRECTION.** Re-checking sources/P-8.6.txt, the other-organizations duty is **PIPEDA s.10.2(1)** ("Notification to organizations 10.2 (1) An organization that notifies an individual … under subsection 10.1(3) shall notify any other organization…"), not a subsection of s.10.1. My v1 V5 entry was imprecise. Source: https://laws-lois.justice.gc.ca/eng/acts/P-8.6/FullText.html |
| V6 | CASL SC 2010, c 23, s.6(1)–(2), s.10(1), s.10(9)–(10), s.11 (§14.2) | ACCURATE. CRTC opt-in correctly labelled as non-binding guidance. |
| V7 | ETA SA 2001, c E-5.5, ss.8, 16, 27 (§15.3) | ACCURATE |
| V8 | §5 tax clause UNRESOLVED and UNVERIFIED | ACCURATE (left unresolved) |
| Extra | §4.4 CPA s.6(4)(t.1); ISCR ss.4–6 | ACCURATE to v1 A13–A14; applicability left to counsel |
| Extra | §6.4 "cf. PIPA s.34"; §13.6 "cf. PIPA s.35"; §6.2 PIPA s.5(2), PIPEDA Sch.1 cl.4.1.3 | ACCURATE to v1 A4–A6 |
Drafting-note caveat (line 9) that VERIFIED_PRIMARY_AUTHORITY means the text only, not its application: consistent with v1.

## 3. Invented commitments check
No new guarantees, SLAs, security, residency or capability representations were found. v2 removed the Supabase and Stripe naming (§6.6) and the v1 damages-exclusion and data-return specifics, and replaced them with UNKNOWN markers.
Commitments carried over from v1: §6.4 "reasonable security arrangements"; §6.7 to notify Customer (timing UNKNOWN); §2.7 one workspace; §13.4 suspension right. These remain for counsel and CEO confirmation (C6, B6).

---
## (A) CONFIRMED LEGAL REQUIREMENTS (verified text)
A1. PIPEDA s.10.2(1): an organization that notifies an individual under s.10.1(3) shall notify any other organization or government institution that may be able to reduce or mitigate the risk of harm. https://laws-lois.justice.gc.ca/eng/acts/P-8.6/FullText.html
A2. All v1 A1–A14 remain applicable and unchanged (compliance_review.md). Section numbers cited in v2 match them, except V5 above.

## (B) LEGAL INTERPRETATIONS REQUIRING COUNSEL
B1. Correct §6.7 to cite PIPEDA s.10.2(1) for notifying other organizations. Allocation of breach duties is still open (v1 B5).
B2. **Q34 / §2.6 versus live checkout:** customers could still subscribe through the public self-serve flow, which advertises "automatic renewal". If a customer did, which terms govern (§1.4 order of precedence is UNKNOWN)? And could the CPA s.6(4)(t.1) express-consent-to-renewal requirement be engaged for an individual consumer? Interpretation only.
B3. **Q33 opt-in mechanics:** whether the follow-on agreement creates a fresh PIPA s.13 / s.13.1 notice point, and whether data continuity rather than export or deletion needs fresh notice or consent (PIPA ss.13, 13.1, 35).
B4. **§4.3 end-of-pilot notice:** a notice promoting the opt-in or paid subscription may be a commercial electronic message. Whether it falls under implied consent (CASL s.10(10) existing business relationship) and must carry s.6(2) identification and an unsubscribe mechanism.
B5. **Termination for convenience (§13.2 open) versus §4.2 customer cancellation:** these overlap. Counsel to reconcile the two, and to settle the refund treatment of a month billed in advance when cancellation or termination happens mid-cycle (§3.5, §13.5 "fees properly accrued"). For consumers, ISCR s.6 and its cancellation-effect provisions may also apply (B9 in v1).
B6. Carried-over commitments in §6.4, §6.7 and §13.4: confirm wording.
B7. All v1 B1–B13 still open as marked in v2.

## (C) CEO COMMERCIAL DECISIONS
C1. **Q32:** a 90-day term with monthly billing in advance gives a partial third or fourth cycle. Decide whether to prorate, bill three full months, or align the term to the billing date.
C2. Start trigger (§2.5) versus billing start (§3.2): if the term starts before billing conditions are met, decide whether the unbilled days count toward the 90 days.
C3. Define "authorized onboarding" and "authorized payment arrangements" and who authorizes them (§3.2).
C4. **Q33:** form of the opt-in agreement and data continuity choices. **Q34:** disable self-serve sign-up before any pilot. Route to the website and billing owner.
C5. Whether either party gets termination for convenience, and on what notice (§13.2), together with the §4.2 cancellation notice.
C6. Whether to send the §4.3 courtesy notice. Also the remaining v1 C-items: payment method, due date, support, signer, export window.

## (D) TECHNICAL FACTS REQUIRING ARGON VERIFICATION (list only)
D1. Features, modules and seat entitlement enforcement per Pilot Plan (§2.3, §3.6).
D2. Whether billing can be technically held until the §3.2 conditions are met, and stopped automatically at day 90 (§3.3). This bears on the Stripe self-serve flow.
D3. Hosting regions, subprocessors, isolation, encryption, backup retention (v1 D1–D4, D7).
D4. Data continuity and export capability at the end of the pilot (Q33, §13.6).

## (E) UNSUPPORTED OR INCONSISTENT PUBLIC CLAIMS
E1. Public "automatic renewal" / "cancel anytime" copy and live self-serve Stripe checkout now directly conflict with v2 §2.6 and §4.1 (no renewal or conversion) and §3.2 (billing only after acceptance and authorization). [05 R2; raw/summitos.nexorayyc.io_signup.html.txt]
E2. Public "Core"/"Pro" names versus v2 "Foundation Pilot" / "Live Intelligence Pilot" / "Enterprise Pilot". v2 also adds the "Pilot" suffix, which differs from the v1 brief's "Foundation / Live Intelligence"; the CEO should confirm the final naming.
E3. Public onboarding amounts ($1,000 / $2,500 / $5,000–$15,000+ CAD) versus v2 §2.8 (quoted separately, not adopted).
E4. Public seat counts (10 / 25 / unlimited) versus v2 UNKNOWN pending Argon.
E5. v1 E3–E8, E10–E11 unchanged (404 legal links, residency, profitability, isolation, SLA, supplier sync, comparison, privacy-policy pilot exclusion).

## Limits
Regulations are still not reviewed. The new initial_risk_assessment.md in the folder was not part of this brief and was not reviewed.
