**FOR QUALIFIED COUNSEL REVIEW, NOT FOR SIGNATURE. NOT LEGAL ADVICE.**

# HNH Immigration — Contract Structure Recommendation (LIAISON-HNH-20261014-39)
Prepared by NEXORA Legal Counsel Desk (AI drafting assistant — **not a lawyer**). Structure, outlines and brief clause notes only; not full drafts. Earlier folders unchanged.

**Citation convention.** Marked VERIFIED only where verified in earlier NEXORA files (LIAISON-20261014-06: changes_v2.md, compliance_review_v2.md V3–V5/A1, schedule_a_review_v3_1.md A3–A4): Alberta PIPA s.6(2)–(3), s.13.1(1)–(4), s.34.1(1)–(2); PIPEDA s.10.1(1)–(3), s.10.2(1). Their *application* to HNH is REQUIRES_LICENSED_COUNSEL. Everything else is UNVERIFIED.

**Key facts / UNKNOWNs.** HNH holds highly sensitive immigration client data. Whether HNH is a law firm, an RCIC practice, or both: UNKNOWN. HNH location(s) and activities: UNKNOWN. CaseEasy (third-party case-management platform) terms, hosting location, API availability and subprocessors: UNKNOWN. NEXORA's own hosting for any HNH work: UNKNOWN. Argon is NEXORA's technical authority.

---

## 1. Document set and signing order
1. **Mutual NDA** (reused GTM-31, HNH changes in §2) — signed first, before any substantive discovery.
2. **DPA** — required **before** any NEXORA access to personal information or to CaseEasy/HNH systems. NOT YET DRAFTED (GTM-29).
3. **Discovery & Design SOW** (GTM-31 SOW as revised per GTM-32/33 notes).
4. Later: scoped proposal → separate implementation SOW/MSA (NOT YET DRAFTED).

**Design principle (recommended):** run D&D **without live client data** where possible — process walkthroughs led by HNH staff, screenshots with client details removed, sample or synthetic data, CaseEasy documentation. If that is achievable, the DPA could be deferred [BRACKET — CEO/COUNSEL: whether to sign a DPA anyway given sensitivity]. Any access to live data or systems = DPA precondition, no exceptions.

## 2. NDA — reuse GTM-31 mutual NDA, HNH-specific changes
| NDA clause | Change |
|---|---|
| §1 Purpose | Widen to cover the free assessment (if any), Discovery & Design, and a scoped proposal for CaseEasy-related technology work. |
| §2 Confidential Information | Expressly include HNH's business, workflow and system information; state that **client personal information is not exchanged under the NDA**. |
| §10 No Personal Information | Keep; route any personal information to the DPA; add inadvertent-receipt handling (stop, notify, delete) [BRACKET — COUNSEL]. |
| New — Privilege | If HNH includes lawyers or regulated immigration consultants, protect solicitor-client privilege and professional confidentiality: NEXORA access must not waive privilege; NEXORA personnel treat any such material under need-to-know [BRACKET — REQUIRES_LICENSED_COUNSEL; HNH status UNKNOWN]. |
| §11 Term and Survival | Longer survival for HNH information [BRACKET — period — COUNSEL]; consider indefinite survival for privileged material (counsel). |
| §7 Return or Destruction | Return or destroy on request/end of discussions with written confirmation [BRACKET — timing, backup exception — COUNSEL]. |
| §13 Governing law | [Alberta — PLACEHOLDER PENDING COUNSEL]; HNH location UNKNOWN. |

## 3. Discovery & Design SOW — HNH-specific notes
- **Base:** GTM-31 SOW revised per GTM-32 notes and GTM-33 sow_notes_dd_addition.md.
- **Scope:** map current CaseEasy workflows; identify integration and automation options (subject to CaseEasy terms/API — UNKNOWN); solution design; implementation plan; estimate; scoped proposal.
- **Argon's role:** Argon is NEXORA's internal technical authority. No representation to HNH about NEXORA, SUMMITOS or CaseEasy capability unless Argon has verified it; unverified items labelled as such. No SUMMITOS components or demos with HNH data.
- **No production changes** to CaseEasy or any HNH system.
- **Access:** none by default; read-only access only under a signed DPA and written access schedule [BRACKET — access scope, accounts, logging — CEO/COUNSEL/Argon]. CaseEasy terms may restrict third-party access — UNKNOWN; HNH to confirm it is permitted.
- **Fee:** [CAD amount — PENDING CEO PRICE APPROVAL]; deposit and credit toward implementation [BRACKET — CEO].
- **Deliverables:** design document and scoped proposal, non-binding until a separate SOW or MSA is signed; no guarantees; interim s.74.01 claims rule (GTM-29 §9).
- **NO-IMMIGRATION-ADVICE boundary:** NEXORA provides technology services only. It gives no immigration or legal advice, does not prepare, review or decide anything on client files, and does not communicate with HNH's clients or with government bodies. HNH remains solely responsible for all professional, regulatory and client obligations. Relevant regulators (e.g. College of Immigration and Citizenship Consultants; Law Society of Alberta or another law society) and their rules on outsourcing/technology providers: UNKNOWN — REQUIRES_LICENSED_COUNSEL.
- **IP, acceptance, termination, no auto-conversion, governing law:** as in GTM-33 D&D notes (brackets unchanged).

## 4. DPA outline
| Topic | Outline note |
|---|---|
| Roles | HNH = organization in control of the personal information; NEXORA = service provider/processor acting only on HNH's documented instructions (REASONED_LEGAL_INTERPRETATION, per GTM-29). Whether PIPA (Alberta) or PIPEDA (or both) applies depends on HNH's location and activities — UNKNOWN; REQUIRES_LICENSED_COUNSEL. |
| Data types | Client identity and contact data; immigration status and history; identity documents (passports, permits); possibly health, criminal-record, family and financial information. Treat all as **sensitive**, requiring heightened safeguards. Exact categories: HNH to confirm. |
| Purpose limitation | Use only to perform the D&D SOW; no other use. |
| No secondary use | **No use of HNH data for AI/model training, analytics, product development (incl. SUMMITOS), marketing or aggregate learning.** |
| Security safeguards | [BRACKET — controls to be specified by Argon and approved by CEO/COUNSEL; none proposed here]. |
| Cross-border | Hosting locations of NEXORA tools, CaseEasy and their subprocessors: UNKNOWN. If a service provider outside Canada is used: PIPA s.13.1(1)–(4) notice and s.6(2)–(3) policy requirements (VERIFIED text, LIAISON-06 V3); PIPEDA cross-border position UNVERIFIED. Application — COUNSEL. |
| Subprocessors | List UNKNOWN; prior notice or prior approval [BRACKET — CEO/COUNSEL]; flow-down of obligations. |
| Breach notice | NEXORA notifies HNH within [BRACKET — timing — CEO/COUNSEL] of becoming aware; cooperation on HNH's obligations, e.g. PIPA s.34.1(1)–(2) (VERIFIED text) and PIPEDA s.10.1(1)–(3), s.10.2(1) (VERIFIED text). Which applies — COUNSEL. |
| Access/correction requests | NEXORA assists HNH and forwards any request received; does not respond directly. |
| End of engagement | Return or deletion with written certificate within [BRACKET — timing — CEO/COUNSEL]; backup exception [BRACKET — COUNSEL]. |
| Audit/reporting | [BRACKET — audit rights or reporting/attestation — CEO/COUNSEL]. |
| Liability and insurance | Link DPA liability (possible data super-cap) to SOW cap and confirmed E&O/cyber insurance (UNKNOWN) [BRACKET — CEO/COUNSEL]. |
| Precedence | DPA prevails over SOW/NDA on personal information (per GTM-29 proposed precedence). |

## 5. Risk flags
- **HIGH sensitivity** data and possible privileged material.
- **NEXORA readiness:** the SUMMITOS hardcoded-tenant issue in supplier email ingestion (reported by Argon) shows multi-tenant isolation risk. **No HNH data may enter SUMMITOS** or any shared multi-tenant NEXORA tool; Argon to confirm the environment used for any access.
- No DPA template exists yet; security controls undefined; insurance status UNKNOWN.
- CaseEasy terms may prohibit or limit third-party access/API use — UNKNOWN.
- **Risk & Compliance review required** before any document is sent to HNH.

### REQUIRES_LICENSED_COUNSEL
1. HNH's status (law firm, RCIC practice, both) and the effect on privilege, confidentiality and regulator rules for technology providers.
2. PIPA vs PIPEDA applicability; cross-border notice; breach-notice allocation.
3. Wording of the no-immigration-advice boundary and whether NEXORA's work could be seen as providing immigration advice (Immigration and Refugee Protection Act — UNVERIFIED).
4. NDA survival and privilege clause; return/destruction mechanics.
5. DPA liability, super-cap and insurance link; audit rights.
6. Whether CaseEasy's terms permit NEXORA access.

### CEO decisions
1. Whether to pursue HNH given sensitivity and current readiness.
2. Design D&D to avoid live data (recommended) and whether to sign a DPA regardless.
3. Fee, deposit, credit, cap (pending price approval).
4. Subprocessor approval model, breach-notice timing, deletion timing (with counsel).
5. Approve Argon-defined security controls and environment.

### UNKNOWNs
HNH legal status, location(s) and regulators; data categories held; CaseEasy terms, hosting, API and subprocessors; NEXORA hosting and subprocessors; insurance coverage; whether HNH has its own DPA paper.

**FOR QUALIFIED COUNSEL REVIEW, NOT FOR SIGNATURE. NOT LEGAL ADVICE.**
