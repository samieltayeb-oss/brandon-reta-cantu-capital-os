**FOR QUALIFIED COUNSEL REVIEW. STOP FOR CEO REVIEW. NOT LEGAL ADVICE.**

# HNH 36-Slide Proposal — Legal Addendum Review (LIAISON-HNH-20261014-39-ADDENDUM)
Prepared by NEXORA Legal Counsel Desk (AI drafting assistant — **not a lawyer**). Sources read-only: `/workspace/strategy/LIAISON-HNH-20261014-39/context/PROPOSAL_SUMMARY_FOR_BOTS.md` and `proposal_text.md` (extracted from HNH_proposal_36.pptx). Reviewed against `structure_recommendation.md` (this folder). "S#" = slide; "S#n" = speaker notes.

**Threshold fact (UNKNOWN, affects every rating):** whether Zain received the .pptx file (speaker notes travel with the file and are readable) or only a PDF/presentation view. Several of the strongest statements are in the notes. Also, S36n says "Do not send this presentation to HNH … until the user approves the final result", while the CEO reports it was sent; whether the CEO approved the sent version is UNKNOWN.

**Recurring disclaimer on every slide (quoted once):** "All systems, workflows and commercial packages are proposed. Final agreement defines scope, access, acceptance, ownership, service limits and third-party costs. No external publication or launch is authorized by this deck."

---

## 1. Issues

| # | Issue | Exact wording (location) | Analysis | Rating |
|---|---|---|---|---|
| 1 | **Offer / contract formation** | "This is not a binding quote." (S18); "This is NEXORA's sales recommendation, not a finalized binding quotation." (S18n); "Every phase still needs an agreed scope and approval to begin." (S18); "Final commercial terms will be agreed before kickoff." (S20n); "All pricing remains subject to agreement." (S25) — against: **"Thank you for choosing NEXORA"** (S36 title); "Confirm the pilot and credit terms" (S36); "Would you be comfortable starting with WhatsApp…?" (S36n) | Specific prices, defined packages and a closing ask could be read as an offer capable of acceptance if Zain replies "yes, start WhatsApp First". The disclaimers and "subject to final agreement" language point the other way (an invitation to negotiate), but that is a counsel question, not a conclusion. "Thank you for choosing NEXORA" suggests a choice has been made. S36n ("not recorded contract acceptance") is internal-facing. | **CRITICAL** |
| 2 | **Free website commitment** | "Premium HNH website — CA$5,900 development fee waived"; "NEXORA charge CA$0" (S15); "NEXORA has agreed to waive its previously proposed CA$5,900 premium website development fee within the approved partnership scope." (S15n); "with the website development fee waived" (S19) | "Has agreed to waive" reads as a commitment, not a proposal. Unclear whether it is a gift, a promotion conditional on buying a package ("within the approved partnership scope" implies conditional — inference), or a standalone promise. Scope ("premium") undefined; "previously proposed" CA$5,900 unevidenced (summary C15). Free work far exceeds the CEO's free-assessment policy (90 min, 2 workflows, 2-page report). Possible reliance/estoppel-type argument if HNH acts on it — counsel. | **CRITICAL** |
| 3 | **Website / Navigator ownership and IP** | "Ownership: agreed custom deliverables and HNH records. Third-party licenses continue." (S18); "HNH receives the agreed custom work: agreed source code, data exports and documentation. Third-party tools and retained components remain licensed." (S24); "Reuse does not remove agreed ownership of custom deliverables." (S19n) | Ownership is promised for "custom deliverables" generally, but **not stated for the website or Navigator**. The website concept is already live at nexorayyc.io/clients/hnh (noindex, S11n). Open: who owns the concept front end, design, copy, Navigator content; licence vs assignment; retained NEXORA components; moral rights. Conflicts with the open licence-vs-ownership brackets in GTM-31/33. | **HIGH** |
| 4 | **Newcomer Navigator scope** | "The initial Newcomer Navigator is included" (S33); "The free initial Newcomer Navigator MVP begins with Calgary/Alberta. Final content and functionality need a defined scope." (S33n); "Initial MVP contribution only." (S33) | Promised free with undefined scope; settlement guidance sits near advice — needs "general information, not professional advice" framing (S33n already notes this). Ownership, maintenance and liability for guidance accuracy unstated. | **HIGH** |
| 5 | **Pilot credit** | "Eligible CA$3,250 pilot fees credit overlapping package work under the final agreement." (S18); "Credit the prior pilot fee against a larger overlapping package when eligibility is agreed, so HNH never pays twice…" (S18n); "Confirm the pilot and credit terms" (S36) | "Eligible" and "overlapping" are undefined; no time limit, no conditions, no statement that credit is lost if not upgraded. "Never pays twice" reads like a promise. | **HIGH** |
| 6 | **12-month maintenance term** | "Website maintenance CA$199 … Proposed 12-month term" (S20); "the previously proposed 12-month term still subject to agreement" (S20n); "a CA$100 monthly bundle reduction or CA$1,200 across twelve paid months. This arithmetic does not create a new subscription duration." (S20n); "Define … cancellation and renewal terms before agreement." (S20n) | Term proposed but renewal, auto-renewal, early termination and fees on termination are absent. "CA$1,200 across twelve paid months" implies a 12-month bundle commitment. Default NEXORA policy is **no automatic renewal** (GTM-29 §2). | **MEDIUM** |
| 7 | **Live client data before a DPA** | "Google Cloud SQL for PostgreSQL, in Canada, under an HNH-controlled account." (S24); "Initial permitted data migration" (S27); "May I ask for your name and preferred contact details?" (S5 Noor example); "Begin with synthetic test data." (S26n); "Sensitive documents use controlled uploads, access checks and tested backups." (S9) | The proposal assumes production flows of client personal information through WhatsApp/Meta, AI vendors, Google and a CRM, plus migration. No NDA or DPA is mentioned. Conflicts with structure_recommendation.md §1 (NDA → DPA → SOW; avoid live data; DPA precondition for any access). "Canadian storage does not guarantee all processing stays in Canada" (S24) is a good qualifier but cross-border notice (PIPA s.13.1(1)–(4), s.6(2)–(3), VERIFIED text in LIAISON-06) is unaddressed. | **CRITICAL** |
| 8 | **Phase 4 agreement preparation / regulated practice** | "Secure requests and professionally approved agreements." (S17); "Documents and agreement handoffs" (S25); "AI prepares approved administrative fields after professional authorization. HNH decides legal scope, conflicts, service terms and signature approval." (S29n); "professionally authorized agreement preparation" (S18n); "Document and agreement requests" (S7) | NEXORA building tools that prepare retainer/agreement content for an immigration practice sits close to regulated immigration and legal practice. Boundary statements exist ("It does not make immigration decisions", S3; "A qualified professional determines advice and eligibility", S4) but "agreement preparation" wording risks being read as NEXORA preparing legal agreements. Unauthorized-practice risk — regulator UNKNOWN (CICC or a law society); Immigration and Refugee Protection Act — UNVERIFIED. REQUIRES_LICENSED_COUNSEL. | **HIGH** |
| 9 | **CaseEasy cutover / vendor terms** | "Supported CaseEasy handoff" (S18); "initial lead/CaseEasy handoff where supported" (S18n); "HNH approves the cutover only after staff acceptance and recovery tests." (S23); "Keep CaseEasy active until the required replacement is proven." (S23); "CaseEasy public terms describe automatic renewal and warn about data after termination." (S23n); "Full CaseEasy replacement is outside the agreed MVP scope." (S6n) | "Required replacement" and "cutover" imply a replacement path, contradicting "CaseEasy retained" (S6). "Supported CaseEasy handoff" is listed as a package feature though API access is Enterprise-only per S6n — unverified (Argon A1). CaseEasy contract, plan, export rights and renewal date UNKNOWN; risk that HNH relies on NEXORA's view of its vendor contract. Note "agreed MVP scope" (S6n) suggests agreement exists. | **HIGH** |
| 10 | **Missing terms** | "Payment terms / deposits / taxes: None stated." (summary §1); "Monthly build recovery … not payment terms" (S21n/S34n); "No invented SLA" (S35n); "Define support hours, response targets…" (S20n) | No payment schedule, deposit, GST, liability cap, warranty, SLA, NDA, DPA, acceptance mechanics, IP detail or termination anywhere. Prices are quoted without "plus GST" (accountant). Not a defect if the deck is an invitation to negotiate, but raises Issue 1 risk if treated as an offer. | **HIGH** |
| 11 | **ROI / savings / guarantee claims vs s.74.01 interim rule** | "Illustrative 12-month ROI: −59.3% / 1.7% / 62.7%" (S34); "5 additional clients / month … Covers CA$2,447/month running costs and CA$14,900 build recovery" (S21); "Example only, not a forecast." (S21); "Less routine administration", "More completed client journeys", "Better management decisions" (S21); "a CA$100 monthly saving" (S20); "PUBLISHED CUSTOM CRM BENCHMARK From CA$30,000" (S19); "12.88 s … 2.59 s" (S11); "We build the technology to help it work better." (S36) | Interim rule (GTM-29 §9): no ROI guarantees; figures need documented basis; ranges with assumptions; "examples, not guarantees". Deck labels assumptions and disclaims guarantees (good), but: the CA$750 contribution is assumed, not HNH data; lab figures are unreproduced with hash mismatches (S12n); the CA$30,000 benchmark beside CA$14,900 implies value. S21 headlines are hypotheses stated as outcomes. s.74.01 text VERIFIED in GTM-29; application to a one-to-one deck — counsel. No explicit guarantee found. | **MEDIUM** |
| 12 | **Free work vs CEO policy** | "Initial SEO, AEO, GEO and Navigator MVP included" (S15) | Exceeds free-assessment policy; needs CEO decision whether this is a documented partnership exception. | **MEDIUM** |
| 13 | **Unverified capability statements** | "Official WhatsApp connection" (S26); "Proposed 24/7 routine reception, subject to platform availability." (S5); "45-day aim" (S17) | Qualified, but Argon has not verified (A1–A9). Under the HNH structure, no capability statement without Argon verification. | **MEDIUM** |
| 14 | **AI imagery / persona** | "Images of people are AI-generated illustrative concepts" (every slide); "It must never impersonate Zain or a human employee." (S5n) | Disclosed; acceptable. Noor consent/privacy notice still HNH's responsibility. | **LOW** |

## 2. Was an offer made?
**Possibly — counsel must decide.** For: specific prices and package contents (S18, S20, S25), a closing request to start (S36n), "Thank you for choosing NEXORA" (S36), "NEXORA has agreed to waive" (S15n). Against: "This is not a binding quote" (S18), "not a finalized binding quotation" (S18n), "Final agreement defines scope…" (every slide), "Final commercial terms will be agreed before kickoff" (S20n), phase-by-phase approval language (S17–S18). **Whether the "not a binding quote" line is enough is a REQUIRES_LICENSED_COUNSEL question**, especially for the website waiver (stated as already agreed) and the pilot credit. Recommended interim posture: treat nothing as accepted; in writing, confirm to Zain (CEO-approved text) that all items are proposals pending a signed agreement — **draft for CEO/counsel, not sent**.

## 3. Contract dependencies (in order)
1. CEO confirms what was sent (file vs PDF, version, notes visible) and whether it was approved.
2. Counsel opinion on offer/acceptance and the website waiver; CEO-approved clarifying message to Zain (if counsel advises).
3. Mutual NDA (GTM-31 + HNH changes).
4. DPA — before any personal information, CaseEasy access, migration or WhatsApp production traffic (NOT YET DRAFTED).
5. Discovery & Design SOW (or a pilot SOW if the CEO keeps WhatsApp First) — reconcile with the proposal's prices (summary C1/C3); Argon verification of A1–A9.
6. Website/Navigator contribution letter or SOW schedule: scope, conditions, ownership/licence, no maintenance, exclusions.
7. Implementation SOW/MSA per phase: price, GST, payment, acceptance, IP, cap, warranty, pilot-credit mechanics.
8. Managed services schedule: 12-month term (if any), no auto-renewal default, termination, support limits, no SLA unless verified.
9. CaseEasy vendor review by HNH (its own contract) before any cutover; NEXORA gives no view on HNH's vendor rights.

## 4. Next-meeting language to AVOID
| Avoid | Safer alternative |
|---|---|
| "We'll build your website for free." / "The website is free." | "NEXORA has proposed waiving its website development fee within a scope we'd define together in writing. Nothing is final until we both sign." |
| "Thank you for choosing NEXORA." / "Let's get started." | "Thank you for considering NEXORA. If you'd like to go ahead, we'll put the scope and terms in writing for you to review." |
| "Your credit is guaranteed." / "You'll never pay twice." | "We've proposed that eligible pilot fees could be credited; the final agreement will set out exactly how." |
| "Guaranteed results / ROI / more clients." | "The figures are illustrations based on assumptions; we'd measure your actual baseline first." |
| "Your data will be safe / stays in Canada / we'll migrate your client data." | "Before any client data is involved, we'd sign a confidentiality agreement and a data processing agreement, and we'd start with test data." |
| "We'll prepare your immigration agreements / retainers." | "Your professionals prepare and approve all agreements; we'd build tools that help your staff track requests and route documents." |
| "We'll replace CaseEasy." / "You can cancel CaseEasy in February." | "CaseEasy stays in place. Any change to it is your decision, after you've reviewed your own contract with them." |
| "Noor works 24/7 with CaseEasy integration." | "We'd confirm WhatsApp and CaseEasy availability technically before committing to those features." |
| "Maintenance is a 12-month contract." | "Maintenance terms, including length and cancellation, would be agreed in writing; we don't auto-renew." |
| "The price is CA$X." (as a commitment) | "The proposal showed estimates; final pricing is set in the signed agreement." |

## 5. CEO decisions
1. Confirm what was sent, in what format, and whether it was approved.
2. Whether to honour, condition or withdraw the CA$5,900 website waiver and free SEO/AEO/GEO/Navigator (partnership exception to free-work policy?).
3. Entry path: D&D first (approved journey) vs WhatsApp First pilot as proposed; how to reconcile the disclosed prices.
4. Ownership/licence model for website, Navigator and custom work.
5. Pilot-credit rules (eligibility, time limit, conditions).
6. Maintenance term, renewal and termination.
7. Whether to send a clarifying "proposal only" message to Zain (text for CEO/counsel approval).
8. Whether Phase 4 (documents/agreements) stays in scope.

## 6. REQUIRES_LICENSED_COUNSEL
1. Offer/acceptance analysis and adequacy of "not a binding quote"; effect of S36 "Thank you for choosing NEXORA" and S15n "has agreed to waive".
2. Enforceability/reliance risk of the free website and Navigator promise.
3. Unauthorized-practice risk of Phase 4 tools; HNH status and regulator (UNKNOWN).
4. PIPA vs PIPEDA, cross-border notice (PIPA s.13.1, s.6(2)–(3) VERIFIED text), DPA content.
5. Competition Act s.74.01 (text VERIFIED, GTM-29) applied to the ROI/benchmark/performance slides.
6. GST presentation of prices (accountant).
7. Whether NEXORA statements about CaseEasy's terms create reliance risk.

## 7. UNKNOWNs
Format/version sent; CEO approval of sent version; HNH legal status, regulator and location; CaseEasy plan, API, renewal date and export rights; source of "previously proposed" CA$5,900; website ownership; NEXORA internal price schedule (summary C2); insurance.

**FOR QUALIFIED COUNSEL REVIEW. STOP FOR CEO REVIEW. NOT LEGAL ADVICE.**
