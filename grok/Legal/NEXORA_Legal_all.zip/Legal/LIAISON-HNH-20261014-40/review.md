**FOR QUALIFIED COUNSEL REVIEW. NOT LEGAL ADVICE. STOP FOR CEO REVIEW.**

# HNH-40 Legal Review — Assessment Report, Closing Strategy, Sales Input (LIAISON-HNH-20261014-40)
Prepared by NEXORA Legal Counsel Desk (AI drafting assistant — **not a lawyer**). Sources read-only in `/workspace/strategy/LIAISON-HNH-20261014-40/`: `report/HNH_Assessment_DRAFT.pdf` (2 pages, via `pdftotext -layout`), `CLOSING_STRATEGY_INTERNAL.md`, `sales.md`. Context also read: `CEO_COMMERCIAL_DIRECTION.md`, `facts.md`, `priorities.md` (grep). Benchmarks: `../LIAISON-HNH-20261014-39/addendum_review.md` §4 avoid list; `NEXORA-GTM-20261014-33/free_assessment_terms_v2_draft.md`.

## Verdicts
| Document | Verdict | Issues |
|---|---|---|
| HNH_Assessment_DRAFT.pdf (prospect-facing) | **PASS WITH FIXES** | 8 (0 CRITICAL, 1 HIGH, 4 MEDIUM, 3 LOW) |
| sales.md (internal + draft email) | **PASS WITH FIXES** | 4 (2 HIGH, 1 MEDIUM, 1 LOW) |
| CLOSING_STRATEGY_INTERNAL.md (internal) | **PASS WITH FIXES** (internal use; risky if repeated) | 7 (3 HIGH, 3 MEDIUM, 1 LOW) |
| **Overall** | **PASS WITH FIXES** — no CRITICAL; nothing should go to HNH until the HIGH fixes are made and the CEO approves | **19** |

**What passes well:** the report has no prices, no ROI, no discounts, no "free website"; it's 2 pages; it tags each point VERIFIED / CUSTOMER STATEMENT / ASSUMPTION; it says "No second CRM. No integration is active today."; it requires a DPA before data; and its closing disclaimer states "not a proposal or quote, and not a contract. NEXORA makes no guarantees about any outcome." The internal strategy already bans "never pay twice", "guaranteed credit" and "free upgrade", and keeps CaseEasy as the system of record.

**Threshold note:** HNH's regulatory status (RCIC practice, law firm, both) remains UNKNOWN (`facts.md`: "No rcic.ca lookup"). Several lines assume a "licensee"/"RCIC".

---

## A. HNH_Assessment_DRAFT.pdf (prospect-facing)
| # | Location | Current text (exact) | Replacement text (exact) | Rating |
|---|---|---|---|---|
| A1 | p.2 §07 "Approvals before any work" | "A Data Processing Agreement in place before any data is handled" | "A signed confidentiality agreement and a Data Processing Agreement in place before NEXORA handles any HNH client personal information" | **HIGH** — "any data" is inaccurate (the assessment already used HNH statements) and omits the NDA; the DPA isn't drafted yet, so don't imply a ready template |
| A2 | p.2 §05 | "General FAQ within strict boundaries: no immigration advice, with escalation to the licensee." | "General FAQ within strict boundaries: no immigration or legal advice, with escalation to HNH's responsible professional." | MEDIUM — HNH's licensing status UNKNOWN |
| A3 | p.2 §07 | "Licensee approval of the FAQ and escalation rules" | "Approval of the FAQ and escalation rules by HNH's responsible professional" | MEDIUM — same reason |
| A4 | p.2 §06 | "Once the first workflow works, a broader CaseEasy-connected transformation, linking HNH's enquiry, booking, client and follow-up workflows, is the logical next stage. It would be scoped and approved separately." | "If HNH wishes, a broader CaseEasy-connected project linking enquiry, booking, client and follow-up workflows could be considered later. It would be optional, and scoped and agreed separately in writing." | MEDIUM — "once it works … is the logical next stage" implies delivery success and a pre-set path |
| A5 | p.2 §05 | "Status: conditionally feasible with bounded, approved intake and human escalation. Subject to technical review." | "Status: may be feasible with bounded, approved intake and human escalation, subject to NEXORA's technical review and WhatsApp Business eligibility." | MEDIUM — capability statement before Argon gates (WhatsApp eligibility, Calendly handoff) are cleared |
| A6 | p.1 §02 | "CaseEasy, HNH's case-management system (per CEO, about CA$2,500/yr)." | "CaseEasy, HNH's case-management system (cost about CA$2,500/yr, as stated by HNH)." | LOW — "per CEO" is an internal attribution; confirm with CEO that Zain is the source |
| A7 | p.1/p.2 header and footer | "DRAFT — CEO REVIEW REQUIRED" | On release: remove, and add to the p.2 disclaimer: "Reviewed and approved by NEXORA before release." | LOW — GTM-33 terms require that statement; CEO approval stays internal |
| A8 | p.2 disclaimer | "It contains preliminary observations and options only." | "It contains preliminary observations and options only, and should not be relied on for decisions without independent advice." | LOW — aligns with GTM-33 §3 no-reliance wording |

**Policy note (no text fix; CEO decision):** GTM-33 free terms name the next step as "optional paid Discovery & Design, followed by a scoped proposal", but the report (§05) and CEO direction lead with the Noor pilot. Either update the free terms (GTM-33 §8) or add D&D to the report. Also confirm Zain accepted the free-assessment terms (acceptance mechanism still a CEO/counsel bracket).

## B. sales.md
| # | Location | Current text (exact) | Replacement text (exact) | Rating |
|---|---|---|---|---|
| B1 | (a) Ask | "Shall we prepare a written Phase 1 scope and agreement, as described in the proposal you received, for your review?" | "Shall we prepare a written Phase 1 scope for your review? Scope, price and terms would be set out only in that written agreement." | **HIGH** — "as described in the proposal you received" ratifies the 36-slide deck (website waiver, credit, prices) and deepens the offer/acceptance risk in addendum_review Issue 1 |
| B2 | (a) Who | "Noor if Noor owns the handoff (H)" | "the HNH staff member who handles WhatsApp handoffs, if any (H)" | **HIGH** — Noor is NEXORA's proposed AI assistant, not a person; treating it as a participant conflicts with AI-identity rules |
| B3 | (a) Agenda | "website item as in the proposal, conditions in writing" | "website: a proposal only; do not reconfirm. Terms, if any, only in a signed agreement (CEO decision D-W and counsel view pending)" | MEDIUM — reconfirming "as in the proposal" repeats the "has agreed to waive" commitment |
| B4 | (b) checklist | "Before sending: CASL consent basis recorded (R&C); 'no cost' wording matches signed free policy; CEO approves text and recipient." | "Before sending: CASL consent basis recorded (R&C); HNH's acceptance of the free-assessment terms recorded; 'no cost' wording matches the CEO-approved free terms (still DRAFT); CEO approves text and recipient." | LOW — the free terms are not "signed"; acceptance not yet evidenced |

Draft email body: no issues found. It makes no offer, no price, and no promise.

## C. CLOSING_STRATEGY_INTERNAL.md (internal; flagged lines risky if repeated to HNH)
| # | Location | Current text (exact) | Replacement text (exact) | Rating |
|---|---|---|---|---|
| C1 | §5 M2 Ask | "Are you comfortable signing Phase 1 now, and should we draft the roadmap agreement so later phases can be approved one at a time?" | "Once you've reviewed the written Phase 1 scope, would you like us to prepare the agreement documents for your review? Later phases would each be optional and agreed separately." | **HIGH** — pushes signature before the NDA, DPA and SOW exist and before counsel review; a "roadmap agreement" may read as a commitment to later phases |
| C2 | §1 Value ladder | "Proof: Zain stops being the receptionist." / "Proof: nothing falls through." / "Proof: one connected operation." | "Objective: fewer enquiries Zain handles personally, measured against an agreed baseline." / "Objective: follow-ups are tracked and visible." / "Objective: connected enquiry-to-follow-up records, where verified integrations allow." | **HIGH** if repeated — outcome promises under the s.74.01 interim rule (GTM-29 §9) and addendum avoid list ("Guaranteed results") |
| C3 | §6 Objections | "AI advice (no; FAQ + escalation; RCIC responsible); data (DPA first, minimum data, CICC s.28)" | "AI advice (no; FAQ + escalation; HNH's licensed professional remains responsible; HNH's regulatory status to be confirmed); data (DPA first, minimum data; CICC rule reference UNVERIFIED, counsel to confirm)" | **HIGH** — "CICC s.28" is not verified in any NEXORA file and must not be cited to HNH; RCIC status UNKNOWN |
| C4 | §4 Pilot credit | "fees paid for the Phase 1 pilot may be credited toward overlapping work in that package, as set out in the final agreement." | "fees paid for the Phase 1 pilot may be credited, once, toward overlapping work in that package, within the period and on the conditions set out in the final agreement." | MEDIUM — otherwise acceptable as draft; it needs to carry the internal limits (once, window D-C). Counsel to confirm. |
| C5 | §6 and §7 website | "website (as written, conditions in SOW)"; "website only after Ph1 acceptance with ownership/hosting stated" | "website: proposal only, pending CEO decision D-W and counsel's view on the waiver; do not reconfirm or schedule" | MEDIUM — treats the waiver as committed |
| C6 | §5 M3 | "M3 agreement: NDA, MSA + SOW 1 + DPA; later phases as SOW addenda." | "Sign the NDA before M2 if HNH will share confidential details; DPA before any personal information; then SOW 1. MSA not yet drafted (counsel). Later phases as separate SOWs." | MEDIUM — sequencing conflicts with structure_recommendation.md §1 (NDA → DPA → SOW) |
| C7 | §1 Line | "'Start with the problem you feel daily; each next phase reuses what Phase 1 built.'" | "'Start with the problem you feel daily; later phases, if you choose them, are designed to build on Phase 1 where that fits.'" | LOW — implied promise of reuse and progression |

Internal-only lines that are fine but must never reach HNH: "Goal: Complete Ecosystem CA$14,900"; "Pivot: Complete -> Connected Growth -> Phase 1. Never a lower price, only less scope."; §7 margin and hour estimates.

## D. Consistency checks
- **Addendum avoid list:** no "free website", "guaranteed", "never pay twice", "replace CaseEasy" or "we'll prepare your agreements" in any of the three. Residual risk is in B1, B3 and C5 (reconfirming the proposal or website), and C1 ("signing now").
- **GTM-33 free terms:** 2-page cap met; no ROI met; no prices met; "reviewed and approved by NEXORA before release" missing (A7); no-reliance wording partial (A8); next-step framing differs (policy note).
- **s.74.01** (text VERIFIED in GTM-29 §9; application to one-to-one communications still a counsel question): the report labels objectives "not guarantees". Exposure is the internal "Proof:" lines (C2) if spoken.

## E. CEO decisions
1. D-W (website waiver) before any mention at M1.
2. Next-step framing: D&D (GTM-33) or Noor pilot (CEO direction). Align the free terms or the report.
3. Pilot-credit window D-C and the "once" limit.
4. Confirm the CaseEasy cost source for A6.
5. Approve the final report text and its release.

## F. REQUIRES_LICENSED_COUNSEL
1. Whether references back to "the proposal you received" affect the offer/acceptance analysis.
2. Pilot-credit wording (C4).
3. HNH regulatory status, and any CICC or law-society rules (all UNVERIFIED).
4. Adequacy of the report's closing disclaimer.

**FOR QUALIFIED COUNSEL REVIEW. NOT LEGAL ADVICE. STOP FOR CEO REVIEW.**
