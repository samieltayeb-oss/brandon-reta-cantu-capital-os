**DRAFT — NOT LEGALLY APPROVED / FOR QUALIFIED COUNSEL REVIEW. NOT LEGAL ADVICE.**

# Final Legal Re-check — NEX2026-0001 PDF and Delivery Email (LIAISON-HNH-20261014-40-FINAL)
Prepared by NEXORA Legal Counsel Desk (AI drafting assistant — not a lawyer). Read-only check of `report/HNH_Assessment_NEX2026-0001_FINAL_CANDIDATE.pdf` (pdfinfo: **2 pages**; Title metadata "HNH Business Growth & Technology Assessment — NEX2026-0001"), `report/HNH_Assessment_DRAFT.html`, `DELIVERY_EMAIL_DRAFT.md`, `CASL_BASIS.md`, `POLICY_ADMIN_CORRECTION.md` and `GO_HOLD_FINAL.md`. Policy files and the GTM-36 signed record were also checked. CEO decisions are treated as CEO_APPROVED_COMMERCIAL_POSITION and are not re-litigated.

## Overall: **HOLD**
The content is legally acceptable once the fixes below are made. Release is held by:
- the email's unsupported opening line;
- DRAFT banners still on the PDF;
- an ambiguous signature status on the policy;
- the CASL evidence gap;
- the pending CEO confirmations already listed in GO_HOLD_FINAL.md.

| # | Item | Verdict | Note / exact fix |
|---|---|---|---|
| 1 | Elena removed | **GO** | No "Elena" or "Chen" in the PDF text, the PDF metadata, the HTML or the email. |
| 2 | Preparer | **GO** | "PREPARED BY: NEXORA TECHNOLOGIES CORP." |
| 3 | Accountable contact and sender | **GO** | PDF header and §08: "Sami Suliman, Founder & CEO · sam@nexorayyc.io". Email From and signature match. |
| 4 | Disclaimer | **GO** | Policy text present. No-reliance: "Do not rely on it for decisions without independent professional advice." Immigration: "NEXORA does not provide immigration or legal advice and makes no decisions about any client file." No "approved by NEXORA" claim. *Residual:* the added "It is a free review … does not promise growth" sentence sits inside the policy's verbatim text; acceptable, low. |
| 5 | Health and client-records exclusion | **GO** | §07: "Please don't send NEXORA any client personal, health, financial or immigration records. If any are sent, we won't open or use them, and will delete them and let you know." |
| 6 | §06 Google Cloud wording | **GO** (residual low) | "could be designed around an HNH-controlled Google Cloud environment… separately verified…"; "Any future replacement… separate, optional projects"; "This assessment is not an implementation proposal." Conditional enough. Optional tightening: "If HNH chooses to pursue it, a future HNH-owned system could be designed…" |
| 7 | §05 five-language history | **GO** (residual low) | "the earlier commercial presentation proposed English, Arabic, French, Urdu and Hindi. The initial rollout languages are subject to HNH's agreement and testing…" Historical and conditional. Residual: it references the 36-slide deck (offer-risk link, addendum Issue 1). |
| 8 | Terms acceptance not a gate | **GO** (CEO decision) | Residual: without accepted terms, the no-reliance, liability and confidentiality protections rest only on the report disclaimer. GTM-33 v2 terms remain DRAFT and unreviewed, so do **not** reference them in the report or email until they're approved. If the CEO wants a reference later: "This assessment is provided under NEXORA's free assessment terms: [link/attachment]." |
| 9 | Policy v1.1 | **HOLD** | Diff check: the only changes are the line-2 header and the appended correction log. **No change of substance.** Hashes match the stated values (v1 7af65777…, v1.1 238db540…). **But signature status is ambiguous.** The "SIGNED" record (`NEXORA-GTM-20261014-36/CEO_APPROVAL_RECORD_A6_20261014-1828_SIGNED.md`) has line 2: "STATUS: SIGNED — CEO APPROVED (not signed; do not mark signed until the CEO actually signs)". That record also says it "does not authorize customer contact". Fix: the CEO confirms the actual signature in writing and corrects line 2 of the record, then acknowledges v1.1 (hash 238db540…). Sending the email still needs separate CEO send approval (GO_HOLD #12). |
| 10 | §08 "separate written agreement" | **GO** | "an optional paid Discovery & Design engagement, scoped and agreed separately in writing." |
| 11 | Claims rule | **GO** | No prices, ROI, savings figures or guarantees; "Objectives (not guarantees)". The email has none either. |
| 12 | Client personal information | **GO** | Only Zain's business name and email and HNH's business address. No HNH client data. |
| 13 | DRAFT banners | **HOLD** | The PDF still shows "DRAFT — CEO REVIEW REQUIRED" on both pages, in the header and footer, plus a watermark. The HTML also has them (lines 36, 38, 59, 61, 62, 85). Fix: render a clean PDF after CEO approval, confirm 2 pages and record its SHA-256. |
| 14 | Email: sender identification | **HOLD** (pending CEO) | The signature has name, business, email, website and mailing address ("95 Corner Glen Manor NE, Calgary, AB T3N 2S7"). The address is pending CEO publication approval. If it isn't approved, use another approved mailing address; the CASL identification requirement (policy §6; sections UNVERIFIED by Legal) needs a mailing address. |
| 15 | Email: unsubscribe | **GO** (pending CEO) | "reply "unsubscribe" and we will stop within 10 business days." The CEO must confirm a named owner monitors it and that it stays valid for 60 days, with a suppression list (GO_HOLD #7). |
| 16 | Email: CASL basis | **HOLD** | CASL_BASIS.md supports a **candidate** implied-consent (inquiry) basis only. The Oct 11 submission rests on a CEO statement, with no primary record; a questionnaire answering NEXORA's own invitation may not be an "inquiry" (counsel); the transactional exemption isn't relied on. Fix: file dated evidence of Zain's submission or a written request, or obtain Zain's express written request or consent; R&C records the basis and its expiry. |
| 17 | Email: overpromising | **GO WITH FIX** | Current: "with clear boundaries so that any immigration question always goes to your team". Replace with: "designed so that immigration questions are routed to your team". ("Always" is an absolute claim about an AI system that hasn't been built.) |
| 18 | Email opening line | **HOLD** | See below. |

## Opening line (item 18)
**Current:** "Thank you again for taking the time to walk me through how HNH Immigration works today. As promised, I've attached…"

**Evidence searched:** `/workspace/strategy` and `/workspace/legal` for walkthrough, call, meeting-notes and transcript terms.
- No meeting notes or transcript of a call or walkthrough between Sami and Zain were found.
- The evidence shows a deck and questionnaire sent by NEXORA, and HNH completing the questionnaire (`LIAISON-HNH-20261014-39/GAP_ANALYSIS.md`).
- Zain's described problems are recorded as "CEO clarification, not questionnaire evidence" (`CEO_PRIORITY_UPDATE.md`).
- A planned or held "next meeting" is described (`sales_reconciliation.md`), but no record shows Sami personally receiving a walkthrough.
- Nothing records a promise to send the assessment ("As promised").

**Verdict: HOLD** (unsupported on file; the CEO may confirm it from personal knowledge, but nothing records it).

**Replacement (exact):** "Thank you for the information HNH shared about your current processes. I've attached your NEXORA Business Growth & Technology Assessment (reference NEX2026-0001)."

**Related (report, low):** "as you described in our conversation" (§02) and "limited information from one conversation" (disclaimer). If no conversation is confirmed, use "as HNH described to us" and "limited information shared by HNH". The second change alters the policy's verbatim disclaimer, so it needs the CEO's OK.

## Exact fixes
1. Email line 1: use the replacement above, or the CEO confirms the walkthrough happened and files a dated note.
2. Email: "any immigration question always goes to your team" becomes "immigration questions are routed to your team" (keeping "designed so that").
3. Render a clean PDF with no DRAFT banners or watermark, 2 pages, SHA-256 recorded; attach only that file.
4. The CEO confirms the signature and corrects the contradictory line 2 of the signed record; acknowledges v1.1 (238db540…).
5. CASL: file primary evidence of Zain's inquiry or request, or obtain express consent; R&C records it.
6. CEO confirms: mailing address for publication, unsubscribe owner and validity, Zain's address, and send approval.
7. Optional: §06 "If HNH chooses to pursue it, …"; §02 and disclaimer "conversation" wording if unconfirmed.

## Counsel items
- Whether the questionnaire submission is an "inquiry" for implied consent.
- Reliance and liability exposure without accepted terms.
- Acceptability of the modified verbatim disclaimer.

**DRAFT — NOT LEGALLY APPROVED / FOR QUALIFIED COUNSEL REVIEW. NOT LEGAL ADVICE.**

---

## Addendum — 2026-10-14 ~22:00 MT: final recommendation on the documented delivery basis
**DRAFT — NOT LEGALLY APPROVED / FOR QUALIFIED COUNSEL REVIEW. NOT LEGAL ADVICE.** The CEO direction of 21:55 MT is treated as CEO_APPROVED_COMMERCIAL_POSITION. Sources re-read: `CASL_BASIS.md` (including its "CEO direction 21:55 MT" section), register entries E-24 to E-29, `DELIVERY_EMAIL_DRAFT.md`, both report PDFs, the HTML, and the GTM-36 approval files.

### Findings
| Check | Result |
|---|---|
| Email opening line | **Fixed.** Now reads "Thank you for the information HNH shared about your current processes." This is supported by E-24 (the questionnaire). |
| Report "as you described" | Supportable: HNH's statements, via the questionnaire and the CEO's clarifications. |
| Report "in our conversation" (§02) and "one conversation" (disclaimer) | **Not supported** by the Oct 11 evidence. E-24 is a *questionnaire*, not a conversation or walkthrough, and doesn't show Sami personally. CEO_PRIORITY_UPDATE records "CEO clarification, not questionnaire evidence", which may reflect a CEO conversation, but no dated note exists. |
| Overpromise | **Fixed.** "designed so that immigration questions are routed to your team". |
| CA$14,900 / prices | **Absent** from the FINAL_CANDIDATE PDF (no "CA$") and the email. GO. |
| DRAFT banners | **Not removed.** FINAL_CANDIDATE still has "DRAFT — CEO REVIEW REQUIRED" (2 text hits plus watermark). Its SHA-256 is unchanged at 97bace2f…, so no clean render exists. HTML: 6 DRAFT markers. |
| Clean SHA-256 | **Not recorded.** |
| Wrong-file risk | `HNH_Assessment_NEX2026-0001_RELEASE_CANDIDATE.pdf` (21:24, SHA-256 d5241bed…) is an **older** render. It still has "Elena Chen, AI-assisted Account Coordinator", "available under the assessment terms", and a PDF Title beginning "DRAFT — CEO REVIEW REQUIRED". It must **not** be attached. |
| Signature-record contradiction | **Not reconciled.** `CEO_APPROVAL_RECORD_A6_20261014-1828_SIGNED.md` line 2 still reads "(not signed; do not mark signed until the CEO actually signs)". APPROVAL_REGISTER AR-001 records "VERIFIED — SIGNED (typed signature, CEO-confirmed in chat t154u)". Per the CEO direction (E-26) this is an audit item, **not a delivery blocker**. |
| Sender identification | Name, business, email, website and mailing address are present in the email. The mailing address is still marked "pending CEO confirmation that it is approved for external publication" (21:55 direction is silent on it). |
| Unsubscribe | Present ("reply "unsubscribe"… within 10 business days"), sent to sam@. Monitored by the CEO (E-27); no backup is named, which is a low residual risk. |

### CASL basis — REASONED_LEGAL_INTERPRETATION
Provisions verified on Justice Laws, S.C. 2010, c. 23, current to 2026-09-21:
- **s.10(9)(a):** consent is implied where there is an existing business relationship.
- **s.10(10)(e):** that relationship can arise from "an inquiry or application, within the six-month period immediately before the day on which the message was sent", made by the recipient "in respect of anything mentioned in any of paragraphs (a) to (c)" (purchase of a service, etc.).
- **s.10(9)(c):** a second possible basis. The recipient disclosed his electronic address to the sender without indicating a wish not to receive messages, and the message is relevant to his business.
- **s.11(1)–(3):** unsubscribe through the same electronic means, valid for at least 60 days, actioned within 10 business days.
- **s.13:** the person alleging consent has the onus of proving it.

**Assessment:**
- Implied consent under s.10(9)(a)/(10)(e) is a **reasonable** basis if Zain's Oct 11 questionnaire submission is an inquiry about NEXORA's services. Whether a response to NEXORA's own invitation qualifies is a counsel question.
- s.10(9)(c) is a reasonable alternative, *if* Zain gave NEXORA zain@hnhimmigration.ca himself.
- The weak point is **proof (s.13)**: the Oct 11 date rests on a CEO statement only (E-24), with no primary timestamp filed.
- The unsubscribe as drafted is consistent with s.11.
- No regulation-based exemption is relied on; none is cited.

### (1) Remaining legal blockers
1. **Clean PDF:** render from the FINAL_CANDIDATE content (not RELEASE_CANDIDATE), with no DRAFT banners or watermark and a clean PDF Title. Confirm 2 pages, record its SHA-256, and update the email's attachment line to that file.
2. **"Conversation" wording:** either the CEO confirms in a dated note that he personally spoke with Zain, or change §02 to "as HNH described to us" and the disclaimer's "from one conversation" to "shared by HNH". The second change alters the policy's verbatim disclaimer, so it needs the CEO's OK.
3. **CASL proof:** file a primary record of Zain's Oct 11 submission (a form timestamp or export metadata, without opening the content), and record how zain@ was obtained. Alternatively, the CEO accepts the residual s.13 proof risk in writing.
4. **Mailing address:** the CEO confirms the address is approved for publication, or substitutes another valid mailing address.
5. **Send approval:** the CEO's final send approval (text, recipient and attachment hash), with the sent copy filed.

Non-blocking items: the signature-record line-2 reconciliation (audit), a backup unsubscribe monitor, and counsel's view on whether the questionnaire counts as an "inquiry".

### (2) Final recommendation
**GO after** items 1 to 5 above are completed. On the current files the status is **HOLD**: the only PDF approved in content still carries DRAFT banners, and the other release-candidate file is outdated.

**DRAFT — NOT LEGALLY APPROVED / FOR QUALIFIED COUNSEL REVIEW. NOT LEGAL ADVICE.**

---

## Addendum 2 — 2026-10-14 ~22:10 MT: delivery conditions check
**DRAFT — NOT LEGALLY APPROVED / FOR QUALIFIED COUNSEL REVIEW. NOT LEGAL ADVICE.** Read-only. `clean_render.py` was **not** run.

| Check | Result |
|---|---|
| FINAL_CANDIDATE hash | `9ceebf99a6f6ef8a37f72bf30eb7b78cfd79d4da082c464abc55b07923c46f11`, matching 9ceebf99…. 2 pages; PDF Title is clean. **GO** |
| Wording | "as HNH described to us" (§02) and "limited information shared by HNH" (disclaimer) are present. No "our conversation" or "one conversation" claims remain. "As you described" (§03, §06) is supported by HNH's statements; "conversation logs" is not a claim. No Elena, no prices. **GO** |
| `clean_render.py` | Its source is `HNH_Assessment_DRAFT.html`, which has the same wording fixes (verified). It removes only the 2 `.wmk` watermarks, the `.draft` and `.draft2` banners, the footer prefix "DRAFT — CEO REVIEW REQUIRED · " (×2), and sets the `<title>`. It asserts exact counts (2,1,1,2), no remaining "DRAFT", 2 pages and no "DRAFT"/"REVIEW REQUIRED" text; it prints the SHA-256. It refuses to render without `--ceo-approved`. Nothing else changes. **GO.** Note: it renders from the HTML, not the FINAL_CANDIDATE PDF, so the CEO should compare the clean PDF's text against FINAL_CANDIDATE, e.g. with `--dry-run` diff and the PNG check it prints. |
| Email (`EMAIL_CUSTOMER_TEXT.txt`) | Opening line is neutral and supported. Sender ID: name, business, email, website and mailing address (CEO-verified against the Articles). Unsubscribe by reply, within 10 business days. The overpromise is fixed. No prices. Attachment is referenced only as "I've attached…". **GO.** Condition: the attached file must be the clean-render output `HNH_Assessment_NEX2026-0001.pdf` with its recorded hash, not the RELEASE_CANDIDATE PDF. |

### CASL basis — REASONED_LEGAL_INTERPRETATION
s.10(9)(a), (9)(c), (10)(e) and s.13 were verified earlier on Justice Laws (S.C. 2010, c. 23, current to 2026-09-21).
- **s.10(9)(a) + (10)(e) (inquiry within 6 months): the applicable basis, conditionally.** Evidence: HNH completed and submitted NEXORA's discovery questionnaire (record #2), dated Oct 11 by CEO statement (#3), with Zain stating goals to NEXORA (#5). That can reasonably be treated as an inquiry about NEXORA's services, though it was made at NEXORA's invitation (counsel question). The date and channel rest only on the CEO's statement, so given the s.13 onus **the attestation must be signed before sending**, ideally with the primary timestamp's metadata filed.
- **s.10(9)(c) (address disclosed to sender): not supported.** zain@ was CEO-supplied, and how it was obtained isn't recorded (record #8). Conspicuous publication under s.10(9)(b) isn't evidenced either; facts.md has no such address. It becomes a secondary basis only if attestation item 2 is completed truthfully.
- **No express consent** is claimed or available.

### Answers
1. **Clean render: conditions satisfied.** The wording is approved and applied, the hash matches, and the script is limited to DRAFT elements. Run it only with the CEO's written approval reference, then verify 2 pages, the PNGs and the text diff against FINAL_CANDIDATE.
2. **CASL basis:** implied consent under s.10(9)(a)/(10)(e) (inquiry), valid to about 2027-04-11, subject to the signed attestation. s.10(9)(c) is not established.
3. **Still blocking CEO send approval:**
   - (a) the CEO signs the attestation (items 1–3, with date, channel and how zain@ was obtained);
   - (b) clean render plus SHA-256 recorded;
   - (c) 2-page and visual check, and the clean file attached (not RELEASE_CANDIDATE);
   - (d) final CEO send approval (text, recipient, attachment hash), with the sent copy filed.
   No other legal blockers. Non-blocking: the signature-record line-2 audit, a backup unsubscribe monitor, counsel's view on "inquiry".

**Recommendation: GO after (a)–(d).**

**DRAFT — NOT LEGALLY APPROVED / FOR QUALIFIED COUNSEL REVIEW. NOT LEGAL ADVICE.**

---

## Addendum 3 — 2026-10-14 ~22:15 MT: reassessment on CEO firsthand evidence (AMCOB)
**DRAFT — NOT LEGALLY APPROVED / FOR QUALIFIED COUNSEL REVIEW. NOT LEGAL ADVICE. REASONED_LEGAL_INTERPRETATION.** Based on the full CASL_EVIDENCE_RECORD.md, including the 22:09 note, the formal 22:10 addendum and the "Additional CEO confirmation (22:10 MT)".

### Statute lettering — re-verified on Justice Laws (E-1.6, page 2, current to 2026-09-21; fetched 22:14 MT)
- **s.10(9)(a):** existing business or non-business relationship.
- **s.10(9)(b):** **conspicuous publication** of the address, with no no-CEM statement, and the message is relevant to the person's business role.
- **s.10(9)(c):** **disclosure to the sender** of the address "without indicating a wish not to receive unsolicited commercial electronic messages", and the message is relevant to the person's "business, role, functions or duties".
- **s.10(9)(d):** circumstances set out in the regulations.
- **s.10(10)(a):** purchase or lease within the **2-year** window; **(b)** acceptance of a business opportunity within that period; **(c)** bartering within that period; **(d)** a written contract, current or expired within that period; **(e)** an inquiry or application within the **6-month** window "in respect of anything mentioned in any of paragraphs (a) to (c)".
- **Correction: CASL_EVIDENCE_RECORD.md is wrong.** It labels disclosure "s.10(9)(b)" and publication "s.10(9)(c)". The correct letters are **disclosure = (9)(c)** and **publication = (9)(b)**. Legal's earlier notes were correct. The record should be corrected by its owner (not edited here).

### Bases
- **s.10(9)(c), disclosure: now the primary basis**, if the attestation confirms that the address Zain personally shared at AMCOB **is zain@hnhimmigration.ca**, with no no-CEM statement. The assessment email is relevant to his business role (HNH operations). The exact address is still UNVERIFIED, and without it this basis fails. This basis has no fixed time window, but it ends if he unsubscribes.
- **s.10(9)(a) + (10)(e), inquiry: secondary, supporting.**
  - The **Oct 11 discovery** runs to about **2027-04-11**. It was completed at NEXORA's invitation, so counsel should confirm it counts as an "inquiry".
  - The **AMCOB meeting request** is an inquiry about NEXORA's services, but its date is UNKNOWN. If it was more than 6 months before sending, it has lapsed on its own; the Oct 11 discovery would then carry this basis.
- **s.10(10)(a)–(d), 2-year relationship: not supported.** Exchanging proposals is not a purchase, the acceptance of an opportunity, bartering, or a written contract. No signed contract is on file.
- **Express consent:** none claimed.

### Exact attestation wording required (replaces the unsigned block; CEO to complete and sign)
> I, Sami Suliman, Founder & CEO of NEXORA Technologies Corp., attest from personal knowledge that:
> 1. I met Zain Ghadai of HNH Immigration at the Allied Muslim Chamber of Business (AMCOB) networking event held on or about ____________ (date), at ____________ (location).
> 2. At that event Zain personally provided his business contact information to me by ____________ (business card / verbally / digitally), including the email address ____________. The address zain@hnhimmigration.ca to which NEX2026-0001 will be sent **is that same address**.
> 3. When providing it, Zain did not indicate that he did not wish to receive commercial electronic messages from me or NEXORA.
> 4. Zain asked me to arrange a business meeting on or about ____________ (date), by ____________ (channel).
> 5. Subsequent communications: NEXORA's discovery briefing deck on 9 October 2026; the 36-slide proposal on or about ____________; HNH's Executive Business Discovery submission on 11 October 2026; other: ____________.
> 6. To my knowledge Zain has not asked NEXORA to stop contacting him.
> 7. I will retain [the business card / the earliest email or message thread] at ____________, or: no such record exists.
>
> Signature: ____________ Date and time (MT): ____________

**Retain:** the business card, or the earliest email or message thread with Zain, plus metadata of the Oct 11 submission (timestamp only).

### Clean PDF
`report/HNH_Assessment_NEX2026-0001.pdf`: SHA-256 **a6a0c15bda51a0c7fb57eafe160a724eae4f6c8c085975f851d36f4c95797163**, matching a6a0c15b. 2 pages. No "DRAFT", "REVIEW REQUIRED", "Elena" or "CA$" text found.

### Final: **GO for CEO authorization after**
1. The CEO signs the attestation above, with every blank filled. Item 2 must confirm zain@hnhimmigration.ca is the address Zain provided; if it can't be confirmed, rely on (10)(e) via the Oct 11 discovery only, and counsel should confirm.
2. Final CEO send approval naming the text (EMAIL_CUSTOMER_TEXT.txt), the recipient (zain@hnhimmigration.ca) and the attachment hash a6a0c15b….
3. The sent copy is filed, and the consent record is completed: basis (9)(c), with (9)(a)/(10)(e) supporting; dates; and expiry of the inquiry basis at about 2027-04-11.

Non-blocking: correct the (9)(b)/(9)(c) labels in CASL_EVIDENCE_RECORD.md; the line-2 signature-record audit; a backup unsubscribe monitor.

**DRAFT — NOT LEGALLY APPROVED / FOR QUALIFIED COUNSEL REVIEW. NOT LEGAL ADVICE.**
