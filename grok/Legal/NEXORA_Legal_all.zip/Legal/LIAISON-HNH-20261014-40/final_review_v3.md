**DRAFT — NOT LEGALLY APPROVED / FOR QUALIFIED COUNSEL REVIEW. NOT LEGAL ADVICE. REASONED_LEGAL_INTERPRETATION.**

# NEX2026-0001 — Final CASL Assessment v3 (2026-10-14 ~22:40 MT)
Advisory only; no one contacted. Sources: `CEO_CASL_ATTESTATION_NEX2026-0001_v3_UNSIGNED.md` and `CASL_EVIDENCE_RECORD.md` F1–F13 (read-only). Prior legal notes: `final_review.md` Addenda 1–3.

## 1. Provisions verified on Justice Laws (fetched 2026-10-14 ~22:35 MT)
- **CASL (S.C. 2010, c. 23), current to 2026-09-21.**
  - **s.10(1):** a person seeking express consent must, *when requesting consent*, set out clearly and simply (a) the purpose, (b) prescribed identifying information, and (c) other prescribed information.
  - **s.10(2):** an exception for seeking consent on behalf of a person whose identity is not known. **Not relevant here, and not an onus provision.**
  - **The onus is s.13:** "A person who alleges that they have consent … has the onus of proving it."
  - **s.10(9)(c):** implied consent where the recipient "has disclosed, to the person who sends the message … the electronic address to which the message is sent without indicating a wish not to receive unsolicited commercial electronic messages", and the message is relevant to the recipient's "business, role, functions or duties in a business or official capacity".
  - **s.10(9)(b):** conspicuous publication.
  - **s.10(10)(e):** an existing business relationship arising from "an inquiry or application, within the six-month period immediately before the day on which the message was sent, … in respect of anything mentioned in any of paragraphs (a) to (c)", i.e. purchase or lease of a product or service, a business opportunity, or bartering.
- **SOR/2012-36 = *Electronic Commerce Protection Regulations (CRTC)*** (confirmed). **s.4** ("Information to Be Included in a Request for Consent") is the correct provision. For s.10(1) and (3) of the Act, a request for consent "may be obtained orally or in writing", must be sought separately for each act, and must include:
  - (a) the requester's name or business name;
  - (b) and (c) on-behalf-of details, if any;
  - (d) a mailing address plus a telephone, email or web contact;
  - (e) "a statement indicating that the person whose consent is sought can withdraw their consent".
  - *Note:* s.4 permits oral requests. The "oral consent must be verifiable" point is **not in s.4**; it comes from CRTC guidance, which was not verified here and isn't cited.
  - SOR/2012-36 s.2 (information in a commercial electronic message) is also relevant to the email footer.

## 2. Assessment
**(a) "Email me" vs express consent.**
- Zain's oral invitation (F9) is very likely **not express CASL consent**. Express consent needs a *request by NEXORA* that met s.10(1) and SOR/2012-36 s.4: purpose, identity, mailing address and contact details, and the withdrawal statement. That request then has to be provable (s.13). No evidence shows NEXORA made such a request.
- The invitation does **strongly support the implied bases**: it is consistent with disclosure without objection under (9)(c), and with an inquiry under (10)(e). It also supports the relevance of the message to his business.
- **Keep "express consent: NOT claimed".**

**(b) s.10(9)(c) — depends on item 4.**
- **YES** (Zain's own WhatsApp contained zain@hnhimmigration.ca): **strong.** Zain himself disclosed the exact address to the sender, with no objection, and invited email (F9). The message is relevant to his business. Retain the WhatsApp message.
- **NO / UNSURE:** **weak or unavailable.** On the record, Zain gave his phone number in person (item 2) and "business contact information" by WhatsApp (item 3). If the email address came from another source (e.g. the CEO's own knowledge or a third party), (9)(c) is not met. A separate verbal or card disclosure of *the same address* would satisfy (9)(c), but only if the CEO attests to it specifically. (9)(b) would need evidence that HNH conspicuously published that address with no no-CEM statement. facts.md records no published email address, so it is not established. **Fall back to (10)(e).**

**(c) s.10(10)(e) — phone call and discovery.**
- Zain phoning to arrange a business meeting about NEXORA's services (F10) is reasonably **an inquiry about services** (anything in (10)(a), i.e. purchasing a service).
- Because the first meeting was **Oct 7, 2026** (F1), the call necessarily came on or after Oct 7. The 6-month window therefore runs to **at least about Apr 7, 2027**, and **is open now**.
- The Oct 11 discovery submission (F13; 06:59:30 UTC = Oct 11, 00:59:30 MDT) is a second, later inquiry, running to about Apr 11, 2027. It was made at NEXORA's invitation; counsel should confirm it counts.
- The exact call and meeting dates are still needed for the record.
- **This basis holds whatever the answer to item 4**, subject to counsel.

**Conclusion:** implied consent under **s.10(9)(a) + (10)(e)** is the primary, reasonably supported basis. **s.10(9)(c)** is a strong additional basis if item 4 = YES. No express consent.

## 3. Attestation v3 — accuracy fixes (exact)
| Location | Current | Replace with |
|---|---|---|
| Opening | "based on my firsthand knowledge and company records" | "based on my firsthand knowledge (items 1–6 and 9) and on NEXORA Command Center records as extracted by Argon (items 7–8)" |
| Item 4 | "[CEO MUST SELECT: YES / NO / UNSURE]" | Keep, and add: "If NO or UNSURE: I obtained zain@hnhimmigration.ca from ____________ on ____________, and Zain [did / did not] separately confirm it to me verbally or in writing on ____________." |
| Item 5 | "On the contrary, **he asked me to email him**." | "He asked me to email him. I do not treat this as express consent under CASL; NEXORA did not make a formal request for consent." |
| Item 6 | "[CEO TO VERIFY]" (date and time) | "on or about ____________ (date; on or after October 7, 2026), by telephone; meeting held on ____________ at ____________ (name and address)" |
| Item 9 | "I believe he wishes to explore working with NEXORA." | "He expressed interest in NEXORA's services. This is not an engagement." |
| CASL assessment | "A possible basis … is direct disclosure of an electronic address" / "A separate potential basis arises from Zain's business meeting request…" | "Candidate implied-consent bases (counsel to confirm): (i) CASL s.10(9)(a) with s.10(10)(e), an inquiry within six months: Zain's telephone meeting request (on or after Oct 7, 2026) and the Oct 11, 2026 discovery submission; (ii) CASL s.10(9)(c), disclosure to the sender, only if item 4 = YES." |
| Add item 10 | — | "Before sending, the suppression register was checked on ____________ and contains no entry for Zain or HNH." |

Paragraph letters: the v3 attestation cites none, so there is no mislabelling in it. Use the letters above. Note that CASL_EVIDENCE_RECORD.md's earlier "(9)(b) disclosure" label is still wrong (Addendum 3). Express consent is correctly not claimed.

## 4. Verdict: **GO after conditions**
1. The CEO signs attestation v3 with the fixes above. Item 4 must be answered YES, NO or UNSURE. Items 3 and 6 dates are filled in or expressly marked "unknown". Item 10 (suppression check) is completed.
2. The original WhatsApp message (and call log, if available) is retained, and its location recorded.
3. Final CEO send approval naming `EMAIL_CUSTOMER_TEXT.txt`, `zain@hnhimmigration.ca` and the attachment SHA-256 `a6a0c15bda51a0c7fb57eafe160a724eae4f6c8c085975f851d36f4c95797163`.
4. The sent copy is filed, and the consent record is updated. Basis: (10)(e), plus (9)(c) if item 4 = YES. Window anchored on the latest inquiry date. Express consent: none.

If item 4 is NO or UNSURE: still **GO** on (10)(e) alone, subject to counsel. Residual risk is higher, because the inquiry dates rest on the CEO's attestation and an Argon extraction.

**DRAFT — NOT LEGALLY APPROVED / FOR QUALIFIED COUNSEL REVIEW. NOT LEGAL ADVICE.**
