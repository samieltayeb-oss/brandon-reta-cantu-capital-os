**FOR QUALIFIED COUNSEL REVIEW. NOT LEGAL ADVICE. STOP FOR CEO REVIEW.**

# Release-Candidate Review — HNH Free Assessment NEX2026-0001 (LIAISON-HNH-20261014-40-RC)
Prepared by NEXORA Legal Counsel Desk (AI drafting assistant — **not a lawyer**). **Scope:** release of the 2-page free assessment to Zain Ghadai (HNH Immigration) only. Not the SOW, migration or pricing.

**Sources, read-only:**
- `/workspace/strategy/LIAISON-HNH-20261014-40/report/HNH_Assessment_DRAFT.html`. The release-candidate PDF `HNH_Assessment_NEX2026-0001_RELEASE_CANDIDATE.pdf` **does not exist**; the folder has DRAFT v1–v5 instead. Only the HTML was reviewed.
- `/workspace/strategy/NEXORA-GTM-20261014-33/FREE_ASSESSMENT_POLICY.md`
- GTM-33 `free_assessment_terms_v2_draft.md`, `review.md`, HNH-39 `structure_recommendation.md` and `addendum_review.md`, LIAISON-09 `advisory_notes.md`.

## Overall: **HOLD**
These blockers must clear before release:
- the policy is unsigned;
- the CEO hasn't approved the final report;
- the persona disclosure is non-compliant with policy §4;
- the free terms haven't been accepted;
- the DRAFT banners are still on the report;
- the "reviewed and approved" line is missing;
- the CASL basis isn't confirmed.

The content is otherwise close to releasable once the fixes below are made.

| Area | Verdict |
|---|---|
| (a) Disclaimer | **HOLD — fixes required** |
| (b) Elena AI disclosure | **HOLD — non-compliant with policy §4** |
| (c) Terms acceptance | **HOLD — not yet accepted; CEO risk decision** |
| (d) Other blockers | **HOLD** |

---

## (a) Disclaimer adequacy
| Check | Status in HTML | Fix |
|---|---|---|
| No immigration advice | PRESENT: "NEXORA does not provide immigration advice." | Strengthen: "NEXORA does not provide immigration or legal advice and makes no decisions about any client file." |
| No legal advice | PRESENT: "not advice (including legal, financial, tax, privacy or security advice)" | OK |
| No reliance | **MISSING** (review.md A8 not applied) | Add: "Do not rely on it for decisions without independent professional advice." |
| No ROI / guarantee | PRESENT: "NEXORA makes no guarantees or warranties about any outcome, saving or result." Objectives are labelled "(not guarantees)". | OK |
| Not offer / quote / contract | PRESENT: "not a proposal, quote or offer, and not a contract" | OK |
| "Reviewed and approved by NEXORA before release" | **MISSING.** Removing the internal approval line removed it too. The GTM-33 v2 terms (§1) require it. | Add as the last sentence of the disclaimer: "This report was reviewed and approved by NEXORA before release." |
| Health-information exclusion | **MISSING.** Policy §3 excludes patient and other sensitive records. The report only covers WhatsApp chats ("No passports, case documents or immigration history"). | Add to §07: "Please don't send NEXORA any client personal, health, financial or immigration records. If any are sent, we won't open or use them, and will delete them and let you know." |
| Verbatim standard disclaimer (policy §6) | **DEVIATES.** The HTML opens "…is a free review of how your tools and workflows fit together; it does not promise growth or any other outcome. It is provided with no obligation to buy." The policy text is "…is provided free of charge, with no obligation to buy." | Restore the policy text verbatim, then append the extra lines above. The "does not promise growth" sentence can follow, which also addresses the R&C "Growth" naming flag (policy §5). |

**Replacement disclaimer (exact):**
> "The NEXORA Business Growth & Technology Assessment is provided free of charge, with no obligation to buy. It is based on limited information from one conversation and publicly available sources at the date shown, and may be incomplete or out of date. It contains preliminary observations and options for discussion only. It is not a full audit or security review, not advice (including legal, financial, tax, privacy or security advice), not a proposal, quote or offer, and not a contract. NEXORA makes no guarantees or warranties about any outcome, saving or result. Any future work would require a separate written proposal and agreement. Third-party product names belong to their owners and do not imply any relationship. It does not promise growth or any other outcome. Do not rely on it for decisions without independent professional advice. NEXORA does not provide immigration or legal advice and makes no decisions about any client file. This report was reviewed and approved by NEXORA before release."

## (b) Elena Chen AI disclosure
**Current text, twice (header and §08):** "Elena Chen, AI-assisted Account Coordinator · e.chen@nexorayyc.io". Also: "Prepared by: NEXORA Assessment Team (AI-assisted)".

**Assessment: non-compliant.**
- Policy §4: "No bot conducts calls, sends reports or represents itself as NEXORA staff."
- A human-style name, a staff-style title and a personal-format staff address, together with "AI-assisted", read naturally as *a human assisted by AI*. That is the R1 HIGH risk in LIAISON-09 advisory_notes.md ("AI personas with human-style names/titles and commercial sender aliases could be perceived as NEXORA staff").
- Advisory clause 12 (no sender aliases for bots) also conflicts with the use of `e.chen@nexorayyc.io`.
- Misleading-representation and CASL sender-identification concerns: sections UNVERIFIED; refer to R&C and counsel.

**Exact fixes:**
- Header: replace "Elena Chen, AI-assisted Account Coordinator · e.chen@nexorayyc.io" with:
  "Elena Chen (AI assistant) — NEXORA's AI account coordinator. A NEXORA team member reviews all communications. Accountable contact: [FOUNDER/CEO FULL NAME], [TITLE], [HUMAN EMAIL]"
- §08: replace "Contact: Elena Chen, AI-assisted Account Coordinator · e.chen@nexorayyc.io · nexorayyc.io" with:
  "Contact: [FOUNDER/CEO FULL NAME], [TITLE], [HUMAN EMAIL] · nexorayyc.io. Elena Chen is NEXORA's AI assistant, not a person; a NEXORA team member reviews all its communications."
- "Prepared by": replace "NEXORA Assessment Team (AI-assisted)" with "NEXORA (drafted with AI assistance; reviewed and approved by NEXORA before release)".
- Email address: CEO decision whether an AI persona keeps `e.chen@` at all. The recommended options are a role address (e.g. an `assistant@` style address, [BRACKET — CEO]) or no AI contact address. **The report must be sent by the human CEO, not by Elena** (policy §4).

## (c) Terms Zain must accept before delivery
- **Which terms:** the GTM-33 `free_assessment_terms_v2_draft.md`, adapted to this assessment:
  - remove the internal CEO_APPROVED box;
  - capacity limit not stated (policy §4);
  - the D&D next step as optional and needing a separate agreement;
  - the health-information exclusion added to §4 of the terms.
- **Status:** **DRAFT, not reviewed by counsel.** The liability, retention, deletion timing, survival and venue brackets are unresolved. If they're sent now, the CEO must either fill the brackets or send a version with neutral wording, e.g. "NEXORA's liability is limited to the extent permitted by law". That wording is itself unreviewed. **Whether to send unreviewed terms is a CEO risk decision.**
- **Timing problem:** the assessment has already been performed. Acceptance now operates retrospectively and before delivery, which is a counsel point. Recommend: the terms are accepted before the report is delivered, and the report is not delivered without acceptance.
- **Acceptable methods** (choose one; CEO/counsel):
  1. **Email reply:** the human CEO sends the terms in the body of the email or as an attachment, and Zain replies "I accept". Keep the full email thread with headers.
  2. **Click-through:** a page showing the terms plus an unchecked "I accept" box, recording name, email, terms version, timestamp and IP.
  - Under either method, acceptance must **not** bundle marketing consent; that's a separate unchecked box (policy §2).
- **Electronic acceptance:** validity under the Alberta Electronic Transactions Act (sections UNVERIFIED) is for counsel.

## (d) Other blockers
| # | Blocker | Status | Required action |
|---|---|---|---|
| 1 | Policy signature | "SIGNATURE PENDING"; signed record being located | Locate or execute `CEO_APPROVAL_RECORD.md` before release; the "free" claim rests on it |
| 2 | CEO approval of this report | Not evidenced; every page still says "DRAFT — CEO REVIEW REQUIRED" | CEO approves the final version (record the version and hash); then remove all "DRAFT — CEO REVIEW REQUIRED" banners |
| 3 | Release-candidate file | `HNH_Assessment_NEX2026-0001_RELEASE_CANDIDATE.pdf` does not exist | Generate it from the fixed HTML and re-check that it is 2 pages |
| 4 | HNH personal information | Only Zain's name and business email, and HNH's business address (business-contact information). No HNH client data found. | OK. Confirm with the CEO that Zain's email may appear in the report. |
| 5 | review.md fixes in the HTML | Applied: A1 (NDA + DPA before client personal information), A2/A3 ("responsible professional"), A5 ("may be feasible…"), A6 (CaseEasy cost removed). **Not applied:** A7 (approval line) and A8 (no reliance); see (a). | See (a) |
| 6 | New §06 content | "HNH's long-term preference is a custom, HNH-owned CRM and immigration practice-management system… A future replacement and complete migration… A future HNH-owned system could be designed around an HNH-controlled Google Cloud environment, with Canadian-region storage" | MEDIUM. It reintroduces the replacement path (addendum Issue 9) and a data-location design in a free report, outside free scope ("detailed architecture" excluded, policy §3). Replace with: "You mentioned a long-term interest in an HNH-owned system. Any such project would be separate, optional, and would need technical feasibility checks and its own written agreement; it is not part of this recommendation." |
| 7 | §05 reference to the 36-slide deck | "the earlier commercial presentation proposed English, Arabic, French, Urdu and Hindi" | MEDIUM: ties the free report to the proposal (offer risk; review.md B1). Replace with: "Initial languages would be agreed and tested, with approval by HNH's responsible professional." |
| 8 | D&D framing | "an optional paid Discovery & Design step is available under the assessment terms" | HIGH: D&D is *not* under the assessment terms. Replace with: "an optional paid Discovery & Design step is available under a separate written agreement." |
| 9 | Claims rule (s.74.01 interim, GTM-29 §9) | No prices, ROI, savings or performance figures. Objectives are labelled "not guarantees". Customer statements are labelled. | PASS |
| 10 | CASL | The delivery email to Zain is a commercial electronic message unless an exemption applies (e.g. a response to his request or inquiry). The consent or exemption basis isn't recorded. Policy §6 requires identification, contact details and a working unsubscribe. CASL sections cited in policy §6 are UNVERIFIED by Legal. | **Refer to Risk & Compliance** to record the basis before sending. The human CEO sends; the identification block names the CEO; include an unsubscribe. |
| 11 | Effort log | Policy §3 requires actual minutes logged (90-minute cap) | Confirm the log exists |

## Exact fix list (in order)
1. Replace the disclaimer with the text in (a).
2. Add the health and sensitive-records exclusion to §07.
3. Replace the Elena wording in three places as in (b); the human CEO sends the report.
4. Fix §08 D&D: "…under a separate written agreement."
5. Replace §06 and the §05 languages sentence as in (d)6 and (d)7.
6. Remove all "DRAFT — CEO REVIEW REQUIRED" banners after CEO approval; generate the release-candidate PDF; confirm 2 pages.
7. Zain accepts the adapted free terms (email "I accept" or a logged click) before delivery. Sending unreviewed terms is a CEO risk decision.
8. Signed policy record located; CEO approval of the final report recorded.
9. R&C confirms the CASL basis; effort minutes logged.

## REQUIRES_LICENSED_COUNSEL
- Retrospective acceptance of the terms.
- Unreviewed liability wording.
- Validity of electronic acceptance.
- AI persona disclosure, against misleading-representation rules and CASL identification (sections UNVERIFIED).

## CEO decisions
- Send the draft terms now, or wait for counsel.
- The acceptance method.
- The human accountable contact.
- Whether Elena keeps a human-style name and address.
- Approval of the final report.
- Sign the policy.

**FOR QUALIFIED COUNSEL REVIEW. NOT LEGAL ADVICE. STOP FOR CEO REVIEW.**
