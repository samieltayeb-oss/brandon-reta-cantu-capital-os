# DRAFT — NOT LEGALLY APPROVED
# NEXORA Contracts Checklist — Sales Launch Readiness (NEXORA-GTM-20261014-29)

**Advisory only. Not legal advice. STOP FOR CEO APPROVAL.**
Prepared by: NEXORA Legal Counsel Desk (AI drafting assistant — **not a licensed lawyer**). Nothing here creates, signs, sends or approves any agreement. Builds on `NEXORA-GTM-20261014-26/contract_architecture.md`, `GROK-REVENUE-20261014-24/commercial_structures.md`, `GROK-REVENUE-20261014-18/contracting_guidance.md` and the SUMMITOS files in `LIAISON-20261014-06/`.

Conventions: all amounts, percentages, periods and caps are **[UNKNOWN — CEO TO DECIDE]**. Statute references are UNVERIFIED unless marked VERIFIED. No case law is relied on beyond what earlier files already recorded (Tercon, confirmed from the court's summary only).

---

## 1. Inventory — which agreement documents actually exist (checked 2026-10-14)

Search: `rg -il 'DRAFT' /workspace/legal` plus a filename search of `/workspace` for NDA/MSA/SOW/DPA files. Result: **the only actual agreement text NEXORA has is the SUMMITOS pilot draft.** Every other file is advisory analysis, not an agreement.

| Document | Status | Path |
|---|---|---|
| SUMMITOS Pilot Agreement v1 (original) | EXISTS AS DRAFT — superseded, kept unchanged | `/workspace/legal/LIAISON-20261014-06/draft_agreement.md` |
| SUMMITOS Pilot Agreement v2 | EXISTS AS DRAFT — **NOT signable** (liability, privacy, tax, IP, data return, cancellation, refunds unresolved) | `/workspace/legal/LIAISON-20261014-06/draft_agreement_v2.md` |
| SUMMITOS Schedule A proposal v3.1 (v3 superseded) | EXISTS AS DRAFT PROPOSAL — **NOT signable** | `/workspace/legal/LIAISON-20261014-06/schedule_a_proposal_v3_1.md` |
| Proposal template (non-binding) | NOT YET DRAFTED | — |
| Short-form fixed-fee SOW + standard terms (Rung 1) | NOT YET DRAFTED | — |
| Master Services Agreement (MSA) | NOT YET DRAFTED | — |
| Automation SOW (Rung 2) | NOT YET DRAFTED | — |
| Connected-systems / custom software SOW with milestone & acceptance schedule (Rung 3) | NOT YET DRAFTED | — |
| Managed Services / Retainer Schedule (Rung 4) | NOT YET DRAFTED | — |
| Mutual NDA | NOT YET DRAFTED | — |
| Data Processing Agreement (+ subprocessor list) | NOT YET DRAFTED | — |
| Change Order form | NOT YET DRAFTED | — |
| Acceptance Certificate | NOT YET DRAFTED | — |
| Paid Discovery SOW for SUMMITOS prospects | NOT YET DRAFTED | — |
| Referral / Partner Agreement | NOT YET DRAFTED (not needed for the five offers below) | — |

Non-agreement supporting files (advisory only): contract_architecture.md (GTM-26), commercial_structures.md (GROK-24), contracting_guidance.md (GROK-18), initial_risk_assessment.md, compliance reviews, open_questions_v2.md, LIAISON-09 advisory_notes.md, framework/legal_research_framework.md.

**Consequence:** every offer below needs at least one document that does not exist yet. "Required" lists below are what must be drafted, CEO-approved and counsel-reviewed.

---

## 2. Cross-offer decisions (apply to all five)

| Topic | CEO decision | Counsel decision |
|---|---|---|
| Deposits | Amount/% per offer; whether work starts only after deposit clears; refundable, partly refundable or non-refundable | Enforceability of non-refundable deposit vs penalty characterisation; refund wording on early termination; late-payment interest (Interest Act — UNVERIFIED). GST on deposits → accountant |
| Liability cap | Option (fees paid under SOW / fees in prior [N] months / multiple / fixed sum) and amount per offer; confirm E&O/cyber insurance limits [UNKNOWN] | Exclusions, carve-outs (confidentiality, data, IP, fraud), super-cap; enforceability (Tercon — confirmed from the court's summary only) |
| IP model | Default per rung: client owns client-specific deliverables on full payment, NEXORA retains pre-existing tools with licence to client (proposed) — or licence-only | Assignment vs licence wording, moral rights waiver (Copyright Act — UNVERIFIED), open-source, escrow (Rung 3) |
| Acceptance | Acceptance window [N business days UNKNOWN]; whether to propose deemed acceptance (on silence and/or production use) | Whether deemed acceptance is enforceable/fair as drafted; defect re-test loop; link to final payment |
| Renewal | **Default: no automatic renewal** (consistent with CEO's SUMMITOS no-auto-conversion direction). Any exception needs explicit CEO approval | If auto-renewal ever approved: notice and consumer-protection requirements (Consumer Protection Act (Alberta) applicability to business clients — UNVERIFIED) |
| DPA trigger and roles | Policy: no NEXORA access to client personal information (PI) before a signed DPA; whether to accept client's DPA paper | NEXORA's role (likely service provider/processor acting for client as controlling organisation — REASONED_LEGAL_INTERPRETATION); PIPA (Alberta) vs PIPEDA applicability; breach notification flow-down; subprocessors; cross-border storage (UNVERIFIED) |
| Governing law | Accept Alberta as default (proposed) | Governing law and venue clause; see §8 for EGM Drywall |
| Sales claims | Approve a conservative, evidence-backed claims list for sales emails | s.74.01 question — see §9 |
| Templates | Template build priority and counsel budget | Review of every template before first use |

---

## 3. Offer 1 — Rung 1 Assessment (paid, fixed-fee)

**Required documents**
| Document | Status |
|---|---|
| Mutual NDA (before confidential discovery) | NOT YET DRAFTED |
| Proposal (non-binding) | NOT YET DRAFTED |
| Short-form fixed-fee assessment SOW with embedded standard terms (or SOW under MSA for likely repeat clients) | NOT YET DRAFTED |
| DPA — only if NEXORA will access client PI (e.g. reviewing customer or owner records) | NOT YET DRAFTED |

**CEO decisions:** deposit % and refundability; balance trigger (delivery vs acceptance); cap option (proposed: fees paid under the SOW) and any fixed sum; IP (client owns report on full payment; NEXORA retains methods/frameworks); acceptance window for report and whether delivery = deemed acceptance after window; revision rounds; renewal: none — ends on completion; whether to scope assessments to avoid PI entirely (avoids DPA).
**Counsel decisions:** advisory/no-reliance disclaimer and no-outcome-guarantee wording; cap and exclusions; non-refundable deposit; deemed acceptance; governing law; incidental-PI handling clause if no DPA.

## 4. Offer 2 — Rung 2 Automation Sprint

**Required documents**
| Document | Status |
|---|---|
| Mutual NDA | NOT YET DRAFTED |
| Proposal | NOT YET DRAFTED |
| MSA (preferred) — or standalone SOW + standard terms for a first job | NOT YET DRAFTED |
| Automation SOW (milestones, test cases) | NOT YET DRAFTED |
| Credentials/access schedule | NOT YET DRAFTED |
| Change Order form | NOT YET DRAFTED |
| Acceptance Certificate | NOT YET DRAFTED |
| DPA — if PI flows through NEXORA-controlled tools or accounts (likely for CRM/dispatch, e.g. Colz Electric; property data, e.g. AspirePeak) | NOT YET DRAFTED |

**CEO decisions:** deposit % and refundability; milestone split (design sign-off / build complete / acceptance); cap (fees under SOW vs prior [N] months; any data super-cap); IP (client-specific config/scripts assigned on payment vs licensed; reusable components retained); UAT acceptance window and deemed acceptance; defect-correction period (if any); renewal: none — ongoing support only via Rung 4; when MSA becomes mandatory.
**Counsel decisions:** MSA core terms; IP clause; third-party platform disclaimer (no warranty of vendor APIs or AI output accuracy); DPA roles and breach notice; data return/deletion on exit (no deadline promised); deemed acceptance; governing law.

## 5. Offer 3 — Rung 3 Connected-Operations Build

**Required documents**
| Document | Status |
|---|---|
| Mutual NDA | NOT YET DRAFTED |
| Paid discovery SOW (recommended first stage) | NOT YET DRAFTED |
| MSA | NOT YET DRAFTED |
| Detailed connected-systems SOW with milestone & acceptance-gate schedule | NOT YET DRAFTED |
| DPA (+ subprocessor list) — likely required | NOT YET DRAFTED |
| Change Order form; Acceptance Certificate | NOT YET DRAFTED |
| Security/hosting schedule — if NEXORA hosts | NOT YET DRAFTED |
| Any SUMMITOS component | SUMMITOS v2 EXISTS AS DRAFT but is **NOT signable** — must be excluded |

**CEO decisions:** mobilisation deposit and refundability; milestone gates and %; holdback (yes/no, %, release period); cap structure (multiple / fixed sum / super-cap) aligned with insurance; IP model A (assign client code, licence back) vs B (NEXORA owns, licenses); escrow; acceptance window per gate and deemed acceptance; warranty period; renewal: none for project, maintenance via Rung 4; whether NEXORA hosts anything.
**Counsel decisions:** all of the above wording; Tercon-aligned cap drafting; open-source disclosure; transition assistance (no deadline); DPA roles, cross-border transfer, breach notification; security schedule; precedence clause (proposed DPA > MSA > SOW > Change Order > Proposal); governing law.

## 6. Offer 4 — Rung 4 Managed Care (recurring)

**Required documents**
| Document | Status |
|---|---|
| MSA | NOT YET DRAFTED |
| Managed Services / Retainer Schedule (scope, included hours, exclusions) | NOT YET DRAFTED |
| DPA — if PI accessed in ongoing support | NOT YET DRAFTED |
| Support process description (response targets only if operationally verified and CEO-approved) | NOT YET DRAFTED |

**CEO decisions:** fee, frequency, in advance vs arrears; prepayment/deposit and refundability; unused hours (rollover/forfeit); overage rate; price-change notice; fixed initial term and termination notice; **renewal: no automatic renewal by default** — continuation by written renewal only; cap (fees in prior [N] months); whether any response target can honestly be offered (none verified today).
**Counsel decisions:** reasonable-skill-and-care warranty; no uptime/SLA wording; exit assistance and data return (no deadline); auto-renewal requirements if CEO ever approves it; DPA; governing law.

## 7. Offer 5 — SUMMITOS Paid Discovery (NOT the pilot)

SUMMITOS Pilot Agreement v2 and Schedule A v3.1 **exist as drafts but are NOT signable** and must not be used, attached or referenced as an offer. Argon-reported blockers include: unenforced tier/seat limits (10 and 25 PROPOSED only), mock/demo supplier integrations, incomplete onboarding, no automatic 90-day Stripe termination, unverified data export, and a hardcoded tenant in supplier email ingestion (possible incident — counsel/Risk & Compliance).

**Required documents**
| Document | Status |
|---|---|
| Mutual NDA | NOT YET DRAFTED |
| Paid Discovery SOW for SUMMITOS prospects (advisory/requirements only; demo disclaimer) | NOT YET DRAFTED |
| DPA | Not needed **if** discovery loads no customer data (recommended rule); otherwise NOT YET DRAFTED and blocks |

**CEO decisions:** discovery fee, deposit and refundability; whether the discovery fee is credited against a future pilot (if so, no commitment that a pilot will be available or on what date); rule that no customer data enters SUMMITOS during discovery; approved demo script/claims (no live integrations, no SLA, no profitability claims); acceptance of discovery report; renewal: none.
**Counsel decisions:** demo/no-reliance disclaimer; statement that no SaaS access or pilot is granted; Competition Act exposure from SUMMITOS public-site claims (CRITICAL in initial risk assessment — must be removed or substantiated before marketing SUMMITOS); possible incident assessment for the hardcoded-tenant route; cap; governing law.

---

## 8. Governing law — EGM Drywall (counsel placeholder)

- EGM Drywall HQ is in **Edmonton**, so **Alberta governing law and Alberta courts are the likely default — counsel placeholder, not a conclusion.**
- **Locations of EGM's other offices are UNKNOWN.** If any are outside Alberta: possible extra-provincial privacy law (PIPEDA or another province's law — UNVERIFIED), site-visit/safety rules, and travel/insurance terms → counsel and Risk & Compliance.
- Venue (Calgary vs Edmonton judicial centre), and any EGM-proposed paper → counsel.
- CEO: confirm the office list in scope before the SOW is drafted.

## 9. Competition Act s.74.01 — one-to-one sales emails (question for counsel)

**Text (VERIFIED_PRIMARY_AUTHORITY — fetched 2026-10-14 from https://laws-lois.justice.gc.ca/eng/acts/C-34/section-74.01.html, Act current to 2026-09-21):** s.74.01(1) makes it reviewable conduct, for the purpose of promoting a product or business interest "by any means whatever", to (a) make "a representation to the public that is false or misleading in a material respect"; (b) make "a representation to the public in the form of a statement, warranty or guarantee of the performance, efficacy or length of life of a product that is not based on an adequate and proper test thereof, the proof of which lies on the person making the representation"; or (c) make a representation to the public in the form of a warranty/guarantee or promise to repeat a service "until it has achieved a specified result" that is materially misleading or has no reasonable prospect of being carried out. (s.52 criminal provision was also verified in the initial risk assessment.)

**Question for counsel:** whether performance or result claims made in **individual, one-to-one sales emails** (e.g. ROI, hours-saved or cost-savings claims, "eliminate margin erosion") are "representations to the public" for s.74.01 (and s.52), including where the same wording is reused across many prospects as a template. The section text quoted above does not itself define "to the public"; whether any other provision or authority settles this is **UNVERIFIED** — no case law is cited here. → **REQUIRES_LICENSED_COUNSEL.**

**Interim rule (pending counsel), proposed for CEO approval:** treat every sales email as if s.74.01 applies. No guarantees of ROI, savings, profitability or results; any performance figure must be backed by a documented test or real client data on file before sending; use ranges with stated assumptions and "examples, not guarantees"; no SUMMITOS capability claims beyond Argon's PRODUCTION_VERIFIED items; no SLA/response-time claims. CASL compliance for the emails themselves → Risk & Compliance (UNVERIFIED).

---

## 10. Minimum to sign the FIRST deal (recommended: a Rung 1 assessment with no PI access)

1. CEO picks the first offer and client (recommend Rung 1 assessment scoped to avoid personal information).
2. Draft Mutual NDA → CEO approval → counsel review.
3. Draft short-form assessment SOW + standard terms → CEO approval → counsel review.
4. CEO decides: fee, deposit % and refundability, cap option/amount, IP default, acceptance window and deemed acceptance (yes/no), no renewal.
5. Counsel settles: cap/exclusions, advisory disclaimer, deposit wording, deemed acceptance, governing law (Alberta placeholder).
6. Accountant confirms GST treatment of deposit and invoices.
7. Confirm insurance (E&O/cyber) is in place and matches the cap [UNKNOWN].
8. CEO approves sales-email claims under the §9 interim rule.
9. If any PI will be touched: a reviewed DPA is required first — otherwise rescope.
10. CEO signs; no bot signs, sends or represents itself as NEXORA staff.

---

## 11. Readiness table

| Offer | Documents existing today | Status | Main blockers |
|---|---|---|---|
| Rung 1 Assessment | None (NDA, SOW not drafted) | **READY WITH DECISIONS** — once NDA + short-form SOW are drafted and reviewed | Templates; deposit/cap/IP/acceptance decisions; DPA only if PI |
| Rung 2 Automation Sprint | None | **READY WITH DECISIONS** — only after MSA (or SOW+terms), SOW, Change Order, Acceptance Certificate drafted; **BLOCKED** where PI flows until a DPA exists | Templates; DPA likely; IP model |
| Rung 3 Connected-Operations Build | None | **BLOCKED** | MSA, detailed SOW, DPA, security schedule not drafted; cap/IP/escrow/holdback decisions; start with paid discovery SOW |
| Rung 4 Managed Care | None | **BLOCKED** | MSA and services schedule not drafted; no verified response targets; term/renewal decisions; DPA if PI |
| SUMMITOS Paid Discovery | SUMMITOS pilot v2 / Schedule A v3.1 exist but NOT signable and not to be used | **READY WITH DECISIONS** — discovery-only SOW + NDA, no customer data loaded, no pilot access; **BLOCKED** for marketing until public-site claims are fixed | Discovery SOW not drafted; site claims (CRITICAL); hardcoded-tenant incident assessment |

"READY WITH DECISIONS" means no structural blocker beyond drafting the listed short documents and making the CEO/counsel decisions; it does **not** mean signable today. **Nothing is signable today.**

---

## 12. Top decisions

**CEO (top):** (1) first offer and client; (2) deposit % and refundability per offer; (3) liability cap option and amounts, matched to insurance; (4) default IP model per rung; (5) acceptance window and whether to propose deemed acceptance; (6) confirm no automatic renewal for Rung 4; (7) policy: no PI access before signed DPA; (8) approve interim sales-claims rule; (9) template build order and counsel budget; (10) EGM office list.

**Counsel (top):** (1) s.74.01/s.52 application to one-to-one sales emails; (2) cap, exclusions and carve-outs; (3) IP assignment vs licence and moral rights; (4) non-refundable deposits and deemed acceptance enforceability; (5) DPA roles, PIPA vs PIPEDA, breach notification; (6) governing law/venue (Alberta placeholder; EGM extra-provincial offices); (7) SUMMITOS discovery disclaimers, public-site claims and hardcoded-tenant incident assessment; (8) review of every template before first use.

*DRAFT — NOT LEGALLY APPROVED. Advisory only. Not legal advice. STOP FOR CEO APPROVAL.*
