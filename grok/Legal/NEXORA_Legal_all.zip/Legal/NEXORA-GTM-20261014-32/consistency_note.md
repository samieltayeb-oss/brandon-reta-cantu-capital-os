**DRAFT — FOR COUNSEL REVIEW, NOT FOR SIGNATURE. NOT LEGAL ADVICE.**

# Consistency Note — GTM-32 vs GTM-31 and GTM-29
Task NEXORA-GTM-20261014-32 (QC). Prepared by an AI drafting assistant (not a lawyer). Only the two GTM-32 files were edited; GTM-31 and GTM-29 are unchanged.

## Conflicts and resolutions (14)
| # | Topic | Conflict | Resolution (GTM-32 edit) |
|---|---|---|---|
| 1 | Party names / defined terms | Free terms used "you"/[PROSPECT NAME]; GTM-31 uses [CLIENT LEGAL NAME] ("Client"), "Party" | Free terms: [PROSPECT LEGAL NAME] ("Prospect" or "you"), "Party", [DATE]; notes add §1 row: Prospect becomes Client at paid stage |
| 2 | Stage sequence | GTM-29 §3/§10 and GTM-31 SOW §2 / cover note treat the paid assessment as the step straight after the free call | Free terms state the 3-step sequence; notes already reposition the SOW |
| 3 | Confidentiality scope | Light clause had no exclusions; NDA §2 has 4 | Added the same 4 exclusions |
| 4 | Confidentiality survival | Light clause silent; NDA §11 brackets survival | Added [SURVIVAL PERIOD — COUNSEL]; new counsel Q6 |
| 5 | Prospect-facing reference | Free terms cited "draft GTM-31" (internal ID) | Replaced with "mutual non-disclosure agreement [internal ref]" |
| 6 | PI / DPA trigger | Free terms "won't use, delete"; GTM-31 "pause + DPA"; GTM-29 "no PI access before signed DPA" | Free terms: notify, delete, drop from scope; no DPA at free stage; PI work only at paid stage after a signed DPA |
| 7 | Retention | Free terms lacked NDA §7-style backup/legal-record exception | Added to retention bracket |
| 8 | s.74.01 | Notes said "flag for counsel"; GTM-29 §9 VERIFIED the text; free terms didn't link to interim rule | Notes: text verified, application still for counsel; free terms: no ROI/performance figures, cites interim rule |
| 9 | IP | GTM-29 proposes client owns report on payment; GTM-31 §10 bracket; free terms implied licence | Free terms: non-exclusive internal-use licence, no ownership transfer [CEO/COUNSEL], intentional difference noted; CEO decision 7 |
| 10 | Deposit | Notes omitted deposit | Notes §8: deposit/refundability unchanged bracket; free terms: no deposit |
| 11 | Credit | "Credit toward later work" (GTM-31) vs "toward implementation" (notes) | Notes: rename, CEO bracket; no credit for free assessment |
| 12 | Acceptance | Notes didn't address SOW §9 | Added §9 row (applies to proposal; not acceptance of implementation) |
| 13 | Governing law / venue | Free terms lacked venue bracket; EGM (Edmonton) flagged in GTM-29 §8 | Added venue bracket and counsel Q7; notes §16 row |
| 14 | Open counsel question | GTM-31 cover note Q9 (standalone SOW vs MSA) not carried forward | Notes counsel Q4 |

Checked with no conflict: liability-cap owners (CEO/Counsel), e-signature/acceptance (Alberta Electronic Transactions Act, sections UNVERIFIED), no renewal, no obligation to proceed, fee pending CEO approval, NDA required at paid stage (consistent with GTM-29 "NDA before confidential discovery").

## Recommended changes to older files (not made)
**GTM-31 assessment_sow_draft.md:** apply all edits in notes_gtm31_sow_changes.md (rename; §2 references free assessment; §3 scope/access/PI options; §4 proposal + non-binding estimate; §8 credit wording; §9 acceptance of proposal; §10 design/estimate IP; §11 NDA as pre-condition, drop fallback).
**GTM-31 mutual_nda_draft.md:** §1 Purpose: add "including a paid assessment and implementation proposal"; no other change needed. Optionally state it supersedes any light confidentiality clause in the free assessment terms for later disclosures.
**GTM-31 cover_note_for_counsel.md:** Purpose: SOW is the paid stage-3 assessment & implementation proposal, not rung 1 after the call; Assumption 3: add the free assessment step; add placeholders for free terms; add the GTM-32 counsel questions.
**GTM-29 contracts_checklist.md:** §1 inventory: Mutual NDA and short-form SOW now EXIST AS DRAFT (GTM-31); add free assessment terms (GTM-32). §3 and §10: insert the free assessment before the paid assessment; §11 readiness for Rung 1 updated accordingly; §12 add CEO decisions on free-terms acceptance, retention and liability.
**Marking convention:** GTM-29 uses "DRAFT — NOT LEGALLY APPROVED"; GTM-31 uses "DRAFT — NOT FOR SIGNATURE. FOR LICENSED COUNSEL REVIEW"; GTM-32 uses "DRAFT — FOR COUNSEL REVIEW, NOT FOR SIGNATURE". CEO to pick one standard label.

**DRAFT — FOR COUNSEL REVIEW, NOT FOR SIGNATURE. NOT LEGAL ADVICE.**
