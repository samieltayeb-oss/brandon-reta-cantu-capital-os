**DRAFT — FOR COUNSEL REVIEW, NOT FOR SIGNATURE. NOT LEGAL ADVICE.**

# Free Business Technology & Growth Assessment — Terms (Proposed)
Task NEXORA-GTM-20261014-32 · Prepared by an AI drafting assistant (not a lawyer).

These terms apply between NEXORA Technologies Corp., Calgary, Alberta ("NEXORA") and [PROSPECT LEGAL NAME] ("Prospect" or "you"); each a "Party". This is step 2 of NEXORA's sequence: (1) free 20-minute introductory call (no contract); (2) this free assessment; (3) only if both Parties separately agree in writing, a paid Connected Operations Assessment & Implementation Proposal under its own signed SOW and mutual NDA. **Effective Date:** [DATE]. You accept them by [BRACKET — acceptance mechanism, e.g. email reply "I agree" or click-through — CEO/COUNSEL].

**1. What it is.** A short, free review of up to **2 workflows**, using public information and what you choose to describe to us. NEXORA spends **no more than 60–90 minutes** of internal effort and gives you a written summary of **2 pages or less**. It does **not** include system access, review of sensitive records, architecture or solution design, code, integrations, prototypes, or ROI, savings or other performance figures.

**2. No fee, no obligation.** The assessment is free. Neither of us is obliged to do anything further. You are not committing to buy anything, and there is no exclusivity — you may work with anyone.

**3. Not advice; no reliance; no guarantee.** The summary contains general observations only. It is not professional, legal, financial, accounting or tax advice. Do not rely on it for decisions without getting independent advice. NEXORA does not guarantee any result, savings, efficiency gain or return on investment, and the summary will not contain ROI, savings or performance figures [consistent with NEXORA's interim Competition Act s.74.01 claims rule — GTM-29 §9; application to one-to-one communications pending counsel].

**4. What to share.** Please share only non-sensitive business information. Do **not** share personal information (e.g. customer, employee, tenant or owner details), passwords or credentials, or confidential records. If any is shared, NEXORA will not use it, will delete it [BRACKET — timing — CEO/COUNSEL], will tell you, and the affected item will be dropped from scope. No data processing agreement is used at this stage; any work that needs personal information belongs to the paid stage and requires a signed DPA first. NEXORA keeps information you share for [BRACKET — retention period and any backup/legal-record exception — CEO/COUNSEL], then deletes it.

**5. Confidentiality.** Each of us will keep the other's non-public information confidential and use it only for this assessment. This does not apply to information that is or becomes public through no fault of the recipient, was lawfully known to it already, is lawfully received from a third party without a confidentiality obligation, or is independently developed. These obligations last [BRACKET — SURVIVAL PERIOD — COUNSEL]. If you want to share confidential material, that falls outside this free assessment; we would first sign NEXORA's mutual non-disclosure agreement [internal ref: GTM-31 draft].

**6. Liability.** The assessment is provided as-is and at no charge. To the extent permitted by law, NEXORA's liability is [BRACKET — excluded / limited to [amount] — CEO/COUNSEL; enforceability to be confirmed by counsel].

**7. The summary.** NEXORA keeps all rights in its methods, know-how and templates. You may use the summary internally in your business (a non-exclusive right of use; ownership is not transferred) [BRACKET — confirm licence wording — CEO/COUNSEL]. This differs intentionally from the paid stage, where licence vs ownership is open. NEXORA will not publish your name or details without your written consent. Internal use of anonymized or aggregate learnings: [BRACKET — CEO DECISION].

**8. Stopping.** Either of us may stop the assessment at any time, by notice (email is enough), without cost.

**9. Communications.** Agreeing to these terms is **not** consent to receive marketing messages. Any consent for follow-up marketing is requested separately [Risk & Compliance to define the CASL consent process].

**10. Governing law.** [Alberta — PLACEHOLDER PENDING COUNSEL]; [BRACKET — courts/venue — COUNSEL]. **No deposit or credit** applies to this free assessment.

---

## Questions for counsel
1. Is a full exclusion (or a cap) of liability for a free service enforceable in Alberta, and what carve-outs (e.g. negligence, confidentiality breach) are needed? Exclude vs. limit?
2. Does email-reply or click acceptance form a binding agreement here; what record should NEXORA keep (Alberta *Electronic Transactions Act* — section UNVERIFIED)?
3. Is the light mutual confidentiality clause (§5) adequate for a free, non-sensitive assessment, or is a short definition/exclusions/survival period needed?
4. CASL (*Canada's Anti-Spam Legislation*, sections UNVERIFIED): confirm that consent to these terms and marketing consent must be kept separate, and whether the assessment-related emails themselves are commercial electronic messages.
5. Is the "will not use and will delete" handling of inadvertently shared personal information sufficient under PIPA (Alberta) / PIPEDA (sections UNVERIFIED), or are notices/records needed?
6. Confirm the light clause's exclusions and survival track the NDA's §2 and §11, and that §5 needs no return/destruction mechanics beyond §4.
7. Governing law/venue where a prospect is outside Calgary or Alberta (e.g. EGM Drywall, HQ Edmonton; other offices UNKNOWN).
8. Does the no-reliance disclaimer adequately address negligent-misstatement risk for free advice?

## CEO decisions
1. Acceptance mechanism (email reply vs. click).
2. Deletion timing for inadvertently shared sensitive information.
3. Retention period for shared information and the summary.
4. Liability: full exclusion or cap (and amount, if a cap).
5. Internal use of anonymized/aggregate learnings — yes/no.
6. Confirm Alberta as governing law (with counsel).
7. Confirm the free summary is licence-only (internal use).
8. Confirm that ending the free assessment carries no follow-up obligation and that CASL consent is requested separately.

**DRAFT — FOR COUNSEL REVIEW, NOT FOR SIGNATURE. NOT LEGAL ADVICE.**
