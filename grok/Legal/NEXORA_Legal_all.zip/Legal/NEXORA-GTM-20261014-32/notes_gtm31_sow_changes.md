**DRAFT — FOR COUNSEL REVIEW, NOT FOR SIGNATURE. NOT LEGAL ADVICE.**

# Notes: Changes to the GTM-31 Assessment SOW
Task NEXORA-GTM-20261014-32. Proposed edits only — the GTM-31 files are **not** edited.

New sequence: (1) free 20-minute call → (2) free Business Technology & Growth Assessment → (3) **paid Connected Operations Assessment & Implementation Proposal** (this SOW) → separate implementation SOW/MSA.

| Clause | Proposed edit |
|---|---|
| Title / header | Rename to "Statement of Work — Connected Operations Assessment & Implementation Proposal". Note it is the paid implementation-proposal stage. |
| §2 Background | Add that the Client received the free assessment summary under separate free terms, that this SOW builds on it, and that the free terms do not carry over into this SOW. |
| §3 Scope | Reframe as deeper review of workflows in the free summary (and others agreed), plus solution design, implementation plan and estimate. Keep "no production changes". |
| §3 System access | Replace the bare bracket with an option: limited, read-only access, scoped in writing [BRACKET — access terms — CEO/COUNSEL], or no access. |
| §3 Personal information | Two options [BRACKET — CEO/COUNSEL]: (A) keep the no-personal-information assumption plus pause-and-DPA trigger; or (B) if access to personal information is expected, sign a DPA before work starts. |
| §4 Deliverables | Replace "assessment report" with: assessment findings, solution design, implementation plan, and an **implementation proposal and estimate that is non-binding until a separate SOW or MSA is signed**. Keep the no-guarantee and s.74.01 language (s.74.01 text VERIFIED in GTM-29 §9; application to one-to-one emails remains a counsel question). Estimate figures must state assumptions and evidence. |
| §5 Exclusions | Keep; state that implementation is only under a separate signed SOW/MSA. Estimate is not an offer. |
| §1 Parties | Keep [CLIENT LEGAL NAME] ("Client"); note the free-stage "Prospect" becomes "Client" here. |
| §6 Client Responsibilities | Add: confirm whether personal information or system access is involved before the SOW starts. |
| §8 Fees | Fee stays [CAD amount — PENDING CEO PRICE APPROVAL]. Deposit and refundability unchanged: [BRACKET — CEO; enforceability — COUNSEL]. Taxes: accountant. Rename "credit toward later work" to "credit toward implementation": [BRACKET — CEO DECISION, including amount/period if any]. No credit is given for the free assessment. |
| §9 Acceptance | Apply acceptance to the implementation proposal and estimate as deliverables; window and deemed acceptance stay [BRACKET — CEO/COUNSEL]. Acceptance of the proposal is not acceptance of any implementation offer. |
| §10 IP | Address design and estimate ownership/licence [BRACKET — CEO/COUNSEL]; NEXORA retains methods and templates. |
| §11 Confidentiality | Make the GTM-31 mutual NDA a **pre-condition** (signed before or with this SOW) — see below. Remove the "if no NDA" fallback or keep it only as counsel's option. |
| §12–13 | No structural change; disclaimer and liability cap still [BRACKET — CEO/COUNSEL]. Consider stating the estimate is not warranted. |
| §16 Governing law | Unchanged: [Alberta — PLACEHOLDER PENDING COUNSEL]; venue [BRACKET — COUNSEL]; EGM Drywall offices outside Alberta flagged. |
| §15 | Keep no renewal / no obligation to purchase implementation. |

## Is the NDA now required at this stage?
**Recommendation: yes.** The free assessment uses only a light clause because it excludes confidential material. The paid stage involves deeper review, possible system access and confidential pricing/design, so the GTM-31 mutual NDA should be signed before or with this SOW. Counsel to confirm (or fold the NDA terms into the SOW/an MSA).

## Questions for counsel
1. Does a non-binding estimate need extra wording to avoid being treated as an offer?
2. Which PI option (A or B) is safer, and what DPA minimums apply (PIPA/PIPEDA — sections UNVERIFIED)?
3. Should the NDA be standalone or merged into the SOW?
4. (Carried from GTM-31 cover note Q9) Is a stand-alone short-form SOW still adequate now that it ends in an implementation proposal, or should general terms or an MSA apply?

**DRAFT — FOR COUNSEL REVIEW, NOT FOR SIGNATURE. NOT LEGAL ADVICE.**
