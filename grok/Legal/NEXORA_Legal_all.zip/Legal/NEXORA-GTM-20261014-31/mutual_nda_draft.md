**DRAFT — NOT FOR SIGNATURE. FOR LICENSED COUNSEL REVIEW. NOT LEGAL ADVICE.**

# Mutual Non-Disclosure Agreement (Proposed)
Task NEXORA-GTM-20261014-31 · Prepared by an AI drafting assistant (not a lawyer).

**Parties:** NEXORA Technologies Corp., Calgary, Alberta ("NEXORA") and [CLIENT LEGAL NAME] ("Client"); each a "Party". **Effective Date:** [DATE].

## 1. Purpose
The Parties wish to exchange information solely to evaluate and, if separately agreed in writing, perform a possible engagement (the "Purpose").

## 2. Confidential Information
"Confidential Information" means non-public information disclosed by a Party ("Discloser") to the other ("Recipient"), in any form, that is marked confidential or that a reasonable person would understand to be confidential, including business, technical, financial, operational, systems and workflow information.

**Exclusions.** Confidential Information does not include information that the Recipient can show: (a) is or becomes public through no fault of the Recipient; (b) was lawfully known to the Recipient before disclosure without a confidentiality obligation; (c) is lawfully received from a third party without a confidentiality obligation; or (d) is independently developed without use of the Discloser's Confidential Information.

## 3. Use and Disclosure Limits
The Recipient will use Confidential Information only for the Purpose and will not disclose it except as permitted by this Agreement.

## 4. Standard of Care
The Recipient will protect Confidential Information with at least the care it uses for its own similar information, and no less than reasonable care.

## 5. Personnel and Advisers
The Recipient may disclose Confidential Information only to its employees, contractors and professional advisers who need to know it for the Purpose and are bound by confidentiality obligations at least as protective as these. The Recipient is responsible for their compliance.

## 6. Compelled Disclosure
If required by law, regulation or court order to disclose Confidential Information, the Recipient will (where legally permitted) give the Discloser prompt notice, cooperate reasonably with any effort to seek protection, and disclose only what is legally required.

## 7. Return or Destruction
On the Discloser's written request or at the end of discussions, the Recipient will return or destroy Confidential Information, subject to [BRACKET — retention exception for backups / legal-record copies, if any — COUNSEL]. Retained copies remain subject to this Agreement.

## 8. No Licence
No licence or other right in any Confidential Information or intellectual property is granted, except the limited right to use it for the Purpose.

## 9. No Obligation to Proceed
Neither Party is obliged to enter into any further agreement or engagement. Any engagement requires a separate signed agreement.

## 10. No Personal Information
The Parties do not intend to exchange personal information under this Agreement. If any personal information is exchanged, a separate agreement addressing it is required: [BRACKET — data processing agreement / handling terms, and handling of any inadvertently received personal information — COUNSEL].

## 11. Term and Survival
This Agreement applies to disclosures made during [BRACKET — TERM — CEO/COUNSEL]. Confidentiality obligations survive for [BRACKET — SURVIVAL PERIOD — COUNSEL] after [BRACKET — trigger, e.g. termination or disclosure — COUNSEL].

## 12. Remedies
**REQUIRES_LICENSED_COUNSEL.** [BRACKET — Proposed: a breach may cause harm for which damages may be inadequate, and the Discloser may seek injunctive or other equitable relief in addition to other remedies. Wording and enforceability to be confirmed by counsel.]

## 13. Governing Law
[Alberta — PLACEHOLDER PENDING COUNSEL], and [BRACKET — courts/venue — COUNSEL].

## 14. General
Entire agreement on its subject matter; amendments in writing; no assignment without consent [BRACKET — COUNSEL]; notices to the addresses in the signature blocks.

## 15. Electronic Signatures and Counterparts
This Agreement may be signed electronically and in counterparts, each an original and together one instrument. [BRACKET — confirm e-signature validity — COUNSEL.]

## Signatures
| NEXORA Technologies Corp. | [CLIENT LEGAL NAME] |
|---|---|
| Signature: ____________ | Signature: ____________ |
| Name: ____________ | Name: ____________ |
| Title: ____________ | Title: ____________ |
| Date: ____________ | Date: ____________ |
| Notice address: ____________ | Notice address: ____________ |

**DRAFT — NOT FOR SIGNATURE. FOR LICENSED COUNSEL REVIEW. NOT LEGAL ADVICE.**
