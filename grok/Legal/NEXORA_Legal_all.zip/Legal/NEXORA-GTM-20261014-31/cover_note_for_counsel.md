**DRAFT — NOT FOR SIGNATURE. FOR LICENSED COUNSEL REVIEW. NOT LEGAL ADVICE.**

# Cover Note for Licensed Counsel — Mutual NDA and Assessment SOW
Task NEXORA-GTM-20261014-31 · Prepared by an AI drafting assistant for NEXORA Technologies Corp. (not a lawyer). Builds on GTM-29 contracts_checklist.md, GTM-26 contract_architecture.md and GROK-24 commercial_structures.md.

## Purpose
Request review and revision of two proposed templates (mutual_nda_draft.md, assessment_sow_draft.md) for NEXORA's paid Connected Operations Assessment (rung 1). Not for signature until counsel review and CEO approval.

## Assumptions
1. The assessment involves no personal information; if any is encountered, work pauses and a DPA is added.
2. The fee is pending CEO price approval; no amount is filled in.
3. The free 20-minute introductory call precedes the SOW and needs no contract.
4. No system access or production changes unless agreed in writing.

## Placeholders and Decision Owners
| # | Document | Placeholder | Owner |
|---|---|---|---|
| 1 | Both | [CLIENT LEGAL NAME], [DATE] | CEO (per deal) |
| 2 | NDA §7 | Return/destruction retention exception | Counsel |
| 3 | NDA §10 | Separate agreement if personal information exchanged | Counsel |
| 4 | NDA §11 | Term of disclosures | CEO / Counsel |
| 5 | NDA §11 | Survival period and trigger | Counsel |
| 6 | NDA §12 | Remedies / injunctive relief (REQUIRES_LICENSED_COUNSEL) | Counsel |
| 7 | NDA §13 | Governing law [Alberta — PLACEHOLDER] and venue | Counsel |
| 8 | NDA §14 | Assignment | Counsel |
| 9 | NDA §15 | E-signature validity | Counsel |
| 10 | SOW §3 | System access terms | CEO / Counsel |
| 11 | SOW §3 | DPA terms / inadvertent personal information | Counsel |
| 12 | SOW §7 | Timeline | CEO |
| 13 | SOW §8 | Fee [CAD amount — PENDING CEO PRICE APPROVAL] | CEO |
| 14 | SOW §8 | Deposit amount and refundability | CEO (amount); Counsel (enforceability) |
| 15 | SOW §8 | Invoicing and payment terms | CEO |
| 16 | SOW §8 | Taxes [GST/other] | Accountant |
| 17 | SOW §8 | Credit toward later work | CEO |
| 18 | SOW §9 | Acceptance window and process / deemed acceptance | CEO / Counsel |
| 19 | SOW §10 | Licence vs ownership of report; moral rights | CEO / Counsel |
| 20 | SOW §11 | NDA date / fallback confidentiality | Counsel |
| 21 | SOW §12 | Warranty disclaimers | Counsel |
| 22 | SOW §13 | Liability cap and exclusions | CEO / Counsel |
| 23 | SOW §14 | Termination | CEO / Counsel |
| 24 | SOW §16 | Governing law [Alberta — PLACEHOLDER] and venue | Counsel |

## Questions for Counsel
1. Are non-refundable deposits enforceable as drafted for this service in Alberta, and how should refundability on termination be expressed?
2. What liability cap basis, exclusions and carve-outs are appropriate, and are they enforceable against small and mid-size business clients?
3. Should the Client receive an assignment or a licence of the report, how should NEXORA's retained methods and tools be protected, and should moral rights be waived?
4. Competition Act s.74.01 (and s.52): are performance or savings claims in one-to-one sales emails (including reused template wording) "representations to the public"? Is the SOW §4 disclaimer adequate?
5. What governing law and venue should apply for clients outside Alberta or with offices outside Alberta (e.g. EGM Drywall, HQ Edmonton, other office locations UNKNOWN)?
6. What NDA term and survival period are appropriate, and should trade secrets survive indefinitely?
7. Is the injunctive-relief clause appropriate and enforceable as drafted?
8. Are electronic signatures and counterparts valid for these agreements under the Alberta Electronic Transactions Act (relevant sections UNVERIFIED), and are any formalities required?
9. Is a stand-alone short-form SOW adequate without an MSA for this rung, or should general terms be added?

**DRAFT — NOT FOR SIGNATURE. FOR LICENSED COUNSEL REVIEW. NOT LEGAL ADVICE.**
