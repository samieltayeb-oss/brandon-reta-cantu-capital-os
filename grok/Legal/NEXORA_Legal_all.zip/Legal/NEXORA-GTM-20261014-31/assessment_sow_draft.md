**DRAFT — NOT FOR SIGNATURE. FOR LICENSED COUNSEL REVIEW. NOT LEGAL ADVICE.**

# Statement of Work — Connected Operations Assessment (Short Form, Proposed)
Task NEXORA-GTM-20261014-31 · Prepared by an AI drafting assistant (not a lawyer).

## 1. Parties
NEXORA Technologies Corp., Calgary, Alberta ("NEXORA") and [CLIENT LEGAL NAME] ("Client"). **SOW Effective Date:** [DATE].

## 2. Background
The Client and NEXORA held a free 20-minute introductory call. That call is not part of this SOW, was provided without charge, and required no contract. This SOW covers only the paid assessment below.

## 3. Scope
NEXORA will review the Client's current systems, workflows and integrations through interviews with Client personnel and document or system walkthroughs led by the Client.
- **No production changes.** NEXORA will not configure, modify or deploy anything in the Client's systems.
- **No system access** unless agreed in writing in advance, with scope stated: [BRACKET — access terms if any — CEO/COUNSEL].
- **No personal information.** The assessment is designed not to involve personal information. If personal information is encountered, NEXORA will pause the affected work and notify the Client, and the Parties will put a data processing agreement in place before that work resumes [BRACKET — DPA terms and handling of inadvertent exposure — COUNSEL].

## 4. Deliverables
A written assessment report with recommendations. Deliverables are **advisory only**. NEXORA does not guarantee any result, savings, return on investment, efficiency gain or other outcome. Any figures or estimates in the report will state their assumptions and supporting evidence and are examples, not guarantees (consistent with NEXORA's interim Competition Act s.74.01 rule pending counsel).

## 5. Exclusions
Implementation, configuration, integration, custom development, data migration, ongoing support, licensing or procurement of third-party software, legal, accounting, tax or regulatory advice, and any work not listed in Section 3. Any such work requires a separate signed agreement.

## 6. Client Responsibilities
Make knowledgeable personnel available for interviews; provide documents and walkthroughs reasonably requested; ensure materials shared contain no personal information; confirm it has the right to share materials and show third-party systems; review deliverables within the acceptance window.

## 7. Timeline
[BRACKET — start date, duration, milestones — CEO]. Dates depend on timely Client cooperation.

## 8. Fees and Payment
- **Fee:** [CAD amount — PENDING CEO PRICE APPROVAL]
- **Deposit:** [BRACKET — deposit amount/percentage and refundability — CEO; enforceability — COUNSEL]
- **Invoicing and payment terms:** [BRACKET — CEO]
- **Taxes:** [GST/other — ACCOUNTANT TO CONFIRM]
- **Credit toward later work:** [BRACKET — CEO DECISION]

## 9. Acceptance
[BRACKET — acceptance window and process, including whether deemed acceptance applies — CEO/COUNSEL].

## 10. Intellectual Property
- The Client receives [BRACKET — licence or ownership of the final report; scope; moral rights — CEO/COUNSEL] in the final report.
- NEXORA retains all rights in its methods, know-how, templates, frameworks and pre-existing tools, including any incorporated into the report.

## 11. Confidentiality
The Parties' mutual non-disclosure agreement dated [DATE] applies to this SOW. [BRACKET — if no NDA is signed, confidentiality terms — COUNSEL.]

## 12. Warranties and Disclaimers
NEXORA will perform the services with reasonable professional effort. [BRACKET — disclaimer of other warranties, express or implied — COUNSEL.]

## 13. Limitation of Liability
[BRACKET — liability cap basis and exclusions/carve-outs — CEO/COUNSEL]. No amounts are proposed in this draft.

## 14. Termination
[BRACKET — termination rights, notice, and fees/deposit on termination — CEO/COUNSEL].

## 15. No Renewal; No Obligation to Purchase
This SOW does not renew. Neither Party is obliged to purchase or provide any further work.

## 16. Governing Law
[Alberta — PLACEHOLDER PENDING COUNSEL]; [BRACKET — venue — COUNSEL].

## Signatures
| NEXORA Technologies Corp. | [CLIENT LEGAL NAME] |
|---|---|
| Signature: ____________ | Signature: ____________ |
| Name: ____________ | Name: ____________ |
| Title: ____________ | Title: ____________ |
| Date: ____________ | Date: ____________ |

**DRAFT — NOT FOR SIGNATURE. FOR LICENSED COUNSEL REVIEW. NOT LEGAL ADVICE.**
