# DRAFT — NOT LEGALLY APPROVED — Research, not legal advice — FOR QUALIFIED COUNSEL REVIEW
## ZAIN-SUDAN-B2B — Regulatory & Sanctions Screen (Zain Sudan Business; tech partner Franco Pinto "FP")
Prepared by NEXORA Legal Counsel Desk (AI legal-ops assistant; **not a lawyer**). Date: Oct 26, 2026 (MDT). Sources accessed Oct 26, 2026 unless stated.
Labels: VPA = VERIFIED_PRIMARY_AUTHORITY · RLI = REASONED_LEGAL_INTERPRETATION · UNV = UNVERIFIED · RLC = REQUIRES_LICENSED_COUNSEL. Risk: CRITICAL/HIGH/MEDIUM/LOW.

### Overall view: **AMBER**
- No sanctions-list hits were found for Zain Sudan, Zain Group or its major shareholders.
- The risk comes from four things: Sudan's war (SAF-led authorities in Port Sudan include persons designated by the US and Canada); payment-route and US-nexus issues; a Sudanese licensing regime that is not fully verified; and **FP's unknown jurisdiction plus Sami Suliman's dual role** (a Canadian person acting for FP).
- Proceed with market research only. Contracting needs counsel sign-off.

## 1. Telecom regulator (TPRA)
| Finding | Source | Label | Risk |
|---|---|---|---|
| TPRA issues **Value-Added Services licences** (SMS, IVR, call centres, digital services, mobile apps/portals, digital payments, USSD, "any other VAS") and **VAS Aggregator licences**. Aggregators need preliminary approval from at least one operator. Applicants must submit company documents, business, technical and organizational plans, and a tax clearance certificate. Fees follow the 2025 fee schedule. | https://tpra.gov.sd/en/services/telecom-licensing/ | VPA (page content) | MEDIUM |
| TPRA's regulations page lists "Regulations for Network Interconnection, Interoperability, and Access, 2025" and "Regulations for the Organization of Wholesale Services…, 2025". The texts were not read. | https://tpra.gov.sd/en/regulatory-frameworks/regulations/ | VPA (existence) / UNV (content) | MEDIUM |
| Whether a foreign B2B software or cloud provider working *through* Zain needs its own VAS licence, or is covered by Zain's licence, is not determined. | — | RLC | MEDIUM |
| Specific rules on ISPs or cloud, A2P SMS, data retention and lawful intercept: **not found** publicly. | — | UNV | — |
| Wartime: in Feb 2024 a nationwide blackout followed the RSF occupation of ISP facilities in Khartoum. Zain Sudan and Sudani set up new data centres in **Port Sudan**. The military-led government restricted Starlink. | Freedom House, Freedom on the Net 2024 (https://freedomhouse.org/country/sudan/freedom-net/2024); TIMEP Sep 19, 2024 (https://timep.org/2024/09/19/internet-in-conflict-sudans-battle-for-connection/) | UNV (secondary) | HIGH (operational) |
| A formal relocation of TPRA itself to Port Sudan: **not sourced**. | — | UNV | — |

## 2. Data, cloud and cyber law
- **No comprehensive data-protection law or DPA** in Sudan. The Constitution protects privacy, and there are sectoral laws (Electronic Transactions Act 2007; cybercrime laws). Sources: https://dataprotection.africa/sudan/ ; https://lexlint.io/law/sd ("as of 7 September 2026"). **UNV (secondary).**
- **Informatic Offences (Combating) Act 2007** exists; the CBoS hosts the text at https://cbos.gov.sd/en/content/informatic-offences-combating-act-2007. It includes an offence of unauthorized access to personal data (up to 5 years). **VPA (that the text exists and is hosted).**
  - The Council of Europe says the **Law on Combating Cybercrimes 2018 (amended 2020) repealed** the 2007 Act (https://www.coe.int/en/web/octopus/-/sudan). The two sources conflict on whether the 2007 Act is still in force. **UNV / RLC.**
- No data-localization rule for telecoms, and no CBoS outsourcing or cloud rule, was found. CBoS rules would matter only if a service touches Zain's mobile-money or payment products. **UNV / RLC.**
- US cloud availability: as of the Oct 25 memo, OpenAI lists Sudan as supported, and AWS and Google Cloud terms put sanctions and export compliance on the customer (see LIAISON-ALSALAM-20261025 memo §5). Azure, Meta and WhatsApp were not verified. **VPA / UNV.**

## 3. Sanctions
**Screening** (keyword screen of official bulk files: OFAC SDN/ALT/CONS downloaded Oct 25, 2026; Canada SEMA consolidated Oct 25, 2026; UN consolidated generated Oct 24, 2026; UK list report Oct 16, 2026; EU FSF Oct 23, 2026). The lists were not re-downloaded today, so additions since those dates are not covered. **UNV.**

Terms searched: Zain; Mobile Telecommunications Company; زين; Sudanese Mobile Telephone; Bader Al-Kharafi; Kharafi; Omantel / Oman Telecommunications; Kuwait Investment Authority; Al-Sharq Holding; Sudatel.

Result: **no relevant hits**. The only hits were irrelevant name fragments (e.g. "Zain Khan", "Zainal Arifin", Libyan Investment Authority). Fuzzy matching was not used. The individual Zain Sudan managers named on LinkedIn were **not screened** (the source is unverified and has no identifiers).

**Ownership**
- Zain Group's 2025 company overview shows **100% ownership of Sudanese Mobile Telephone (Zain) Company Limited** ("Zain Sudan"). Major Zain Group shareholders: Omantel 21.9% (indirect), Kuwait Investment Authority 15.9% (direct), PIFSS 6.0%, Al-Sharq Holding 5.05%. Source: https://zain.com/SR2025/wp-content/uploads/2026/04/02-Company-Overview.pdf. **VPA (company source).**
- **No Sudanese state shareholding is shown.** Sudatel was a pre-2006 shareholder, according to Wikipedia (UNV). The Kuwaiti and Omani state stakes are not sanctioned.
- Group CEO and Zain Sudan chair (per LinkedIn): Bader Nasser Al-Kharafi. Zain Sudan's MD, Elfatih Erwa, died in April 2025 (Zain Annual Report 2025). The current Zain Sudan CEO is **UNV**.

**SAF/RSF links**
- No public source found ties Zain Sudan to SAF or RSF ownership. **UNV.**
- Operationally, it operates under SAF-controlled authorities. Designated persons in that government include Burhan (US SDN Jan 16, 2025; Canada SEMA (Sudan) Sched. item 8) and finance minister Gibril Ibrahim (US SDN Sep 12, 2025). State-owned Ports Engineering Co. (Port Sudan) was added as an SDN on Jun 26, 2026. **VPA** (see the Oct 25 memo).
- Risk: payments or services that benefit these persons, such as licence fees or "contributions". **HIGH, RLC.**

**Rules**
- **Canada:** the SEMA (Sudan) Regulations (SOR/2024-61) s.3 apply to persons in Canada **and Canadians outside Canada** (https://laws-lois.justice.gc.ca/eng/regulations/SOR-2024-61/FullText.html, current to 2026-09-30). **VPA.** Sami Suliman is bound personally even when acting for FP abroad. **RLI.** No country-wide embargo applies, so dealing with the non-listed Zain is not per se prohibited. **RLI.**
- **US:** E.O. 14098 (list-based). The 50% rule makes entities blocked if they are owned 50% or more in aggregate by SDNs; Zain is not, on current info. **RLI.** The old Sudan embargo was revoked in 2017. US-nexus points: USD clearing, US-person staff, US cloud, AI and software vendors. **HIGH, RLI.**
- **FP's jurisdiction is UNKNOWN.** That determines which regimes FP itself is under (EU? UK? UAE? US?). **RLC.**
- **Payment route:** Zain Group in Kuwait is the natural payer. Paying from Kuwait or Bahrain in a non-USD currency to FP's or NEXORA's bank is the lowest-risk route. Payment from Sudan-based accounts invites bank de-risking. **RLI.**

## 4. Contract terms FP needs (checklist; wording for counsel)
1. Sanctions representation, mutual and continuing: no party, owner (50% / control) or beneficiary is listed by the UN, US, Canada, UK or EU; no benefit to listed persons, SAF/RSF or designated officials. Termination and suspension right on any listing or breach, with no liability.
2. KYC/UBO deliverables, re-screening at milestones, and audit and cooperation rights.
3. Payment in an approved currency (e.g. EUR, AED or KWD; USD only if counsel approves), from a named Zain Group entity and account outside Sudan, with no third-party payers. Sanctions-driven payment failure is not a default by FP.
4. Export control: classification of each deliverable (encryption 5D992 / ECL Cat. 5 Part 2); no re-export to restricted end users or military end use (SAF/RSF).
5. Data processing: a DPA (roles, security, sub-processors, cross-border transfers, breach notice, lawful-intercept requests routed through Zain), since Sudanese law gives no baseline.
6. Force majeure covering war, civil unrest, network shutdowns, government action and sanctions changes, with suspension and exit rights.
7. Limitation of liability: a cap (e.g. 12 months' fees); exclusions for indirect losses; carve-outs for confidentiality, sanctions and anti-bribery breaches.
8. Governing law and disputes: e.g. English law with LCIA arbitration, or DIFC law with DIFC-LCIA/DIAC; seat outside Sudan; enforceability in Sudan **RLC**.
9. Anti-bribery: CFPOA (Canada) covers Canadians; also the FCPA if there is a US nexus and the UK Bribery Act if UK-linked. No facilitation payments to TPRA or officials; books-and-records clause.
10. IP: FP and NEXORA keep background IP; a licence to deliverables on payment; no transfer of pre-existing tools.
11. Conflict of interest and roles: disclose Sami's dual NEXORA and FP role. Make clear which entity contracts, so that NEXORA is not inadvertently bound.

## 5. Points requiring licensed counsel
- FP's jurisdiction and applicable regimes.
- Sami's personal SEMA and CFPOA exposure in the dual role.
- Whether FP or NEXORA needs a TPRA VAS licence.
- Status of the 2007 Informatics Act vs the 2018/2020 cybercrime law.
- Lawful-intercept and data-retention duties.
- Payment route and USD use.
- EAR and ECL classification.
- Arbitration enforceability in Sudan.
- Re-screening of the current Zain Sudan management with identifiers.

### Unverified / not done
- Current Zain Sudan CEO and board.
- TPRA regulation texts.
- TPRA relocation.
- CBoS cloud rules.
- Azure/Meta terms.
- List updates after Oct 23–25, 2026.
- FP's legal identity.
