# DRAFT — NOT LEGALLY APPROVED / FOR QUALIFIED COUNSEL REVIEW
## Preliminary Sanctions & Export-Control Issue-Spotting Memo — Al Salam Bank Sudan (مصرف السلام السودان)
Prepared by: NEXORA Legal Counsel Desk (AI legal-ops assistant; **not a lawyer**). Research only, not legal advice.
Date: Oct 25, 2026 (America/Edmonton). Ref: LIAISON-ALSALAM-20261025.
Proposed work: free website concept → possibly CRM, Arabic/English AI assistant (web + WhatsApp), digital onboarding, ticketing, integrations.
Labels: VPA = VERIFIED_PRIMARY_AUTHORITY; RLI = REASONED_LEGAL_INTERPRETATION; UNV = UNVERIFIED; RLC = REQUIRES_LICENSED_COUNSEL.

---
## 0. Bottom line
**NO-GO for now (HOLD; do not start even the free concept).** Screening found a **potential name match between a listed board member and a person designated by the US, Canada, the UK and the EU as a Hamas financier.** Identity is NOT confirmed. Until sanctions counsel clears it, any engagement, including free work (which is "providing property/services"), carries **CRITICAL** risk. If the match is cleared, the realistic outcome is at most **GO-WITH-CONDITIONS**, and the payment route and US-nexus problems remain HIGH.

## 1. Potential list match — CRITICAL
| Item | Detail | Label |
|---|---|---|
| Bank board list (English page) | "Mr. Abd Elbasit Hamza Al Hassan — Board Member" at https://www.alsalam-bank.net/New%20folder/Directors.aspx.html (accessed Oct 25, 2026; the page is undated) | VPA (that the page says this) |
| Designated person | **KHAIR, Abdelbasit Hamza Elhassan Mohamed** (a.k.a. "HAMZA, Abdelbasit"; "HAMZA, Abd al-Basit"), DOB Aug 28, 1955, POB Marawi, Sudan. Described by OFAC as a "Sudan-based Hamas financier who has managed numerous companies in Hamas's investment portfolio", with "historic ties to al-Qa'ida and Usama bin Laden-linked companies in Sudan" | VPA |
| OFAC | SDN (SDGT, E.O. 13224) since Oct 18, 2023, uid 45675. Press release: https://home.treasury.gov/news/press-releases/jy1816. Linked SDNs: Zawaya Group for Development and Investment Co. Ltd., Al Zawaya Group … S.L. (Spain), Larrycom for Investment Ltd (Oct 27, 2023, https://home.treasury.gov/news/press-releases/jy1845). Found in the SDN.CSV downloaded Oct 25, 2026 from sanctionslistservice.ofac.treas.gov | VPA |
| Canada | Listed in the consolidated SEMA list (the "Hamas Terrorist Attacks" regulations), Part 1 item 16, listed Jun 24, 2024. Arabic: عبد الباسط حمزة الحسن محمد خير. Source: the sema-lmes.xml file, downloaded Oct 25, 2026 | VPA |
| UK | The Counter-Terrorism (International Sanctions) (EU Exit) Regs 2019, Group ID 16202 (CTI0053): asset freeze, plus director disqualification from Apr 9, 2025. Designated Nov 14, 2023. Source: UK Sanctions List CSV, report date Oct 16, 2026 | VPA |
| EU | Hamas/PIJ regime (code HAM), listed Jan 19, 2024, Reg. 2024/386. Source: EU FSF consolidated CSV, file date Oct 23, 2026 | VPA |
| Same person? | Same given names "Abdelbasit/Abd Elbasit" + "Hamza" + "Elhassan/Al Hassan", Sudanese, businessman profile. The bank's page gives no DOB or ID, and its Arabic board page (https://mobile.alsalam-bank.net/Directors.aspx.html) **does not list him**, so the English page may be stale. **Identity is NOT established.** | UNV / RLC |

Consequences if he is the same person: a designated individual on the board does **not** by itself make the bank blocked. The OFAC 50% rule is about ownership, not board seats; Canadian, UK and EU "control" tests look at real influence (see §3). But **any dealing that benefits him** is prohibited (SEMA s.3-type prohibitions; E.O. 13224), banks will almost certainly refuse the payments, and reputational and terrorist-financing exposure is severe. A secondary-sanctions risk flag is on his SDN entry (E.O. 13224 §1(b) as amended by E.O. 13886). **RLC.**

Other screening (bank name in English and Arabic, "Al Salam", the other board members, the GM Eltayeb Ali Ibrahim, the board secretary, the shareholders Makkah Investment Consultancy and Rashed Al Rashed & Sons, Central Bank of Sudan, and the Almiza/Leader Capital debtors): **no other hits** on OFAC SDN + non-SDN (CONS), Canada SEMA consolidated, UN consolidated (generated 2026-10-24 23:00 UTC, i.e. Oct 24, 5:00 PM MDT), UK list (Oct 16, 2026) or EU FSF (Oct 23, 2026). One OFAC SDGT entry, "HAMAD, Abdelbasit Alhaj Alhassan Haj" (DOB 1979, uid 15649), is a weaker partial name match that the DOB/patronymic make unlikely to be the board member. Still, **list it for counsel.** Method: keyword/regex screening of the official bulk files on Oct 25, 2026. That is not fuzzy matching with transliteration variants, so false negatives are possible. **UNV.**

Not done: the interactive tools (sanctionssearch.ofac.treas.gov, the EU Sanctions Map, the GAC search page) were not used; I screened against the official bulk downloads instead. Beneficial owners behind the shareholders and the ~86.5% public free float could not be identified.

## 2. Entity profile (public info)
- Incorporated Khartoum Dec 28, 2004 (registration 23335). Operating since May 2005. Listed on the Dubai Financial Market (ALSALAMSUDAN) since Jun 4, 2008. DFM profile: https://www.dfm.ae/the-exchange/market-information/company/ALSALAMSUDAN/profile (accessed Oct 25, 2026). The DFM still shows a Khartoum head office and a **different board** (chair Abdulrahman Ahmed Abdullah Sinan): inconsistent sources. **UNV.**
- Bank website board (Oct 25, 2026): chair HE Mohammed bin Omeir Bin Yousef; members Sultan Abdulaziz Alsadoon, Saud Mamoun Al Burair, Abd Elbasit Hamza Al Hassan, Dr Abdullah Saad Salem Al Khanbashi, Dr Mohammed Ali Khamis Al Hosani, Abdulrahman Ahmad Abdullah Senan, Abbas Al Bakheet Musa Mudawi; secretary Dr Mohey Alsona Babiker Altayeb.
- Shareholders (third-party aggregator, not primary): Makkah Investment Consultancy 8.33%, Rashed Al Rashed & Sons 5.19%, rest public. https://simplywall.st/stocks/ae/banks/dfm-alsalamsudan/al-salam-bank-sudan-shares/ownership (accessed Oct 25, 2026). **UNV.**
- FY2025 annual report (via https://financialfilings.com/filings/al-salam-sudan/annual-report/2026/44958129/, accessed Oct 25, 2026): GM Eltayeb Ali Ibrahim. It shows debts and litigation involving Hussein Mohamed Salim Almiza / Leader Capital and a holding in "Al Salam Bank/Algeria". **The Al Salam Bank Bahrain / group link was not verified.**
- HQ in Port Sudan: per the brief only; not confirmed from primary sources. **UNV.**

## 3. Sanctions frameworks
**Canada (VPA unless noted)**
- Special Economic Measures (Sudan) Regulations, SOR/2024-61 (current to 2026-09-30, last amended 2025-03-05): https://laws-lois.justice.gc.ca/eng/regulations/SOR-2024-61/FullText.html. Section 3 prohibits persons in Canada and Canadians abroad from dealing in property of listed persons, facilitating such transactions, providing financial or related services, and making goods or other property available to them. s.2(f) lists entities "owned — or held or controlled, directly or indirectly" by listed persons. Schedule: 11 individuals (incl. **Abdel Fattah al-Burhan**, Hemedti, Ali Karti, Salah Gosh, Mirghani Idris) and 7 entities (incl. Defence Industries System, Sudan Master Technology, Zadna, **Al Khaleej Bank**). **Al Salam Bank and the Central Bank of Sudan are not listed.**
- United Nations Sudan Regulations (UN Act): arms embargo, technical/financial assistance tied to arms, and an asset freeze on 1591-Committee designees. Overview: https://www.international.gc.ca/world-monde/international_relations-relations_internationales/sanctions/sudan-soudan.aspx?lang=eng (accessed Oct 25, 2026). The regulation text was not separately fetched. **UNV as to the current text.**
- Canada's ownership/control approach: listing covers entities "owned, held or controlled, directly or indirectly", plus property-level "held or controlled". There is no fixed % test; GAC guidance points to a fact-based control analysis. **RLI.**
- Area Control List (SOR/81-543, current to 2026-09-30) lists **only the DPRK**. Sudan is not on it. https://laws-lois.justice.gc.ca/eng/regulations/SOR-81-543/FullText.html. **VPA.**

**United States**
- E.O. 14098 (May 4, 2023, 88 FR 29529) is the current Sudan-related program (tag SUDAN-EO14098): 57 SDN entries in the Oct 25, 2026 file. Examples: Burhan (Jan 16, 2025), Hemedti (Jan 7, 2025), Defense Industries System, **Alkhaleej Bank Co Ltd**, finance minister **Gebreil Ibrahim (address Port Sudan, Sep 12, 2025)**, Al-Baraa Bin Malik Brigade, and **Ports Engineering Company Ltd (Port Sudan, state-owned, Jun 26, 2026)**. Sources: https://home.treasury.gov/news/press-releases/jy2789 ; https://ofac.treasury.gov/recent-actions/20250912 ; https://ofac.treasury.gov/recent-actions/20260626 (all accessed Oct 25, 2026). **VPA.**
- The 1997/2006 country-wide Sudan embargo (31 CFR Part 538) was revoked effective Oct 12, 2017. The SST designation was rescinded Dec 14, 2020, and the EAR was conformed Jan 19, 2021 (https://www.federalregister.gov/documents/2021/01/19/2020-29037/...). The exact dates are from memory and secondary sources. **RLI.** Partly UNV.
- 50% rule: entities owned 50% or more, directly or indirectly, individually or in the aggregate, by blocked persons are blocked. It is quoted in jy1816 above. **VPA.** Control without 50% ownership does not trigger automatic blocking but is a risk factor. **RLI.**
- **Central Bank of Sudan: not on the SDN or CONS lists** (Oct 25, 2026 file). **VPA (for the file screened).**

**UK / EU / UN**
- UK: Sudan (Sanctions) (EU Exit) Regulations 2020, SI 2020/753: https://www.legislation.gov.uk/uksi/2020/753. Ownership/control test: >50% of shares or votes, or de facto control (SAMLA regulations, reg. 7-type provisions; per OFSI guidance). **RLI (not re-read today).**
- EU: the Sudan regime is **Council Regulation (EU) 2023/2147** and Decision (CFSP) 2023/2135, **not 2023/2686**. Consolidated: https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX%3A02023R2147-20250718. EU file code SDNZ (98 rows). EU test: ownership >50% or control per Council Best Practices. **RLI.** The EU Sanctions Map was not used.
- UN 1591 list: 13 "SDi" entries in the UN consolidated XML (Oct 24, 2026). No hit for the bank or the CBoS. **VPA.**

**Port Sudan authority risk — HIGH (RLI).** The de facto government in Port Sudan is SAF-led. Its leader (Burhan) is listed by the US and Canada, and its finance minister (Gibril Ibrahim) by the US. The CBoS is not listed, but a regulated bank interacts constantly with these authorities. Any deliverable or payment that benefits a listed official, or a state-owned entity owned 50%+ by listed persons, must be excluded. **RLC.**

## 4. Can NEXORA provide services and be paid?
- Canada: no country-wide embargo on Sudan. Non-arms services to a non-listed bank are not per se prohibited. **RLI.** They are prohibited to the extent they benefit a listed person (possibly the board member above). **RLC.**
- US nexus — HIGH: E.O. 13224 and E.O. 14098 prohibit US persons and US-transiting transactions involving blocked persons' interests. Risk points: USD clearing through US correspondents; US-person staff or contractors; US cloud and AI vendors acting as US persons. **RLI.**
- Payments — HIGH: Sudanese banks have very limited correspondent access. Gulf intermediaries (UAE) add layering and red flags. Canadian banks are likely to refuse or freeze inbound Sudan-origin wires, especially with a terrorism-financing name match. **RLI.** FINTRAC: NEXORA is not a reporting entity as a software vendor (**RLI**), but its bank is and will run EDD.
- FATF: **Sudan is not on the Black List (DPRK, Iran, Myanmar) or the Grey List** as of the June 19, 2026 statements: https://www.fatf-gafi.org/en/countries/black-and-grey-lists.html (accessed Oct 25, 2026). South Sudan is grey-listed (a different country). Any October 2026 plenary outcome was **not checked**. **VPA (June) / UNV (October).**

## 5. Export controls
- Canada ECL: AI chatbots and web/CRM software using standard encryption usually fall under the Cat. 5 Part 2 cryptography note (mass-market/ancillary) exclusions. Item-by-item classification was not done. **RLC/UNV.** Not on the ACL (see above).
- US EAR: Sudan is in **Country Group B and one D column (appears to be D:5, arms embargo), not E:1/E:2** (eCFR Supp. 1 to Part 740, accessed Oct 25, 2026: https://www.ecfr.gov/current/title-15/subtitle-B/chapter-VII/subchapter-C/part-740/appendix-Supplement%20No.%201%20to%20Part%20740). Removed from E:1 Jan 2021. Mass-market 5D992 software to a bank in Sudan is generally NLR absent end-user/end-use red flags. **RLI.** Points not analysed: de minimis (if NEXORA bundles US-origin code), deemed re-export to foreign-national staff, and any 2025–26 AI model-weight rules. **UNV/RLC.**
- Providers (accessed Oct 25, 2026):
  - OpenAI: **Sudan IS listed** as a supported country (https://developers.openai.com/api/docs/supported-countries). **VPA.**
  - Stripe: Sudan does not appear on https://stripe.com/global as a supported business country. **VPA (page text).** Not usable for the client.
  - AWS: the Service Terms §9.9 put sanctions and export compliance on the customer (https://aws.amazon.com/service-terms/). The page names no Sudan ban.
  - Google Cloud: the Service Terms reference export controls (incl. ECCN 5A002) and "embargoed United States countries and regions" (https://cloud.google.com/terms/service-terms). Sudan is not currently a US-embargoed country. **RLI.**
  - Azure/Microsoft and Meta/WhatsApp Business: no Sudan-specific language was retrieved; the pages were not machine-readable. **UNV.** All providers bar use by or for SDNs. **RLI.**

## 6. Data residency
I found no CBoS outsourcing, cloud or data-localization regulation, and no Sudanese data-protection statute, in the time available. **UNV.** Assume local-law constraints exist and have Sudanese counsel confirm them. **RLC.**

## 7. Recommendation and conditions
**NO-GO now.** Re-assess as GO-WITH-CONDITIONS only after:
1. Canadian and US sanctions counsel resolve the Abdelbasit Hamza match (DOB/ID from the bank, current board register, CBoS fit-and-proper filings).
2. Full KYC and beneficial ownership, down to 10% and controllers, incl. Makkah Investment Consultancy and Rashed Al Rashed & Sons; reconcile the DFM board with the website board.
3. Rescreen all parties with fuzzy and Arabic matching; document it.
4. Pre-clear the payment route with NEXORA's Canadian bank in writing: no USD and no US correspondent unless counsel approves; no third-party or Gulf intermediary payers.
5. A no-US-nexus design (US vendors and staff reviewed) and vendor ToS sign-off.
6. Contract terms: sanctions/AML reps and warranties; termination on listing; no benefit to listed persons; export compliance; audit rights.
7. CEO written approval.

Points needing licensed counsel: identity of the match and whether the bank is "controlled"; facilitation exposure for free work; E.O. 13224 secondary-sanctions risk; EAR classification; Sudanese banking-secrecy and outsourcing rules.

---
# ADDENDUM — Oct 25, 2026 (04:13–04:30 MDT): verification of the reported board departure
**DRAFT — NOT LEGALLY APPROVED / FOR QUALIFIED COUNSEL REVIEW.** Research only; not legal advice.

CEO statement (Sami Suliman, relayed): "Abd Elbasit Hamza Al Hassan" is no longer with the bank. Before checking: **UNV**.

## A. Public-source findings (all accessed Oct 25, 2026)
1. **He was on the board in the past. VPA (that the source says so).** Argaam, Mar 26, 2011 (https://www.argaam.com/ar/article/articledetail/id/815864) and the bank's own news page (https://mobile.alsalam-bank.net/News12.aspx.html) report the general assembly re-electing the board. Members named include **عبد الباسط حمزة الحسن** and also **كمال حمزة الحسن (Kamal Hamza Al Hassan)**, with Hussein Mohamed Salim Al-Miza as vice-chair. Al-Miza is now the bank's litigation debtor per the FY2025 annual report. Kamal's shared patronymic suggests a possible family tie. **UNV, flag for counsel.**
2. **He is not on the current board. VPA (filing text) / RLI (inference).**
   - The resolutions of the 16th general assembly (Mar 10, 2026) elected the 2026–2029 board: Sinan, Al Hosani, Al Khanbashi, Madawi, Al Wahibi, Elawadi, and Ahmed Hamad Al Khalifa Mohammed. He is not among them. Source: the DFM filing mirrored at https://financialfilings.com/filings/al-salam-sudan/declaration-of-voting-results-voting-rights-announcements/2026/44957371/. The original DFM record was not opened. The DFM board list matches it.
   - The nomination call (Nov 24, 2025; HQ Port Sudan) is at https://financialfilings.com/filings/al-salam-sudan/regulatory-filings/2025/44954311/ and in Argaam 1861374.
   - The bank's Arabic board page omits him. The English page is stale: it still lists him and chair Bin Yousef, who is not on the 2026 board either.
3. **Exit or resignation date: NOT found. UNV.** No resignation notice, DFM disclosure or news item was located. That same Mar 10, 2026 assembly approved the board report for **2019–2025** and **discharged the board from liability for 2019–2025**. That leaves open the possibility that he sat on the board, or was part of the board discharged, during the period that included his designation (Oct 18, 2023). **This matters and is unresolved.** The DFM general-meetings page lists nothing after May 8, 2019 (https://www.dfm.ae/the-exchange/market-information/company/ALSALAMSUDAN/general-meetings). I did not check the Khartoum Stock Exchange (no reachable source found) or annual reports for 2012–2024.
4. **Shareholdings by him, Zawaya or Larrycom, past or present: NOT determinable. UNV.** The FY2025 annual report mirror could not be text-searched; the page returned about 4 KB. The only ownership data is from an aggregator: Makkah Investment Consultancy 8.33% and Rashed Al Rashed & Sons 5.19%, with the rest free float. No public source links Zawaya or Larrycom to the bank. The free float of about 86.5% is opaque.
5. **The designation entries do not name Al Salam Bank. VPA.** Identifiers for counsel's identity match:
   - **OFAC SDN uid 45675** (SDGT, Oct 18, 2023): KHAIR, Abdelbasit Hamza Elhassan Mohamed; a.k.a. HAMZA, Abdelbasit / HAMZA, Abd al-Basit. DOB **28 Aug 1955**, POB Marawi; **National ID 101 0015 9792 (Sudan)**; address Africa Street, Khartoum 12290; "Linked To: HAMAS".
     - Linked SDNs: Zawaya Group for Development and Investment Co., Ltd. (uid 45900; Africa Rd, Takamul, Khartoum); Al Zawaya Group … S.L. (uid 45901; Valencia, Spain; NIF B72884711); Larrycom for Investment Ltd (uid 45902; Khartoum).
     - Source: SDN/ALT/ADD CSV, sanctionslistservice.ofac.treas.gov, downloaded Oct 25, 2026; press releases jy1816 and jy1845.
   - **Canada**: SEMA Hamas Terrorist Attacks regulations, Sched. Part 1 item 16, listed Jun 24, 2024. Name in Arabic: عبد الباسط حمزة الحسن محمد خير. DOB 1955-08-28. No ID number given. No affiliated entities found in the Canadian list.
   - **UK**: Counter-Terrorism (International Sanctions) Regs 2019, Group ID 16202 (CTI0053). Designated **Nov 14, 2023**: asset freeze, travel ban, targeted arms embargo, and director disqualification (imposed Apr 9, 2025). **DOB shown as 23/08/1955: discrepancy vs 28 Aug in the other lists.** Zawaya and Larrycom are not on the UK list. Source: UK Sanctions List CSV, report date Oct 16, 2026.
   - **EU**: Hamas/PIJ regime (HAM), Reg. 2024/386, listed Jan 19, 2024. DOB 1955-08-28. The ID is recorded as passport "10100159792". **EU calls it a passport and OFAC calls it a national ID; same digits.** The EU also lists Zawaya (incl. Hungarian Zrt. entities), Al Zawaya S.L. and Larrycom (incl. Larrycom Befektetési Zrt.) under HAM, Reg. 2024/1838 (Jun 28, 2024). Source: EU FSF CSV, Oct 23, 2026.
   - **The bank's site gives no DOB or ID for its former director, so the identity match is still UNV / RLC.** Same Arabic name core "عبد الباسط حمزة الحسن", Sudanese, a businessman profile, and a historic al-Qa'ida/bin Laden-company link per OFAC: **likelihood of a match: HIGH (RLI).**

## B. Updated assessment
**Departure: partly corroborated.** He is absent from the board elected Mar 10, 2026 (VPA as to the filing). His exit date, any role in 2019–2025, and his past or present shareholding are UNVERIFIED.

(i) **Free website concept: HOLD → GO-WITH-CONDITIONS is possible, but not yet.** Risk drops from CRITICAL to **HIGH**. These must be met first:
- (a) written confirmation from the bank of his exit date and that he, his relatives (e.g. Kamal Hamza Al Hassan), Zawaya, Larrycom or any nominee hold **no shares, board, nominee, management or signing role**, with board and shareholder registers;
- (b) enhanced screening of the full board, senior management, the Sharia board and shareholders over 10%, with fuzzy and Arabic matching, documented;
- (c) Canadian sanctions counsel sign-off. A free concept is still "property/services", but it no longer benefits a listed person if (a) holds. **RLI / RLC.**

(ii) **Outreach email (drafting only; no sending): GO-WITH-CONDITIONS for drafting.** Drafting creates no dealing (**RLI**). Before any send:
- the conditions in (i)(a)–(c);
- CEO approval;
- CASL compliance for a commercial electronic message. CASL applies to CEMs sent from Canada. The bank is a non-Canadian recipient, but NEXORA's sending from Canada still triggers it. **RLI.** So the email needs consent (no implied-consent basis is known; a conspicuous publication of the address plus relevance to the recipient's role may apply, **RLC**), sender identification, a mailing address and an unsubscribe mechanism.
- The email must not be sent to any address tied to the former director or to listed persons.

**Conditions that still apply in every scenario:**
- enhanced screening and rescreening at each milestone;
- the payment route pre-cleared with NEXORA's Canadian bank: no USD or US correspondent without counsel approval; no third-party or Gulf payers;
- a no-US-nexus design (US persons, vendors, OpenAI and other US cloud providers reviewed for facilitation);
- a sanctions/AML/CTF clause with reps, a covenant of no benefit to listed persons, termination on listing and audit rights;
- Canadian and US counsel sign-off.

**Residual risk: HIGH (reputational and banking de-risking).**
- The bank had a designated Hamas financier on its board, at least from 2011, and possibly into 2019–2025. Banks running EDD will likely surface this. Expect account or wire refusals.
- If any ongoing link exists (shares, nominee, relatives, Zawaya/Larrycom), the exposure becomes **CRITICAL**. It would cover Criminal Code terrorist-property and facilitation offences (ss. 83.03–83.04) and SEMA dealing prohibitions in Canada, and E.O. 13224 with secondary-sanctions risk in the US. **REQUIRES_LICENSED_COUNSEL.**

## CEO decision record (2026-10-25, ~04:14 MT) — DRAFT — NOT LEGALLY APPROVED
- Sami Suliman (CEO) confirmed from his own knowledge, without documents, that the matched director is no longer with Al Salam Bank Sudan. He decided to proceed with the free concept outreach. Source: relayed by NEXORA Liaison. Label: CEO_APPROVED_COMMERCIAL_POSITION.
- Public sources are consistent with this: he is absent from the board elected on Mar 10, 2026. No exit date was found, and he may have remained a director after his designation on Oct 18, 2023 (UNVERIFIED). Shareholdings are unknown.
- This desk's advice is unchanged: HOLD until the bank confirms his exit and non-ownership in writing, full screening is done and counsel signs off. The CEO has accepted the risk of proceeding.
- Before any pricing, contract, paid work or data access: written confirmation from the bank, full screening, an approved payment route, a design with no US connection, a sanctions clause in the contract, and counsel sign-off. Outreach email: CASL consent basis, sender ID and unsubscribe required, plus CEO approval of the final text.
