# Contracting Structure Guidance — Calgary SMB Prospects (GROK-REVENUE-20261014-18)

**DRAFT — NOT LEGALLY APPROVED. Advisory only. Not legal advice.**
Prepared by NEXORA Legal Counsel Desk, an AI legal research and drafting assistant for NEXORA Technologies Corp. (Calgary). This is not a licensed lawyer and this document is not a legal opinion. Date: 2026-10-14.

Classification key: VERIFIED_PRIMARY_AUTHORITY / REASONED_LEGAL_INTERPRETATION / CEO_APPROVED_COMMERCIAL_POSITION / UNVERIFIED / REQUIRES_LICENSED_COUNSEL.
No statute sections in this note have been verified. Statutes are named only, and any section reference is marked UNVERIFIED.

---

## 0. Status of NEXORA templates
- **No NEXORA contract template is approved.** The MSA, SOW, NDA, SaaS Agreement, SUMMITOS Pilot Agreement, DPA, Maintenance Agreement, Change Order and Acceptance Certificate are all **DRAFT_ONLY**.
- **SUMMITOS pilot:** the terms are still DRAFT. Open items in draft_agreement_v2.md (liability, privacy, taxes, IP, data return, cancellation, refunds) and the Schedule A v3.1 pre-signing technical conditions are **unresolved. No SUMMITOS pilot should be signed or offered as signable yet.** The CEO_APPROVED_COMMERCIAL_POSITION items are: a 90-day pilot, no automatic conversion, CAD $299 / $599 / custom pricing, and onboarding fees approved separately.
- This guidance is generic. It contains no prospect-specific contracts, legal conclusions or agreements.

---

## 1. Decision table: engagement type → structure → key clauses to watch

| Engagement type | Recommended structure (REASONED_LEGAL_INTERPRETATION) | Key clauses to watch |
|---|---|---|
| One-off marketing or brochure website, no repeat work expected | **Standalone website SOW** (with short-form general terms attached or incorporated) | Scope and page/feature list; content supply by client; acceptance criteria and deemed acceptance; change orders; IP assignment on full payment vs NEXORA pre-existing tools/themes licence; third-party themes/plugins/fonts licensing; domain/hosting ownership (in client's name); payment milestones; warranty period [UNKNOWN]; liability cap [UNKNOWN]; privacy policy/cookie content is client's responsibility unless scoped |
| Website with forms collecting customer personal information (quote requests, booking) | Website SOW **plus a DPA or data-processing clause** if NEXORA hosts/receives the form data | Where submissions are stored; who can access; retention; breach notice; subprocessors (form/email tools) |
| Automation / integration (CRM, accounting, scheduling, email workflows, AI workflow) | **Automation/integration SOW**, ideally under an MSA; **DPA** if personal information flows through NEXORA-controlled systems | Client authorization to access its third-party accounts; dependency on vendor terms/APIs (vendor changes outside NEXORA control); credentials handling; data mapping and test data; acceptance testing; error/edge-case responsibility; AI output limits and human review; ongoing monitoring is out of scope unless a maintenance agreement exists |
| SaaS pilot (SUMMITOS) | **SUMMITOS Controlled Paid Pilot Agreement + Schedule A + DPA** — **NOT SIGNABLE YET** | Accurate feature descriptions (Schedule A v3.1); no SLA/uptime/profitability claims; no live supplier integrations promised; seat limits PROPOSED only; 90-day end with no auto-conversion; data export/return [UNKNOWN]; tenant data separation (hardcoded-tenant issue must be fixed first); billing termination at 90 days not automated |
| Repeat or multi-phase work (e.g., website then CRM then automation; or phased rollout) | **MSA + successive SOWs** (+ Change Orders, Acceptance Certificates) | Order of precedence (SOW vs MSA); master IP, confidentiality, liability, privacy terms; SOW-specific scope/fees/acceptance; term and termination of MSA vs individual SOWs; survival clauses |
| Any engagement where NEXORA collects, stores, hosts, accesses or processes personal information on the client's behalf | **DPA** (schedule to MSA/SOW/SaaS terms) | Roles (client as organization in control; NEXORA as service provider) — REQUIRES_LICENSED_COUNSEL; instructions-only processing; security safeguards; subprocessors and notice; data location/residency [UNKNOWN]; breach notification to client; return/deletion at end; audit/cooperation; staff confidentiality |
| Hosting and ongoing maintenance after delivery | **Separate Hosting & Maintenance Agreement** (or maintenance SOW under MSA) | Recurring fees; what maintenance includes/excludes; response targets only if CEO-approved (no invented SLAs); backups [UNKNOWN]; security updates; term, renewal and cancellation notice [UNKNOWN]; transition-out assistance |
| Pre-sales discussions involving client confidential info (drawings, pricing, owner lists) | **Mutual NDA** before receiving materials | Definition of confidential information; permitted use; return/destruction; term; personal information excluded from casual sharing |

---

## 2. Prospect-type matrix

All "likely engagements" are **ASSUMPTIONS** to be confirmed in discovery, not facts about any prospect.

| Prospect type | Likely engagement (ASSUMPTION) | Suggested structure | Data and legal considerations |
|---|---|---|---|
| **Metal fabrication shop** | Website refresh; quote-request workflow; CRM/ERP or estimating integration; possibly SUMMITOS-like ERP interest (pilot not signable) | NDA early → website SOW and/or integration SOW; MSA + SOWs if phased | Customer drawings, CAD files and specifications (client and its customers' IP — confidentiality and limited-use clauses; NEXORA claims no rights); supplier pricing and cost data (commercially sensitive confidential information); limited personal information (customer contacts — PIPA applies to private-sector organizations in Alberta, sections UNVERIFIED); third-party ERP/accounting vendor terms govern API access |
| **Electrical contractor** | Website; job intake/scheduling automation; CRM and field-service tool integration | Website SOW; integration SOW + DPA; MSA if multi-phase | Customer names, addresses, site access details (sometimes occupancy/security info); possibly employee data (scheduling, certifications) and safety records — treat as sensitive, minimize access, confirm whether in scope; permits/inspection documents; integration with field-service platforms requires client account authorization and depends on vendor terms; Alberta occupational health and safety record obligations remain the client's (statute named only: Occupational Health and Safety Act (Alberta), sections UNVERIFIED) |
| **Property / condo management firm** | Owner/resident portal or website; maintenance-request automation; communications workflows; CRM integration | MSA + SOWs + **DPA (strongly indicated)**; NDA before discovery | Owner and resident personal information (names, units, contact details, possibly financial/arrears, access fobs, incident reports); condominium corporation records — Condominium Property Act (Alberta) and its regulation contain record-keeping and access provisions (sections UNVERIFIED); PIPA (Alberta) applies (sections UNVERIFIED); question of who is the controlling organization (management firm vs condo corporation/board) — REQUIRES_LICENSED_COUNSEL; owner mass emails may raise CASL questions (see §3); data residency expectations [UNKNOWN] |
| **Renovation company** | Website with lead/quote forms; CRM and estimating integration; marketing email set-up | Website SOW; automation SOW (+ DPA if NEXORA holds lead data); MSA if repeat | Homeowner names, addresses, photos of homes/interiors (personal information, potentially revealing); project quotes and pricing (confidential); before/after photos for marketing need client to have customer consent (client responsibility, flagged); consumer-facing contract rules for the client's own customers (e.g., Consumer Protection Act (Alberta) — sections UNVERIFIED) are the client's issue, not within NEXORA scope unless asked; CASL relevant for marketing emails |
| **Moving company** | Website with booking/quote forms; inventory/quote automation; scheduling and CRM integration | Website SOW; automation SOW + DPA; MSA if phased | Customer origin/destination addresses, move dates (security-sensitive: empty-home timing), household inventories and valuations, sometimes photos/videos of contents; payment data — NEXORA should not store card data (use payment processor; PCI obligations [UNKNOWN] / for Risk & Compliance); third-party booking/CRM vendor terms; retention and deletion after move |

---

## 3. Cross-cutting points

1. **IP ownership.** Suggested approach (REASONED_LEGAL_INTERPRETATION, not approved): the client owns custom deliverables made specifically for it once paid in full. NEXORA keeps its pre-existing tools, libraries, frameworks, templates, know-how and general improvements, and grants the client a licence to use what is embedded in the deliverables [licence scope: UNKNOWN — CEO/COUNSEL TO CONFIRM]. Third-party and open-source components stay under their own licences. Moral rights waivers and assignment formalities under the Copyright Act (sections UNVERIFIED): REQUIRES_LICENSED_COUNSEL. Client materials such as logos, drawings and data remain the client's.
2. **Acceptance and change orders.** Every SOW should have objective acceptance criteria, a fixed review window, and a defined deemed-acceptance rule [period: UNKNOWN]. It should also say how defects are handled. Any change in scope, timeline or fees should go through a written Change Order signed before work starts. Sign-off is recorded on a Project Acceptance Certificate (DRAFT_ONLY).
3. **Hosting and maintenance are separate.** Keep build work (one-time) apart from hosting and maintenance (recurring), each with its own term, fees, scope and exit terms. Don't put uptime or response commitments in unless the CEO has approved them and they can be delivered. Domains and key third-party accounts should, where practical, be registered in the client's name.
4. **CASL.** If NEXORA sets up or runs the client's marketing email, the client is generally the sender responsible for consent, identification and unsubscribe content, and NEXORA acts as a service provider (REASONED_LEGAL_INTERPRETATION; CASL sections UNVERIFIED). Contracts should make the client responsible for consent records and list content, and NEXORA should not send without client instructions. Detailed CASL analysis, including whether condo-owner notices count as commercial electronic messages, goes to **Risk & Compliance**.
5. **AI features and limits.** Describe AI features accurately. Outputs can be wrong and need human review before the client relies on them. Make no accuracy, savings or profitability guarantees. Disclose any third-party AI provider as a subprocessor if personal information is sent to it [provider list and data location: UNKNOWN]. Do not use client data to train models unless the client agrees [policy: UNKNOWN — CEO to decide]. Label automated customer-facing outputs as AI where appropriate.
6. **Third-party integrations.** The client must authorize NEXORA's access to its accounts, preferably with delegated or least-privilege credentials rather than shared passwords. Vendor terms and API changes are outside NEXORA's control, and the contract should say so. The client remains bound by its own vendor agreements.
7. **Privacy baseline.** Collect only the personal information needed. Use test or synthetic data where possible. Keep access logs. Return or delete data at the end. Breach notification duties under PIPA and/or PIPEDA (sections UNVERIFIED) need the roles settled in a DPA.
8. **Liability, indemnities, warranties.** No cap amount, indemnity scope or warranty period has been approved. All are [UNKNOWN — CEO/COUNSEL TO CONFIRM].
9. **Taxes.** GST treatment and invoicing details need accountant verification.

---

## 4. Open questions, Risk & Compliance items, counsel items

### Open questions / UNKNOWNs (CEO)
1. Which template set will be used first (MSA + SOW vs standalone SOW short-form terms)?
2. Liability cap model, indemnities and warranty period.
3. IP model: assignment on payment vs licence; scope of NEXORA pre-existing tool licence.
4. Deemed-acceptance period and number of revision rounds.
5. Hosting/maintenance pricing, scope, term and cancellation notice; whether any response targets are offered.
6. Hosting location / data residency and current subprocessor list (incl. AI providers).
7. Policy on using client data for AI/model improvement.
8. Payment terms (deposit, milestones, late fees).
9. Whether NEXORA will ever operate client marketing email sends directly.
10. Whether condo-management work will be offered before a DPA template is reviewed.

### Items for Risk & Compliance
- CASL roles and consent records when NEXORA configures client email marketing, and whether condo owner/resident communications are commercial electronic messages.
- PIPA vs PIPEDA applicability for each prospect type, and cross-border transfer notice if hosting or AI providers are outside Canada.
- Handling of sensitive data: employee and safety records, condo arrears and incident records, mover schedules and inventories.
- Payment card handling and PCI scope for booking flows.
- Website claims and marketing accuracy (Competition Act concerns previously raised for SUMMITOS pages).
- Security baseline for credential handling in integrations.

### REQUIRES_LICENSED_COUNSEL
- Controller/service-provider roles under PIPA/PIPEDA, especially for condo firms vs condo corporations.
- Condominium Property Act (Alberta) records obligations and how they affect a vendor holding condo records (sections UNVERIFIED).
- Enforceability of limitation-of-liability and exclusion clauses under Alberta law.
- Copyright assignment, moral rights waivers and open-source licence obligations.
- Electronic signature and contract formation approach (Electronic Transactions Act (Alberta), sections UNVERIFIED).
- Final approval of every template (all DRAFT_ONLY) and of SUMMITOS pilot terms before any signature.

---
**DRAFT — NOT LEGALLY APPROVED. Advisory only. Not legal advice. No citations in this document are verified; statutes are named only.**
