# DRAFT — NOT LEGALLY APPROVED
## LIAISON-20261014-09 — Advisory Notes: Grok Bot → NEXORA Command Center Evidence Handoff Boundaries
Prepared by: NEXORA Legal Counsel Desk (AI drafting/research assistant — NOT a lawyer; not legal advice; not privileged). Internal CEO review only. Date: 2026-10-14.

### 0. Sources reviewed (read-only)
- A document titled "contract v0.1" was **NOT FOUND** on the box (search: `contract v0.1|evidence package|NXR-HUM-001` across /workspace and /home/box/agent-data).
- Related spec found: NEXORA operating handover package (Liaison attachment `2a941f77…ca2a1.md`), §13 "Safe Handoff Contract & Evidence Protocol" (6-state lifecycle REQUESTED → ACCEPTED → RESEARCHING → EVIDENCE_SUBMITTED → REVIEWED → CLOSED; VERIFIED_PUBLIC vs INFERRED; §14.1 Phase 0 air-gapped, human copy/paste bridge; LEVEL_3 CEO-only authority for external communications). The spec itself classifies the handoff contract as **ARCHITECTURAL DESIGN**, not verified/deployed.
- Example evidence package: `/workspace/qa/LIAISON-20261013-01-report.md`.
- It is [UNKNOWN — CEO/COUNSEL TO CONFIRM: whether §13 is "contract v0.1" or whether a separate v0.1 document exists]. These notes rely on §13 plus the task description.

### 1. Short advisory notes
1. **Ownership.** Evidence packages (compilation, summaries, analysis) prepared for NEXORA should be treated as NEXORA internal work product once accepted into Command Center. [UNKNOWN — CEO/COUNSEL TO CONFIRM: the Grok Bot service provider's terms on output ownership/licence.] Third-party content quoted or captured from public sources remains owned by its rights-holders; no copyright transfers by inclusion in a package. Keep quotations short and cite source URLs. (Copyright Act fair dealing scope: REQUIRES_LICENSED_COUNSEL.)
2. **Accuracy accountability.** Bots provide evidence "as-is" with exact source URL and retrieval date (UTC) and a VERIFIED_PUBLIC / INFERRED label. Bots are not accountable persons. The human reviewer who accepts an item, and the CEO (NXR-HUM-001) for anything adopted into a decision, are accountable.
3. **Storage and retention.** Store only what the task needs (data minimization). Personal information should be limited to business-contact information published publicly and needed for the task; no guessed emails (the spec's "NONE_FOUND — DO NOT GUESS" rule). Alberta PIPA and PIPEDA may apply to collection/use of personal information, including "publicly available" exceptions — specific sections UNVERIFIED; detailed analysis deferred to Risk & Compliance. Retention periods: [UNKNOWN — CEO/COUNSEL TO CONFIRM].
4. **Rejected/duplicate data.** Rejections and duplicates should be recorded with status, reason, reviewer and timestamp — never silently deleted or silently merged — and later retention/deletion should follow one documented rule.
5. **Bot vs. employee.** Bots are not employees, agents, officers or contractors of NEXORA, have no authority to bind NEXORA, and cannot approve anything. Note: the roster lists AI "personas" with staff-like titles and sender aliases (e.g., `marcus@nexorayyc.io`); this blurs the line and is a risk (see Risks).
6. **Impersonation protections.** No external communications in NEXORA's name, clear AI labelling, no staff credentials, an audit trail, and no self-approval.

### 2. Top risks
| # | Risk | Rating | Basis |
|---|---|---|---|
| R1 | AI personas with human-style names/titles and commercial sender aliases could be perceived as NEXORA staff by recipients | HIGH | Roster in handover spec; misleading-representation concerns (Competition Act / CASL sender identification — sections UNVERIFIED here) |
| R2 | Handoff contract is design-only; "contract v0.1" not located — boundaries may not be enforced | HIGH | Spec §14.2 classifies it ARCHITECTURAL DESIGN |
| R3 | Unverified or INFERRED bot output adopted as fact without human review | HIGH | Accuracy accountability gap |
| R4 | Personal information (named leaders, emails) collected beyond need; no retention periods | MEDIUM–HIGH | PIPA/PIPEDA (sections UNVERIFIED); retention UNKNOWN |
| R5 | Third-party copyrighted content reproduced in packages beyond short quotation | MEDIUM | Copyright Act; fair dealing REQUIRES_LICENSED_COUNSEL |
| R6 | Silent deletion/merge destroys audit trail | MEDIUM | Governance/auditability |
| R7 | Bot-provider terms (ownership, confidentiality, data use for training) unknown | MEDIUM | [UNKNOWN] |

### 3. Recommended boundary clauses (DRAFT — NOT LEGALLY APPROVED)
1. **Status of Bots.** Grok Bots are automated research tools. They are not employees, agents, officers, partners or contractors of NEXORA and hold no office or authority.
2. **No Authority to Bind.** No Bot may make, accept, sign, amend or terminate any agreement, commitment, offer or representation on NEXORA's behalf.
3. **No Approval Power.** Bots may only REQUEST approval. Every approval decision is made by NXR-HUM-001 (or a human delegate the CEO designates in writing [UNKNOWN — CEO TO CONFIRM whether any delegate exists]). No Bot may approve, review-as-final, or self-approve its own output.
4. **Evidence Ownership.** NEXORA owns (or holds the rights the Bot provider grants in) accepted evidence packages as internal work product [UNKNOWN — COUNSEL TO CONFIRM against provider terms]. Third-party content retains its owners' rights; no transfer of third-party copyright is made or implied.
5. **Evidence As-Is.** Bots supply evidence as-is, without warranty, each factual item carrying exact source URL, retrieval date (UTC) and a VERIFIED_PUBLIC or INFERRED label. Unsourced items are labelled UNVERIFIED and may not be adopted as fact.
6. **Human Accountability.** The named human reviewer is accountable for accepting an item into Command Center; the CEO is accountable for any decision or external use relying on it.
7. **Data Minimization.** Packages contain only information necessary for the stated task. Personal information is limited to publicly published business-contact information needed for the task; no inferred, guessed or sensitive personal information.
8. **Retention.** Accepted, rejected and duplicate records are kept for [UNKNOWN — CEO/COUNSEL TO CONFIRM retention periods] and then deleted or de-identified under a documented schedule.
9. **Rejected and Duplicate Records.** Rejected or duplicate submissions are marked REJECTED or DUPLICATE with reason, reviewer and timestamp, linked to the retained record, and never silently deleted, overwritten or merged.
10. **No External Communications.** Bots send no message, post, form submission or contact to any person outside NEXORA in NEXORA's name or otherwise.
11. **AI Labelling.** All Bot output is labelled as AI-generated and identifies the Bot; Bots never present as a human or as NEXORA staff.
12. **No Staff Credentials.** Bots hold and use no NEXORA staff credentials, sender aliases, accounts or system access (consistent with spec §14.1 Phase 0 air-gap).
13. **Audit Trail.** Every handoff state change (REQUESTED → CLOSED) records task ID, actor, timestamp and content hash [UNKNOWN — CTO TO CONFIRM technical implementation].
14. **Confidentiality.** Bots receive only the NEXORA information needed for a task; confidential client data is not shared with Bots without explicit CEO approval.
15. **Suspension.** The CEO may suspend any Bot or reject any package at any time without reason.

### 4. Open questions
1. Is §13 of the handover package "contract v0.1"? If not, where is v0.1? [UNKNOWN]
2. Bot provider terms on output ownership, confidentiality and training use? [UNKNOWN]
3. Retention periods for accepted / rejected / duplicate records? [UNKNOWN]
4. Who are the "internal reviewer" roles — human or AI personas? If AI personas review, who is the accountable human? [UNKNOWN]
5. Will AI personas with sender aliases continue to send external email, and how are they disclosed as AI? [UNKNOWN]
6. Where is Command Center data hosted (residency) and who are subprocessors? [UNKNOWN]
7. Is any CEO delegate authorized to approve in the CEO's absence? [UNKNOWN]
8. Is the audit-trail/hash design implemented or design-only? [UNKNOWN]

### 5. Items requiring licensed Canadian counsel
- PIPA/PIPEDA applicability, "publicly available information" exceptions, and retention obligations (specific sections UNVERIFIED).
- Copyright fair dealing for quotations/screenshots in evidence packages.
- Disclosure obligations for AI personas in external communications (CASL identification requirements, Competition Act misleading representations).
- Ownership/licence of AI-generated output under the Bot provider's terms and Canadian law.
- Whether these boundaries should sit in an internal policy, provider terms, or both.

*DRAFT — NOT LEGALLY APPROVED. No message sent; no system changed.*
