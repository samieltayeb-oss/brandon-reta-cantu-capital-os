# DRAFT — NOT LEGALLY APPROVED
# NEXORA Contract Architecture — Offer Ladder (NEXORA-GTM-20261014-26)

Prepared by: NEXORA Legal Counsel Desk (AI drafting assistant — **not a licensed lawyer**). **Not legal advice.** No agreement is created, signed or sent. Builds on `GROK-REVENUE-20261014-18/contracting_guidance.md`, `GROK-REVENUE-20261014-24/commercial_structures.md` and the SUMMITOS files in `LIAISON-20261014-06/` (SUMMITOS Pilot Agreement v2 / Schedule A v3.1 remain **draft and NOT signable**).

Conventions: all structures are REASONED_LEGAL_INTERPRETATION. All percentages, amounts, periods and caps are **[UNKNOWN — CEO TO CONFIRM]**. Statutes named only; **all section references UNVERIFIED**. All templates are **DRAFT_ONLY**. Tax treatment (GST, invoicing, deposits) → **accountant**.

---

## 0. Ladder summary table

| Rung | Offer type | Core document set | Payment checkpoints (structure only) | IP default (proposed) | Liability cap option | Renewal |
|---|---|---|---|---|---|---|
| 1 | Entry fixed-fee: website, discovery, assessment | Proposal + short-form SOW (standalone T&Cs) + NDA; DPA if PI accessed | Deposit on signing [UNKNOWN %] → balance on delivery/acceptance [UNKNOWN %] | Client owns deliverables on full payment; NEXORA retains pre-existing tools; licence to client | Fees paid under the SOW (option) [amount UNKNOWN] | None — ends on completion |
| 2 | Mid-tier automation | Proposal + SOW under MSA (or SOW + standalone T&Cs for first job) + NDA; DPA if PI flows | Deposit → milestone(s) (e.g. design sign-off, build complete) → acceptance [all % UNKNOWN] | Custom config/code to client on payment, or licence (CEO/counsel); NEXORA tools licensed | Fees paid in prior [UNKNOWN] months or per-SOW fees | None; follow-on via new SOW |
| 3 | High-value connected systems / custom software | MSA + detailed SOW(s) + NDA + DPA (likely) + Change Order + Acceptance Certificate; possibly security schedule | Deposit → phased milestones tied to acceptance gates → final acceptance; optional holdback [all UNKNOWN] | Negotiated split: assignment of client-specific code vs licence; NEXORA platform/libraries retained | Multiple of fees / fixed sum / super-cap for data & confidentiality [all UNKNOWN] | None; support/maintenance via Rung 4 |
| 4 | Recurring managed services / retainers | MSA + Services Schedule/SOW (scope, hours, response targets only if verified) + DPA (if PI) | Monthly/periodic in advance or arrears [UNKNOWN]; overage handling [UNKNOWN] | Work product per MSA; NEXORA tools licensed for term only | Fees paid in prior [UNKNOWN] months | Fixed term; **no automatic renewal unless CEO approves** |
| — | SUMMITOS pilot (reference only) | Pilot Agreement v2 + Schedule A v3.1 — **NOT signable** | Monthly in advance after acceptance & authorised onboarding (CEO direction); onboarding quoted separately | Per draft (unresolved) | UNRESOLVED | 90-day pilot, **no automatic conversion** (CEO direction) |
| — | Referral / partner | Referral Agreement + NDA | Commission [UNKNOWN] on [trigger UNKNOWN] | N/A; trademark use licence if any | Mutual, [UNKNOWN] | Term [UNKNOWN]; no auto-renewal unless CEO approves |

---

## 1. Cross-ladder principles (apply to every rung)

- **Order of documents:** NDA before confidential discovery → proposal (non-binding unless stated) → SOW (and MSA from Rung 2/3 upward or for repeat clients) → DPA before any NEXORA access to client personal information.
- **Precedence clause:** DPA > MSA > SOW > Change Order > Proposal (proposed; counsel to confirm), except where a SOW expressly overrides an MSA term for that SOW only.
- **No invented commitments:** no SLAs, uptime, response times, warranty periods or export deadlines unless verified and CEO-approved.
- **Third-party dependencies:** client-owned vendor accounts (e.g. CRM, Rent Manager, configurators, Stripe) — client warrants authority; NEXORA not liable for vendor changes/outages (counsel to word).
- **Change orders:** written, signed by both, stating scope, schedule and fee impact; no work on unpriced changes unless CEO approves.
- **Acceptance:** defined criteria in the SOW; acceptance window [UNKNOWN days]; deemed acceptance on silence or production use — **option only, counsel decision**; defect re-test loop.
- **AI disclosure:** where AI tools are used in delivery, disclose per NEXORA policy (Risk & Compliance); no bot represented as NEXORA staff.

---

## 2. Rung 1 — Entry fixed-fee (website, discovery, assessment)

- **Document set:** Proposal + short-form fixed-fee SOW with embedded standard terms (or MSA if client is likely repeat); mutual NDA before discovery; DPA only if NEXORA will access personal information (e.g. website contact forms hosted by NEXORA, client records reviewed in assessment).
- **Payment checkpoints:** (a) deposit on signing [UNKNOWN %], non-refundable status [CEO/counsel decision]; (b) optional mid-point (e.g. design/draft report delivered) [UNKNOWN]; (c) balance on acceptance/delivery [UNKNOWN %]. Work starts only after deposit received (proposed). Late payment interest [UNKNOWN; Interest Act — sections UNVERIFIED → counsel].
- **Change orders:** fixed scope list; anything outside = change order or new SOW; number of revision rounds [UNKNOWN].
- **IP:** client owns final deliverables (site content/design, report) on full payment; NEXORA retains templates, frameworks, methods, code libraries, know-how; non-exclusive licence to client for embedded NEXORA materials; third-party assets (themes, fonts, stock, plugins) under their own licences; client warrants rights to supplied content. Moral rights waiver → counsel (Copyright Act, sections UNVERIFIED).
- **Warranty:** deliverables materially conform to SOW at delivery; [warranty period UNKNOWN — none stated]; assessments are advisory, no guarantee of outcomes; disclaimer of implied warranties → counsel (Sale of Goods Act (Alberta) applicability UNVERIFIED).
- **Liability cap (options):** (A) fees paid under the SOW; (B) fixed sum [UNKNOWN]; exclusion of indirect/consequential loss; carve-outs [counsel].
- **Termination:** for convenience by client with payment for work done [notice UNKNOWN]; for breach with cure period [UNKNOWN]; NEXORA may suspend for non-payment.
- **Renewal:** none; engagement ends on completion. Hosting/maintenance for websites moves to Rung 4 by separate agreement.
- **Acceptance:** checklist-based; acceptance window [UNKNOWN]; launch = acceptance (option, counsel).

## 3. Rung 2 — Mid-tier automation

- **Document set:** Proposal + automation SOW under MSA (preferred) or standalone SOW+T&Cs; NDA; DPA if personal information flows through NEXORA-controlled tools/accounts; credentials/access schedule.
- **Payment checkpoints:** deposit [UNKNOWN %] → milestone 1 (process map/design sign-off) [UNKNOWN] → milestone 2 (build complete, UAT start) [UNKNOWN] → final on acceptance [UNKNOWN]. Each milestone invoice tied to a written sign-off.
- **Change orders:** required for new workflows, integrations, data sources or vendor-plan changes; impact on milestones stated.
- **IP:** client-specific workflow configuration/scripts to client on payment (or licence — CEO/counsel); NEXORA reusable automation components and tooling retained and licensed; no transfer of third-party platform rights.
- **Warranty:** conformance to agreed spec at acceptance; [defect-correction period UNKNOWN]; no warranty of third-party platforms, API stability or AI output accuracy.
- **Liability cap (options):** fees paid under the SOW, or fees paid in prior [UNKNOWN] months; possible separate cap for data/confidentiality breach [counsel].
- **Termination:** convenience (pay for work + committed costs), breach with cure, insolvency; data return/deletion on exit [timing UNKNOWN — no deadline promised].
- **Renewal:** none; ongoing support only via Rung 4.
- **Acceptance:** UAT against written test cases with client data owner; acceptance certificate.

## 4. Rung 3 — High-value connected systems / custom software

- **Document set:** MSA + detailed SOW(s) + mutual NDA + DPA (likely) + Change Order form + Acceptance Certificate; optionally security/hosting schedule, subprocessor list, and SaaS terms if NEXORA hosts (any SUMMITOS component remains NOT signable).
- **Payment checkpoints:** deposit/mobilisation [UNKNOWN] → phased milestones each tied to an acceptance gate (discovery/architecture, phase builds, integration testing, go-live) → final acceptance; optional holdback released after [UNKNOWN] period [CEO/counsel]. Paid discovery SOW first is strongly recommended.
- **Change orders:** formal change control; estimates in writing; schedule relief for client delays/dependencies.
- **IP:** negotiated: (A) assign client-specific custom code on full payment with NEXORA retaining platform, libraries, know-how and a licence back; or (B) NEXORA retains ownership, grants perpetual/term licence. Open-source compliance disclosure. Escrow [UNKNOWN / CEO]. All → counsel.
- **Warranty:** material conformance with specification for [period UNKNOWN]; remedy = repair/re-perform (option); exclusions for client modifications, third-party systems.
- **Liability cap (options):** (A) multiple [UNKNOWN] of fees paid/payable; (B) fixed sum [UNKNOWN]; (C) higher "super-cap" for data protection/confidentiality [UNKNOWN]; insurance alignment [UNKNOWN — confirm NEXORA E&O/cyber coverage]. Enforceability (Tercon) → counsel.
- **Termination:** convenience with wind-down fees [UNKNOWN]; breach; transition assistance [scope UNKNOWN, no deadline committed]; data return/deletion.
- **Renewal:** none for project; maintenance via Rung 4.
- **Acceptance:** staged acceptance per milestone; final acceptance criteria; deemed acceptance option → counsel.

## 5. Rung 4 — Recurring managed services / retainers

- **Document set:** MSA + Services Schedule (scope, included hours or services, exclusions) + DPA if PI; support process description (response targets **only if operationally verified and CEO-approved**).
- **Payment checkpoints:** periodic fee in advance [frequency/amount UNKNOWN]; unused-hours treatment (rollover/forfeit) [CEO]; overage rate [UNKNOWN]; price-change notice [UNKNOWN].
- **Change orders:** scope changes via updated schedule; out-of-scope project work → new SOW (Rung 2/3).
- **IP:** per MSA; NEXORA tools licensed only during term.
- **Warranty:** services performed with reasonable skill and care (wording → counsel); no uptime guarantee unless verified.
- **Liability cap:** fees paid in prior [UNKNOWN] months (option).
- **Termination:** fixed initial term [UNKNOWN] then termination on [UNKNOWN] notice; exit assistance and data return [no deadline].
- **Renewal:** **No automatic renewal unless the CEO approves.** Default: term ends; continuation requires written renewal. If CEO approves auto-renewal, Risk & Compliance/counsel to review notice and consumer-protection requirements (Consumer Protection Act (Alberta) applicability to business clients UNVERIFIED). Consistent with the SUMMITOS **no-automatic-conversion** position (90-day pilot ends unless customer affirmatively opts in).
- **Acceptance:** periodic service reports [format UNKNOWN]; disputes raised within [UNKNOWN] days.

## 6. SUMMITOS position (reference)
SUMMITOS Pilot Agreement v2 and Schedule A v3.1 are **NOT signable**: open liability, privacy, tax, IP, data return terms; unenforced tier/seat limits; mock supplier integrations; incomplete onboarding; no automatic 90-day Stripe termination; hardcoded tenant in email ingestion. Prospects may only be offered a **paid discovery SOW** (Rung 1). CEO directions retained: 90-day pilot, no auto-conversion, monthly in advance after acceptance, separately approved onboarding.

## 7. Referral / partner agreement
- **Structure:** written Referral Agreement + NDA; partner is independent contractor, no authority to bind NEXORA or make product claims beyond approved materials.
- **Commission:** [UNKNOWN — CEO TO CONFIRM] rate/flat fee, trigger (signed SOW vs payment received), duration, clawback on refund/non-payment — all UNKNOWN.
- **Disclosure:** partner discloses compensated relationship to referred clients (proposed); NEXORA discloses where relevant.
- **Marketing:** partner marketing (email/text) must comply with CASL → **Risk & Compliance** (sections UNVERIFIED); approved messaging only; Competition Act deceptive marketing exposure → counsel.
- **Exclusivity:** **none unless CEO approves.**
- **Competition / anti-kickback:** referral fees to persons owing duties to the client (e.g. condo boards, property managers, procurement staff), and secret-commission concerns (Criminal Code, Competition Act — sections UNVERIFIED) → **counsel**.
- **Data:** sharing of lead personal information requires consent basis (PIPA (Alberta)/PIPEDA — UNVERIFIED) → Risk & Compliance.
- **Term/termination:** [UNKNOWN]; no auto-renewal unless CEO approves; post-termination commission tail [UNKNOWN].

---

## 8. Templates to build (all DRAFT_ONLY)
1. Proposal template (non-binding wording) — DRAFT_ONLY
2. Short-form fixed-fee SOW + standard terms (Rung 1) — DRAFT_ONLY
3. Master Services Agreement — DRAFT_ONLY
4. Automation SOW template (Rung 2) — DRAFT_ONLY
5. Custom software / connected-systems SOW with milestone & acceptance schedule (Rung 3) — DRAFT_ONLY
6. Managed Services / Retainer Schedule (Rung 4) — DRAFT_ONLY
7. Mutual NDA — DRAFT_ONLY
8. Data Processing Agreement (+ subprocessor list) — DRAFT_ONLY
9. Change Order form — DRAFT_ONLY
10. Acceptance Certificate — DRAFT_ONLY
11. Referral / Partner Agreement — DRAFT_ONLY
12. Paid Discovery SOW for SUMMITOS prospects — DRAFT_ONLY

## 9. REQUIRES_LICENSED_COUNSEL
- Liability cap structures, exclusions, carve-outs and enforceability (Tercon line).
- IP assignment vs licence, moral rights waivers (Copyright Act — UNVERIFIED), open-source and escrow.
- Warranty disclaimers and implied terms (Sale of Goods Act (Alberta) — UNVERIFIED).
- Deemed acceptance, non-refundable deposits, late interest (Interest Act — UNVERIFIED).
- Document precedence, governing law (Alberta proposed; EGM-type out-of-province clients).
- Auto-renewal if ever approved; consumer-protection applicability.
- Referral fees: secret commissions, anti-kickback, Competition Act (all UNVERIFIED).
- DPA roles, cross-border transfer, breach notification terms.

## 10. Risk & Compliance items
- CASL for NEXORA and partner marketing (UNVERIFIED).
- PIPA (Alberta)/PIPEDA applicability per engagement; DPA triggers; lead-data sharing (UNVERIFIED).
- Marketing claims vs verified capability (SUMMITOS public claims; Competition Act — UNVERIFIED).
- AI-use disclosure; bots not presented as staff.
- SUMMITOS hardcoded-tenant ingestion issue — possible incident assessment.
- Insurance coverage alignment with caps.

## 11. Accountant items
- GST/HST on deposits, milestones, retainers and commissions (Excise Tax Act — UNVERIFIED); revenue recognition of deposits; cross-province supply.

## 12. CEO decisions
1. Deposit and milestone percentages per rung.
2. Deposit refundability.
3. Default IP model (assignment vs licence) per rung.
4. Liability cap option and amounts per rung.
5. Warranty/defect-correction periods (if any).
6. Acceptance window; whether to propose deemed acceptance.
7. Rung 4 term, notice, unused-hours and price-change rules; whether any auto-renewal is ever allowed (default: no).
8. Referral commission model, trigger, tail, clawback; any exclusivity (default: none).
9. When MSA (vs standalone SOW) becomes mandatory.
10. Template build priority and counsel budget.

*DRAFT — NOT LEGALLY APPROVED. Not legal advice.*
