**DRAFT — FOR COUNSEL REVIEW, NOT FOR SIGNATURE. NOT LEGAL ADVICE.**

# Addition to GTM-32 SOW Notes — Paid Discovery & Design (Option A)
Task NEXORA-GTM-20261014-33 · AI drafting assistant (not a lawyer). GTM-31 and GTM-32 files unchanged.

**Position.** (1) free call → (2) free NEXORA Business Growth & Technology Assessment → **(3) paid Discovery & Design** → (4) scoped proposal → implementation SOW/MSA. Steps 3 and 4 are optional and each needs a separate written agreement.

| Topic | Proposed position | GTM-31 SOW clause it maps to |
|---|---|---|
| Title | "Statement of Work — Discovery & Design" (replaces "Connected Operations Assessment & Implementation Proposal" in the GTM-32 notes) | Title |
| Background | Follows the free assessment report; free terms do not carry over | §2 |
| Scope | Deeper discovery, requirements, solution design, implementation plan, estimate; no production changes; system access only as agreed [BRACKET — CEO/COUNSEL] | §3 |
| Personal information | Option A: no-PI assumption with pause-and-DPA trigger; Option B: DPA signed before start [BRACKET — CEO/COUNSEL]. DPA is NOT YET DRAFTED | §3, §6 |
| Deliverables | Design document and a scoped proposal (with estimate); **both non-binding until a separate SOW or MSA is signed**; no guarantees; figures state assumptions and evidence (interim s.74.01 rule, GTM-29 §9) | §4 |
| Exclusions | Implementation, configuration, integration, development, migration, support — separate agreement only | §5 |
| Fee | [CAD amount — PENDING CEO PRICE APPROVAL]; no numbers | §8 |
| Deposit | [BRACKET — amount/% and refundability — CEO; enforceability — COUNSEL] | §8 |
| Credit toward implementation | [BRACKET — CEO DECISION] | §8 |
| Taxes | [GST/other — ACCOUNTANT TO CONFIRM] | §8 |
| Acceptance | Applies to design document and scoped proposal; window/deemed acceptance [BRACKET — CEO/COUNSEL]; acceptance ≠ acceptance of any implementation offer | §9 |
| IP in design documents | [BRACKET — licence vs ownership; moral rights — CEO/COUNSEL]; NEXORA retains methods/templates/tools | §10 |
| Confidentiality | GTM-31 mutual NDA required, signed before or with this SOW; drop "if no NDA" fallback | §11 |
| Warranties / liability | Unchanged brackets — COUNSEL; CEO/COUNSEL | §12–13 |
| Termination | [BRACKET — rights, notice, fees/deposit on termination — CEO/COUNSEL] | §14 |
| No auto-conversion | Does not renew or convert into implementation or any subscription; no obligation to purchase | §15 |
| Governing law | [Alberta — PLACEHOLDER PENDING COUNSEL]; venue [BRACKET — COUNSEL]; EGM Drywall offices UNKNOWN | §16 |

**Recommendation.** Yes — the GTM-31 assessment SOW should become the Discovery & Design SOW. Its 16-clause structure already covers every topic above; the changes are retitling and rewriting §2–§4, §8 (credit wording), §9, §10 and §11, plus the PI option choice. This avoids a parallel template (one fewer document for counsel). A separate scoped-proposal/implementation SOW or MSA is still needed for step 4 onward (NOT YET DRAFTED per GTM-29).

**Counsel questions.**
1. Wording so the estimate and scoped proposal are not treated as an offer.
2. PI Option A vs B, and DPA minimums (PIPA (Alberta) / PIPEDA — sections UNVERIFIED).
3. IP model for design documents (licence vs assignment; moral rights).
4. Deposit refundability and credit-toward-implementation drafting on termination.
5. Standalone SOW vs NDA merger, and whether general terms or an MSA should apply.
6. Adequacy of the no-auto-conversion and no-obligation wording.

**DRAFT — FOR COUNSEL REVIEW, NOT FOR SIGNATURE. NOT LEGAL ADVICE.**
