**DRAFT — FOR COUNSEL REVIEW, NOT FOR SIGNATURE. NOT LEGAL ADVICE.**

# NEXORA Business Growth & Technology Assessment — Terms (Proposed, v2)
Task NEXORA-GTM-20261014-33 · Prepared by an AI drafting assistant (not a lawyer). Derived from GTM-32 free_assessment_terms_draft.md (unchanged).

> **Internal note — CEO_APPROVED_COMMERCIAL_POSITION:** no charge; no payment card collected; no obligation; no auto-enrolment into any paid service; no exclusivity; NEXORA effort capped at 90 minutes; report ≤ 2 pages; up to 2 workflows; offered at NEXORA's discretion with capacity of at most 5 per month; every report CEO-approved before release (prospect-facing text says "reviewed and approved by NEXORA"). Remove this box before any prospect use.

These terms apply between NEXORA Technologies Corp., Calgary, Alberta ("NEXORA") and [PROSPECT LEGAL NAME] ("Prospect" or "you"); each a "Party". This is step 2 of NEXORA's sequence: (1) free 20-minute introductory call (no contract); (2) this free assessment; (3) optional paid Discovery & Design; (4) optional scoped proposal. Steps 3 and 4 happen only if both Parties separately agree in a written agreement (with a mutual NDA). **Effective Date:** [DATE]. You accept them by [BRACKET — acceptance mechanism, e.g. email reply "I agree" or click-through — CEO/COUNSEL].

**1. What it is.** The NEXORA Business Growth & Technology Assessment is a short, free review of up to **2 workflows**, using public information and what you choose to describe to us. NEXORA spends **no more than 90 minutes** of internal effort and gives you a written report of **2 pages or less**, which is reviewed and approved by NEXORA before release. It does **not** include system access, review of sensitive records, architecture or solution design, code, integrations, prototypes, or ROI, savings or other performance figures. Not available to clinics or health-service providers at this time.

**2. No fee, no obligation.** The assessment is free and no payment card is collected. You will not be enrolled automatically in any paid service. Neither of us is obliged to do anything further. You are not committing to buy anything, and there is no exclusivity — you may work with anyone. The assessment is offered at NEXORA's discretion and capacity is limited, so NEXORA may decline or schedule requests [BRACKET — whether to state the monthly limit to prospects — CEO; internal limit: 5 per month].

**3. Not advice; no reliance; no guarantee.** The report contains general observations only. It is not professional, legal, financial, accounting or tax advice. Do not rely on it for decisions without getting independent advice. NEXORA does not guarantee any result, savings, efficiency gain or return on investment, and the report will not contain ROI, savings or performance figures [consistent with NEXORA's interim Competition Act s.74.01 claims rule — GTM-29 §9; application to one-to-one communications pending counsel].

**4. What to share.** Please share only non-sensitive business information. Do **not** share personal information (e.g. customer, employee, tenant or owner details), health information, passwords or credentials, or confidential records. If any is shared, NEXORA will not use it, will delete it [BRACKET — timing — CEO/COUNSEL], will tell you, and the affected item will be dropped from scope. No data processing agreement is used at this stage; any work that needs personal information belongs to the paid Discovery & Design stage and requires a signed DPA first. NEXORA keeps information you share for [BRACKET — retention period and any backup/legal-record exception — CEO/COUNSEL], then deletes it.

**5. Confidentiality.** Each of us will keep the other's non-public information confidential and use it only for this assessment. This does not apply to information that is or becomes public through no fault of the recipient, was lawfully known to it already, is lawfully received from a third party without a confidentiality obligation, or is independently developed. These obligations last [BRACKET — SURVIVAL PERIOD — COUNSEL]. If you want to share confidential material, that falls outside this free assessment; we would first sign NEXORA's mutual non-disclosure agreement [internal ref: GTM-31 draft].

**6. Liability.** The assessment is provided as-is and at no charge. To the extent permitted by law, NEXORA's liability is [BRACKET — excluded / limited to [amount] — CEO/COUNSEL; enforceability to be confirmed by counsel].

**7. The report.** NEXORA keeps all rights in its methods, know-how and templates. You may use the report internally in your business (a non-exclusive right of use; ownership is not transferred) [BRACKET — confirm licence wording — CEO/COUNSEL]. This differs intentionally from the paid Discovery & Design stage, where licence vs ownership is open. NEXORA will not publish your name or details without your written consent. Internal use of anonymized or aggregate learnings: [BRACKET — CEO DECISION].

**8. Next steps (optional).** After the report, NEXORA may offer paid Discovery & Design, followed by a scoped proposal. Both are optional and each requires a separate written agreement; nothing in these terms commits either Party to them.

**9. Stopping.** Either of us may stop the assessment at any time, by notice (email is enough), without cost.

**10. Communications.** Agreeing to these terms is **not** consent to receive marketing messages. Any consent for follow-up marketing is requested separately [Risk & Compliance to define the CASL consent process].

**11. Governing law.** [Alberta — PLACEHOLDER PENDING COUNSEL]; [BRACKET — courts/venue — COUNSEL]. **No deposit or credit** applies to this free assessment.

---

## Questions for counsel
1. Is a full exclusion (or a cap) of liability for a free service enforceable in Alberta, and what carve-outs (e.g. negligence, confidentiality breach) are needed? Exclude vs. limit?
2. Does email-reply or click acceptance form a binding agreement here; what record should NEXORA keep (Alberta *Electronic Transactions Act* — section UNVERIFIED)?
3. Is the light mutual confidentiality clause (§5) adequate for a free, non-sensitive assessment, or is a short definition/exclusions/survival period needed?
4. CASL (*Canada's Anti-Spam Legislation*, sections UNVERIFIED): confirm that consent to these terms and marketing consent must be kept separate, and whether the assessment-related emails themselves are commercial electronic messages.
5. Is the "will not use and will delete" handling of inadvertently shared personal information sufficient under PIPA (Alberta) / PIPEDA (sections UNVERIFIED), or are notices/records needed?
6. Confirm the light clause's exclusions and survival track the NDA's §2 and §11, and that §5 needs no return/destruction mechanics beyond §4.
7. Governing law/venue where a prospect is outside Calgary or Alberta (e.g. EGM Drywall, HQ Edmonton; other offices UNKNOWN).
8. Does the no-reliance disclaimer adequately address negligent-misstatement risk for free advice?
9. Does the "at NEXORA's discretion / may decline" wording need any care in how requests are declined?

## CEO decisions
1. Acceptance mechanism (email reply vs. click).
2. Deletion timing for inadvertently shared sensitive information.
3. Retention period for shared information and the report.
4. Liability: full exclusion or cap (and amount, if a cap).
5. Internal use of anonymized/aggregate learnings — yes/no.
6. Confirm Alberta as governing law (with counsel).
7. Confirm the free report is licence-only (internal use).
8. Capacity wording: state "5 per month" to prospects, or keep it internal.
9. Confirm that ending the free assessment carries no follow-up obligation and that CASL consent is requested separately.

**DRAFT — FOR COUNSEL REVIEW, NOT FOR SIGNATURE. NOT LEGAL ADVICE.**
