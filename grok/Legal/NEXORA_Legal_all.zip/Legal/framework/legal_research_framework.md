> **DRAFT — NOT LEGALLY APPROVED. AI-generated research structure, not legal advice.** Prepared by NEXORA Legal Counsel Desk (AI legal research and drafting assistant, not a licensed lawyer). Status: DRAFT_ONLY. Created 2026-10-14.

# NEXORA Legal Research Knowledge Framework (Canadian Technology Law)

## 0. How to use this library
- Every entry records: authority, URL, issuing body, jurisdiction, binding status, date verified, key sections, applicability to NEXORA, exceptions/conflicting authority, confidence.
- "Verified" means the text was fetched from the official publisher on the date shown and the cited section was read. It does **not** mean NEXORA has been advised that the provision applies; how it applies is REASONED_LEGAL_INTERPRETATION or REQUIRES_LICENSED_COUNSEL.
- Alberta King's Printer PDFs are office consolidations. Counsel should confirm against official versions before relying on them.
- Re-verify each entry before reuse. Statutes noted "current to 2026-09-21" may change.
- Verification method: Justice Laws section pages fetched directly (WebFetch). Alberta King's Printer PDFs can't be read with WebFetch (binary). They were downloaded from kings-printer.alberta.ca by the Risk & Compliance Analyst on 2026-10-14 (`/workspace/legal/LIAISON-20261014-06/sources/`) and the cited sections were re-read from those copies by this desk.

### Conclusion labels (use on every conclusion)
| Label | Meaning |
|---|---|
| VERIFIED_PRIMARY_AUTHORITY | Statute or case text read at the official source on the date recorded |
| REASONED_LEGAL_INTERPRETATION | AI reasoning applying verified text to NEXORA facts. Not advice. |
| CEO_APPROVED_COMMERCIAL_POSITION | A commercial term the CEO has approved on the record (e.g., pricing) |
| UNVERIFIED | Not confirmed at a primary source, or the source couldn't be fetched |
| REQUIRES_LICENSED_COUNSEL | Needs a qualified Alberta/Canadian lawyer before anyone relies on it |

### Source status labels for documents
VERIFIED_LEGAL_SOURCE · CEO_APPROVED_COMMERCIAL_POLICY · LAWYER_REVIEWED (none to date) · DRAFT_ONLY · UNVERIFIED

---

## 1. CANADIAN LAW (federal and Alberta)

| # | Topic | Authority | URL | Jurisdiction | Binding status | Verified | Key sections | Applicability to NEXORA | Exceptions / conflicts | Confidence |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | Alberta contract law: general | Common law of contract (formation, interpretation, good faith, unconscionability). No single statute. | — | Alberta (common law, subject to SCC) | Binding case law | NOT YET RESEARCHED | — | Underpins every NEXORA agreement | No Alberta case has been verified in this library yet | UNVERIFIED |
| 2 | Exclusion/limitation clauses | *Tercon Contractors Ltd. v. British Columbia (Transportation and Highways)*, 2010 SCC 4, [2010] 1 SCR 69 (decided 2010-02-12, docket 32460) | https://decisions.scc-csc.ca/scc-csc/scc-csc/en/item/7843/index.do ; https://www.canlii.org/en/ca/scc/doc/2010/2010scc4/2010scc4.html | Canada (SCC; binds Alberta courts) | Binding case | 2026-10-14 (partial) | Case existence, citation and headnote issues confirmed: whether the exclusion clause applies, then whether to refuse enforcement for unconscionability or overriding public policy. Fundamental-breach doctrine retired. | Liability cap and exclusion of damages in the SUMMITOS Pilot §12 and every future MSA/SaaS | **Paragraph pin cites not verified.** The SCC full text was blocked (403) and the CanLII page returned empty to WebFetch. The test is taken from the official headnote/search index. | MEDIUM: citation verified; test wording REQUIRES pin-cite check |
| 3 | SaaS / software licensing: copyright | Copyright Act, RSC 1985, c C-42 | https://laws-lois.justice.gc.ca/eng/acts/C-42/section-13.html | Federal | Binding statute | 2026-10-14 | s.13(1) author is first owner; s.13(3) employer owns works made in the course of employment, absent contrary agreement; s.13(4) assignments and licences of an interest valid only in writing signed by the owner | Ownership of SUMMITOS code, contractor-built code, and customer-created formulas. Licence grants and assignments must be in signed writing. | s.13(3) covers employees, not independent contractors. Contractor IP needs a written assignment (REASONED_LEGAL_INTERPRETATION). | HIGH (text) |
| 4 | Moral rights waiver | Copyright Act s.14.1 | https://laws-lois.justice.gc.ca/eng/acts/C-42/section-14.1.html | Federal | Binding statute | 2026-10-14 | s.14.1(2) moral rights can't be assigned but can be waived; s.14.1(3) assignment ≠ waiver; s.14.1(4) a waiver for the owner/licensee may be invoked by persons it authorizes | Every deliverable-transfer clause (MSA/SOW) and contractor agreement needs an express waiver | Act current to 2026-09-21 | HIGH (text) |
| 5 | MSA / SOW structure | No statute. Contract law plus rows 2–4. | — | — | — | — | — | Order of precedence, change orders, acceptance | — | Template work only |
| 6 | Privacy: Alberta private sector | Personal Information Protection Act, SA 2003, c P-6.5 (PIPA) | https://kings-printer.alberta.ca/documents/Acts/P06P5.pdf | Alberta | Binding statute | 2026-10-14 (local copy, current as of 2025-09-01) | s.5(2) responsibility for contracted persons; s.6(2)–(3) policies for service providers outside Canada; s.13 notice; s.13.1 notice for service providers outside Canada; s.34 security; s.34.1 notice to the Commissioner (real risk of significant harm); s.35 retention | Customer-entered employee/GPS/payroll data in SUMMITOS. NEXORA's own customer/admin data. | Applies "subject to the regulations". The PIPA Regulation was NOT reviewed (UNVERIFIED). Owned by Risk & Compliance. | HIGH (text) / application REQUIRES_LICENSED_COUNSEL |
| 7 | Privacy: federal | Personal Information Protection and Electronic Documents Act, SC 2000, c 5 (PIPEDA) | https://laws-lois.justice.gc.ca/eng/acts/P-8.6/FullText.html | Federal | Binding statute | 2026-10-14 (via R&C; Act current to 2026-09-21) | Part 1: s.4(1) application; s.10.1 breach reporting; s.10.3 records; Sch.1 cl.4.1.3 (third-party processing). Part 2: electronic documents (federal-law requirements only). | Interprovincial or cross-border flows. Part 2 is mostly irrelevant to private contracts (REASONED_LEGAL_INTERPRETATION). | s.26(2)(b) "substantially similar" exemption for Alberta PIPA: REQUIRES_LICENSED_COUNSEL | HIGH (text) |
| 8 | Privacy guidance | OPC guidance; OIPC Alberta guidance | https://www.priv.gc.ca ; https://oipc.ab.ca | Federal / Alberta | Regulator guidance (non-binding) | Not fetched | — | Breach, cross-border and processor practice | — | UNVERIFIED |
| 9 | CASL | An Act to promote the efficiency… (CASL), SC 2010, c 23 | https://laws-lois.justice.gc.ca/eng/acts/E-1.6/FullText.html | Federal | Binding statute | 2026-10-14 (via R&C; current to 2026-09-21) | s.6(1)–(2) consent plus prescribed content; s.10(1) express consent request; s.10(9)–(10) implied consent; s.11 unsubscribe within 10 business days | SUMMITOS §14 marketing consent; customer SMS/email features | Electronic Commerce Protection Regulations NOT reviewed. CRTC "no pre-checked box" is guidance only. | HIGH (text) |
| 10 | CASL guidance | CRTC CASL FAQ | https://crtc.gc.ca/eng/com500/faq500.htm | Federal | Regulator guidance | via R&C 2026-10-14 | — | Consent mechanics | Non-binding | MEDIUM |
| 11 | Consumer vs business subscriptions | Consumer Protection Act, RSA 2000, c C-26.3 | https://kings-printer.alberta.ca/documents/Acts/C26P3.pdf | Alberta | Binding statute | 2026-10-14 (local copy, current as of 2026-09-01) | s.1(1)(b) "consumer" = individual; s.6(4)(t.1) continuing-services agreements: prominent full disclosure, express consent to renewals | Applies only if a pilot customer is an individual (e.g., a sole proprietor). The B2B default is outside it. | Application to sole proprietors: REQUIRES_LICENSED_COUNSEL | HIGH (text) |
| 12 | Internet sales | Internet Sales Contract Regulation, Alta Reg 81/2001 | https://kings-printer.alberta.ca/documents/Regs/2001_081.pdf | Alberta | Binding regulation | via R&C 2026-10-14 (current as of 2023-04-01) | ss.2, 4, 5, 6 | Self-serve Stripe checkout if consumers buy | Consumer-only | MEDIUM |
| 13 | Misleading representations | Competition Act, RSC 1985, c C-34 | https://laws-lois.justice.gc.ca/eng/acts/C-34/section-52.html ; https://laws-lois.justice.gc.ca/eng/acts/C-34/section-74.01.html | Federal | Binding statute | 2026-10-14 | s.52(1) criminal (knowingly/recklessly); s.52(4) general impression; s.74.01(1)(a) false/misleading in a material respect; (b) performance guarantee needs adequate and proper test; (c) materially misleading warranty/guarantee | Public SUMMITOS claims: profitability guarantee, SLA, multi-tenancy | Applies B2B and B2C. Remedies and penalties not reviewed. Act current to 2026-09-21, amended 2026-03-26. | HIGH (text) |
| 14 | Electronic contracting | Electronic Transactions Act, SA 2001, c E-5.5 | https://kings-printer.alberta.ca/documents/Acts/E05P5.pdf | Alberta | Binding statute | 2026-10-14 (local copy, current as of 2025-06-11) | s.8 consent to electronic form; s.16 electronic signature; s.27 click-through formation | E-signature and click-through for SUMMITOS and SaaS | s.16(2) and s.22 exceptions not analysed | HIGH (text) |
| 15 | Hosting / data processing | PIPA s.5(2), s.13.1, s.6(2); PIPEDA Sch.1 cl.4.1.3 (rows 6–7) | as above | AB / Federal | Binding statute | 2026-10-14 | as above | DPA template; subprocessor schedule | Hosting regions are unknown (technical fact) | MEDIUM |
| 16 | Tax: GST/HST | Excise Tax Act, RSC 1985, c E-15, Part IX | https://laws-lois.justice.gc.ca/eng/acts/E-15/section-165.html ; https://laws-lois.justice.gc.ca/eng/acts/E-15/section-240.html | Federal | Binding statute | 2026-10-14 | s.165(1) GST 5% on taxable supplies made in Canada; s.165(2) additional tax in participating provinces (HST); s.240(1) registration required except small suppliers | Pilot fees; NEXORA registration number on invoices | Place-of-supply rules, PST/QST and CRA guidance NOT reviewed. **ACCOUNTANT VERIFICATION REQUIRED.** | HIGH (text) / application UNVERIFIED |
| 17 | Healthcare information | Alberta Health Information Act; other provinces' health statutes | — | Alberta | — | NOT YET RESEARCHED | — | Healthcare digital systems line | — | UNVERIFIED / REQUIRES_LICENSED_COUNSEL |

Case-law policy: only cases confirmed on CanLII or a court site are listed. Row 2 is the only case so far. **No Alberta case has been verified.**

## 2. US AND INTERNATIONAL LAW (kept separate; not Canadian law)
| Topic | Status |
|---|---|
| US state privacy and breach laws (e.g., if hosting or customers are in the US) | NOT RESEARCHED. Relevant only if US customers or US subprocessors trigger them. |
| CLOUD Act exposure of US-hosted data | NOT RESEARCHED. Commentary only for now. |
| GDPR / UK GDPR | NOT RESEARCHED. Only if EU/UK data subjects are involved. |
| US UCC warranty disclaimer conventions ("merchantability") | Note: the SUMMITOS draft §11.3 uses US-style wording. The Alberta equivalent (Sale of Goods Act implied conditions) is NOT RESEARCHED and likely doesn't fit SaaS. REQUIRES_LICENSED_COUNSEL. |

## 3. NEXORA templates to build (all DRAFT_ONLY; none drafted yet under this methodology)
| Template | Status | Primary dependencies |
|---|---|---|
| Master Services Agreement (MSA) | DRAFT_ONLY — not yet drafted | Rows 1–5, 13 |
| Statement of Work (SOW) | DRAFT_ONLY — not yet drafted | Rows 3–5 |
| NDA / Confidentiality Agreement | DRAFT_ONLY — not yet drafted | Row 1 |
| SaaS Subscription Agreement | DRAFT_ONLY — not yet drafted | Rows 2, 6–14, 16 |
| SUMMITOS Controlled Paid Pilot Agreement | DRAFT_ONLY — an existing first draft (LIAISON-20261014-06) is under review, not approved | All |
| Data Processing Agreement (DPA) | DRAFT_ONLY — not yet drafted | Rows 6–8, 15 |
| Software Maintenance & Support Agreement | DRAFT_ONLY — not yet drafted | Rows 2, 13 |
| Change Order | DRAFT_ONLY — not yet drafted | Row 5 |
| Project Acceptance Certificate | DRAFT_ONLY — not yet drafted | Rows 3–5 |

## 4. Library folders (planned)
canadian_sources/ · alberta/ · nexora_policy/ (CEO_APPROVED only: currently pricing Foundation CAD $299/mo, Live Intelligence CAD $599/mo, Enterprise custom) · templates_approved/ (empty) · templates_draft/ · clause_library/ · negotiation_positions/ · risk_classifications/ · product_requirements/ · open_questions/ · lawyer_reviewed/ (empty: no professional review to date)

## 5. Review standard (A–J) and risk scale
A completeness · B clause-by-clause · C legislation/case law · D enforceability/jurisdiction · E commercial exposure · F privacy/security/cross-border · G negotiation alternatives · H defined terms/consistency · I comparison against NEXORA policy · J independent verification (Risk & Compliance via NEXORA Liaison).
Risk scale: CRITICAL (likely unlawful or unenforceable, or uncapped exposure before execution) / HIGH / MEDIUM / LOW. Every rating states its factual and legal basis.
